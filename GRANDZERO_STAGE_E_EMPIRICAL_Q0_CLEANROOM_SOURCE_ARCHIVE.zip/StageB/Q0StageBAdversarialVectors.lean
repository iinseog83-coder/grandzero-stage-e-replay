/-
  GRANDZERO Ω — Stage B (Minimal 3-Context · 1-Triangle 2-Cell Certifier)
  Module B-5: Q0StageBAdversarialVectors.lean
  Scope:
    Mechanized formal theorems & structured audit records for `TB-01 ~ TB-06`,
    plus explicit verification of Tribunal Refinements `2.C` & `2.D`:
      - `TB-01`: Molar Energy Nondimensionalize/Redimensionalize (`verifiedExactBridge` + `NonVacuousBridge`)
      - `TB-02`: Nonlinear vs. 1st-Order Taylor (`verifiedPathDiscrepancy` + universal non-commutation
                 + exact defect `-κ²v³/(1+κv)` + formal `κ`-degree `2` + `v = -1, κ = 1/2` counterexample
                 + universally quantified non-negative subdomain bound `0 ≤ -Δ(v,κ) ≤ κ²v³`)
      - `TB-03`: Subsonic ∩ Supersonic Empty Overlap (`verifiedEmptyOverlap` + vacuous `LogicalCommutation`
                 vs. universal impossibility of `verifiedExactBridge` + nonlinear SOS square witness)
      - `TB-04`: Energy (`J`, `.canonical`) vs. Torque (`N·m`, `.torque`) (`∀ w`, `.illTypedBridge`)
      - `TB-05`: Non-Empty Overlap Intermediate Guard Failure (`verifiedBridgeDomainViolation` + exclusions)
      - `TB-06`: 3D Product-Lattice Authority Escalation Attempt (`∀ w`, `.authorityEscalation`)
-/

import StageB.Q0Triangle2CellKernel

namespace GrandZero.StageB

open GrandZero.StageA

/-! ### Helper Units for Stage B Physical Scenarios -/

def molarEnergyUnit : UnitSpecQ0 :=
  { dim := { L := 2, M := 1, T := -2, N := -1 }, kind := .canonical }

def velUnit : UnitSpecQ0 :=
  { dim := { L := 1, T := -1 }, kind := .canonical }

def invVelUnit : UnitSpecQ0 :=
  { dim := { L := -1, T := 1 }, kind := .canonical }

/-! ### Vector `TB-01`: Molar Energy Nondimensionalize / Redimensionalize (`verifiedExactBridge`) -/

def tb01_C123 : ContextQ0 :=
  { vars   := [UnitSpecQ0.energy, UnitSpecQ0.energy, UnitSpecQ0.mole]
    hyps   := []
    guards := [.pos (.bvar 1), .pos (.bvar 2)] }

def tb01_C2 : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless, UnitSpecQ0.energy, UnitSpecQ0.mole]
    hyps   := []
    guards := [.pos (.bvar 1), .pos (.bvar 2)] }

def tb01_C3 : ContextQ0 :=
  { vars   := [molarEnergyUnit]
    hyps   := []
    guards := [] }

def tb01_spec : Triangle2CellSpecQ0 :=
  { C123  := tb01_C123
    C1    := tb01_C123
    C2    := tb01_C2
    C3    := tb01_C3
    iota1 := { src := tb01_C123, dst := tb01_C123, coords := [.bvar 0, .bvar 1, .bvar 2] }
    f12   := { src := tb01_C123, dst := tb01_C2,
               coords := [.binOp .div (.bvar 0) (.bvar 1), .bvar 1, .bvar 2] }
    f23   := { src := tb01_C2, dst := tb01_C3,
               coords := [.binOp .div (.binOp .mul (.bvar 0) (.bvar 1)) (.bvar 2)] }
    f13   := { src := tb01_C123, dst := tb01_C3,
               coords := [.binOp .div (.bvar 0) (.bvar 2)] }
    obs3  := .bvar 0 }

def tb01_witness : Triangle2CellWitnessQ0 :=
  .exactBridgeCert
    [10, 2, 5]
    { coordPoleProofs := []
      hypPullProofs   := []
      guardPullProofs := [.fromStageA (.gActiveMem 0), .fromStageA (.gActiveMem 1)] }
    { coordPoleProofs := [.fromStageA (.gPosImpNz (.gActiveMem 0))]
      hypPullProofs   := []
      guardPullProofs := [.fromStageA (.gActiveMem 0), .fromStageA (.gActiveMem 1)] }
    { coordPoleProofs := [.fromStageA (.gPosImpNz (.gActiveMem 1))]
      hypPullProofs   := []
      guardPullProofs := [] }
    { coordPoleProofs := [.fromStageA (.gPosImpNz (.gActiveMem 1))]
      hypPullProofs   := []
      guardPullProofs := [] }
    [.fromStageA (.gPosImpNz (.gActiveMem 0)), .fromStageA (.gPosImpNz (.gActiveMem 1))]
    [.fromStageA (.gPosImpNz (.gActiveMem 1))]

theorem tb01_molar_energy_exact_bridge :
    auditTriangle2Cell tb01_spec tb01_witness = .verifiedExactBridge ∧
    NonVacuousBridge tb01_C123 (compositeExpr tb01_spec) (directExpr tb01_spec) := by
  have h : auditTriangle2Cell tb01_spec tb01_witness = .verifiedExactBridge := by
    with_unfolding_all rfl
  exact ⟨h, (thm_stageB_exact_bridge_sound tb01_spec tb01_witness h).2.2.2.1⟩

/-! ### Vector `TB-02`: Nonlinear vs. 1st-Order Taylor Discrepancy & Exact Defect (`Tribunal 2.D`) -/

def tb02_denom : ExprQ0 :=
  .binOp .add (.ratLit 1 .unitless) (.binOp .mul (.bvar 1) (.bvar 0))

def tb02_C123 : ContextQ0 :=
  { vars   := [velUnit, invVelUnit]
    hyps   := []
    guards := [.nonNeg (.bvar 1), .pos tb02_denom] }

def tb02_C2 : ContextQ0 :=
  { vars   := [velUnit, invVelUnit, velUnit]
    hyps   := []
    guards := [.nonNeg (.bvar 1)] }

def tb02_C3 : ContextQ0 :=
  { vars   := [velUnit]
    hyps   := []
    guards := [] }

def tb02_spec : Triangle2CellSpecQ0 :=
  { C123  := tb02_C123
    C1    := tb02_C123
    C2    := tb02_C2
    C3    := tb02_C3
    iota1 := { src := tb02_C123, dst := tb02_C123, coords := [.bvar 0, .bvar 1] }
    f12   := { src := tb02_C123, dst := tb02_C2,
               coords := [.bvar 0, .bvar 1,
                          .binOp .mul (.bvar 0)
                            (.binOp .sub (.ratLit 1 .unitless) (.binOp .mul (.bvar 1) (.bvar 0)))] }
    f23   := { src := tb02_C2, dst := tb02_C3, coords := [.bvar 2] }
    f13   := { src := tb02_C123, dst := tb02_C3, coords := [.binOp .div (.bvar 0) tb02_denom] }
    obs3  := .bvar 0 }

def tb02_witness : Triangle2CellWitnessQ0 :=
  .pathDiscrepancyCert [1, 1 / 2]

theorem tb02_taylor_discrepancy_and_unbridgeable :
    auditTriangle2Cell tb02_spec tb02_witness = .verifiedPathDiscrepancy ∧
    (∀ w : Triangle2CellWitnessQ0, auditTriangle2Cell tb02_spec w ≠ .verifiedExactBridge) := by
  have h : auditTriangle2Cell tb02_spec tb02_witness = .verifiedPathDiscrepancy := by
    with_unfolding_all rfl
  exact ⟨h, (thm_stageB_path_discrepancy_sound_and_exclusive tb02_spec tb02_witness h).2⟩

def tb02_expected_defect : GPRResultQ0 :=
  { num    := { terms := [([3, 2], -1)] }
    den    := { terms := [([], 1), ([1, 1], 1)] }
    guards := [.nonZero tb02_denom]
    unit   := velUnit }

/-- Exact closed-form rational defect `Δ(v, κ) = (-1 * v³ * κ²) / (1 + v * κ)` and
    formal polynomial minimum degree `ord_κ(N_Δ) = 2` (`Tribunal Refinement 2.D`). -/
theorem tb02_exact_defect_and_kappa_order :
    compute2CellDefect tb02_spec = some tb02_expected_defect ∧
    minVarDegPoly 1 tb02_expected_defect.num = some 2 ∧
    (∀ ρ : List Rat, ValidDomainQ0 ρ tb02_C123 →
      denoteExpr ρ (defectExpr tb02_spec) =
        some (evalPoly ρ tb02_expected_defect.num / evalPoly ρ tb02_expected_defect.den)) := by
  have hdef : compute2CellDefect tb02_spec = some tb02_expected_defect := by
    with_unfolding_all rfl
  have hord : minVarDegPoly 1 tb02_expected_defect.num = some 2 := by
    with_unfolding_all rfl
  have hpole : checkBridgeGuardList tb02_C123.vars tb02_C123.hyps tb02_C123.guards
      [.fromStageA (.gPosImpNz (.gActiveMem 1))] tb02_expected_defect.guards = true := by
    with_unfolding_all rfl
  refine ⟨hdef, hord, fun ρ hvalid => ?_⟩
  exact (thm_2cell_exact_defect_sound tb02_spec tb02_expected_defect
    [.fromStageA (.gPosImpNz (.gActiveMem 1))] hdef hpole ρ hvalid).2

/-- Mechanized Counterexample from `Tribunal Refinement 2.D`:
    At `v = -1, κ = 1/2`, `[-1, 1/2] ∈ Real_ℚ(tb02_C123)` holds, `Δ(-1, 1/2) = 1/2`,
    yet `κ² v³ = -1/4`, proving `|Δ| ≤ κ² v³` is FALSE without `v ≥ 0`! -/
theorem tb02_unconstrained_bound_false_at_neg_v :
    ValidDomainQ0 [-1, 1 / 2] tb02_C123 ∧
    denoteExpr [-1, 1 / 2] (defectExpr tb02_spec) = some (1 / 2) ∧
    ¬ ((1 / 2 : Rat) ≤ (1 / 2) * (1 / 2) * ((-1) * (-1) * (-1))) := by
  have hvb : checkValidDomainQ0 [-1, 1 / 2] tb02_C123 = true := by
    with_unfolding_all rfl
  have hd : denoteExpr [-1, 1 / 2] (defectExpr tb02_spec) = some (1 / 2) := by
    with_unfolding_all rfl
  have hnot : ¬ ((1 / 2 : Rat) ≤ (1 / 2) * (1 / 2) * ((-1) * (-1) * (-1))) := by
    intro hle
    have hbad : decide ((1 / 2 : Rat) ≤ (1 / 2) * (1 / 2) * ((-1) * (-1) * (-1))) = true :=
      decide_eq_true hle
    have hfalse : decide ((1 / 2 : Rat) ≤ (1 / 2) * (1 / 2) * ((-1) * (-1) * (-1))) = false := by
      with_unfolding_all rfl
    rw [hfalse] at hbad
    contradiction
  exact ⟨(lem_checkValidDomain_iff [-1, 1 / 2] tb02_C123).mp hvb, hd, hnot⟩

/-- Universally Quantified Domain-Constrained Error Bound (`Tribunal Refinement 2.D`):
    Under explicit sign constraints `0 ≤ v` and `0 ≤ κ`, `1 + κ * v > 0` holds automatically
    and the exact truncation error satisfies `0 ≤ -Δ(v, κ) ≤ κ² v³` for ALL `v, κ ∈ ℚ`. -/
theorem tb02_nonneg_subdomain_error_bound (v κ : Rat)
    (hv : 0 ≤ v) (hκ : 0 ≤ κ) :
    let num_mag := (κ * κ) * (v * (v * v))
    let den_val := 1 + κ * v
    0 < den_val ∧
    denoteExpr [v, κ] (defectExpr tb02_spec) = some (-(num_mag / den_val)) ∧
    0 ≤ num_mag / den_val ∧
    num_mag / den_val ≤ num_mag := by
  dsimp only
  have hkv_nn : 0 ≤ κ * v := Rat.mul_nonneg hκ hv
  have hden_pos : 0 < 1 + κ * v := by grind
  have hden_nz : 1 + κ * v ≠ 0 := by grind
  have hk2_nn : 0 ≤ κ * κ := rat_sq_nonneg κ
  have hv2_nn : 0 ≤ v * v := rat_sq_nonneg v
  have hv3_nn : 0 ≤ v * (v * v) := Rat.mul_nonneg hv hv2_nn
  have hnum_nn : 0 ≤ (κ * κ) * (v * (v * v)) := Rat.mul_nonneg hk2_nn hv3_nn
  have hq_nn : 0 ≤ ((κ * κ) * (v * (v * v))) / (1 + κ * v) :=
    rat_div_nonneg hnum_nn hden_pos
  have hq_le : ((κ * κ) * (v * (v * v))) / (1 + κ * v) ≤ (κ * κ) * (v * (v * v)) := by
    let A := (κ * κ) * (v * (v * v))
    let B := 1 + κ * v
    by_cases hle : A / B ≤ A
    · exact hle
    · have hgt : 0 < A / B - A := by grind
      have hprod_pos : 0 < (A / B - A) * B := Rat.mul_pos hgt hden_pos
      have hcancel : (A / B) * B = A := rat_div_mul_cancel A B hden_nz
      have hprod_nonpos : (A / B - A) * B ≤ 0 := by
        have hdiff : (A / B - A) * B = -(A * (κ * v)) := by
          dsimp [B] at hcancel ⊢
          grind
        have hakv_nn : 0 ≤ A * (κ * v) := Rat.mul_nonneg hnum_nn hkv_nn
        grind
      grind
  have hd_eq : denoteExpr [v, κ] (defectExpr tb02_spec) =
      some (-(((κ * κ) * (v * (v * v))) / (1 + κ * v))) := by
    simp only [defectExpr, compositeExpr, directExpr, tb02_spec, tb02_denom,
               substMap, substParallel, coordsToSubst, List.getElem?_cons_zero,
               List.getElem?_cons_succ, denoteExpr, evalBinOp, hden_nz, ↓reduceIte]
    congr 1
    have h1 : v * (1 - κ * v) - v / (1 + κ * v) =
        (v * (1 - κ * v) * (1 + κ * v) - v) / (1 + κ * v) := by
      have hv_div : v * (1 - κ * v) = (v * (1 - κ * v)) / 1 := (rat_div_one _).symm
      rw [hv_div, rat_sub_frac _ _ _ _ (by grind) hden_nz]
      grind
    have hnum_alg : v * (1 - κ * v) * (1 + κ * v) - v = -((κ * κ) * (v * (v * v))) := by grind
    rw [h1, hnum_alg, ← rat_neg_div]
  exact ⟨hden_pos, hd_eq, hq_nn, hq_le⟩

/-! ### Vector `TB-03`: Subsonic ∩ Supersonic Empty Overlap & Vacuous-Gluing Defense -/

def tb03_C123 : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless]
    hyps   := []
    guards := [.pos (.binOp .sub (.ratLit 1 .unitless) (.bvar 0)),
               .nonNeg (.binOp .sub (.bvar 0) (.ratLit 2 .unitless))] }

def tb03_C1 : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless]
    hyps   := []
    guards := [.pos (.binOp .sub (.ratLit 1 .unitless) (.bvar 0))] }

def tb03_C2 : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless]
    hyps   := []
    guards := [.nonNeg (.binOp .sub (.bvar 0) (.ratLit 2 .unitless))] }

def tb03_C3 : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless]
    hyps   := []
    guards := [] }

def tb03_spec : Triangle2CellSpecQ0 :=
  { C123  := tb03_C123
    C1    := tb03_C1
    C2    := tb03_C2
    C3    := tb03_C3
    iota1 := { src := tb03_C123, dst := tb03_C1, coords := [.bvar 0] }
    f12   := { src := tb03_C1,   dst := tb03_C2, coords := [.bvar 0] }
    f23   := { src := tb03_C2,   dst := tb03_C3, coords := [.bvar 0] }
    f13   := { src := tb03_C1,   dst := tb03_C3, coords := [.bvar 0] }
    obs3  := .bvar 0 }

def tb03_cone_cert : EmptyOverlapCertQ0 :=
  .coneContradiction
    [{ weight     := 1
       weightUnit := .unitless
       expr       := .binOp .sub (.ratLit 1 .unitless) (.bvar 0)
       proof      := .fromStageA (.gActiveMem 0) }]
    [{ weight     := 1
       weightUnit := .unitless
       expr       := .binOp .sub (.bvar 0) (.ratLit 2 .unitless)
       proof      := .fromStageA (.gActiveMem 1) }]
    []

def tb03_witness : Triangle2CellWitnessQ0 :=
  .emptyOverlapCert tb03_cone_cert

/-- Proves BOTH:
    1. `LogicalCommutation` IS vacuously true on `TB-03` (`e_123 = M = e_13`), YET
    2. `auditTriangle2Cell` certifies `.verifiedEmptyOverlap` AND blocks `.verifiedExactBridge`
       for ALL candidate witnesses (`F-PHCA-B02` vacuous-gluing defense)! -/
theorem tb03_mach_empty_overlap_and_vacuous_blocked :
    LogicalCommutation tb03_C123 (compositeExpr tb03_spec) (directExpr tb03_spec) ∧
    auditTriangle2Cell tb03_spec tb03_witness = .verifiedEmptyOverlap ∧
    (∀ w : Triangle2CellWitnessQ0, auditTriangle2Cell tb03_spec w ≠ .verifiedExactBridge) := by
  have hemp : auditTriangle2Cell tb03_spec tb03_witness = .verifiedEmptyOverlap := by
    with_unfolding_all rfl
  have hexcl := thm_stageB_empty_overlap_sound_and_exclusive tb03_spec tb03_witness hemp
  have hvac : LogicalCommutation tb03_C123 (compositeExpr tb03_spec) (directExpr tb03_spec) := by
    intro ρ hvalid
    exact False.elim (hexcl.1 ρ hvalid)
  exact ⟨hvac, hemp, fun w => (hexcl.2 w).1⟩

/-- Nonlinear SOS/Square Preordering Empty-Overlap Witness (`Tribunal Refinement 2.C`):
    Context `[x : 1]` with guard `-(x² + 1) > 0` is certified globally empty via `gSqNNeg`. -/
def tb03_sos_ctx : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless]
    hyps   := []
    guards := [.pos (.unaryNeg (.binOp .add (.binOp .mul (.bvar 0) (.bvar 0)) (.ratLit 1 .unitless)))] }

def tb03_sos_cert : EmptyOverlapCertQ0 :=
  .coneContradiction
    [{ weight     := 1
       weightUnit := .unitless
       expr       := .unaryNeg (.binOp .add (.binOp .mul (.bvar 0) (.bvar 0)) (.ratLit 1 .unitless))
       proof      := .fromStageA (.gActiveMem 0) }]
    [{ weight     := 1
       weightUnit := .unitless
       expr       := .binOp .mul (.bvar 0) (.bvar 0)
       proof      := .gSqNNeg [] }]
    []

theorem tb03_sos_nonlinear_empty_overlap :
    checkEmptyOverlapCert tb03_sos_ctx tb03_sos_cert = true ∧
    (∀ ρ : List Rat, ¬ ValidDomainQ0 ρ tb03_sos_ctx) := by
  have h : checkEmptyOverlapCert tb03_sos_ctx tb03_sos_cert = true := by
    with_unfolding_all rfl
  exact ⟨h, thm_empty_overlap_sound tb03_sos_ctx tb03_sos_cert h⟩

/-! ### Vector `TB-04`: Iso-Dimensional Energy (`J`) vs. Torque (`N·m`) Fiber Tear -/

def tb04_C1 : ContextQ0 := { vars := [UnitSpecQ0.energy], hyps := [], guards := [] }
def tb04_C2 : ContextQ0 := { vars := [UnitSpecQ0.torque], hyps := [], guards := [] }

def tb04_spec : Triangle2CellSpecQ0 :=
  { C123  := tb04_C1
    C1    := tb04_C1
    C2    := tb04_C2
    C3    := tb04_C1
    iota1 := { src := tb04_C1, dst := tb04_C1, coords := [.bvar 0] }
    f12   := { src := tb04_C1, dst := tb04_C2, coords := [.bvar 0] }
    f23   := { src := tb04_C2, dst := tb04_C1, coords := [.bvar 0] }
    f13   := { src := tb04_C1, dst := tb04_C1, coords := [.bvar 0] }
    obs3  := .bvar 0 }

theorem tb04_energy_torque_ill_typed_all_witnesses :
    ∀ w : Triangle2CellWitnessQ0,
      auditTriangle2Cell tb04_spec w = .rejectedIllTypedOrUnverified .illTypedBridge := by
  apply thm_stageB_ill_typed_universal_reject
  with_unfolding_all rfl

/-! ### Vector `TB-05`: Non-Empty Overlap Intermediate Guard Domain Violation -/

def tb05_C123 : ContextQ0 := { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }
def tb05_C2   : ContextQ0 := { vars := [UnitSpecQ0.unitless], hyps := [], guards := [.pos (.bvar 0)] }
def tb05_C3   : ContextQ0 := { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }

def tb05_spec : Triangle2CellSpecQ0 :=
  { C123  := tb05_C123
    C1    := tb05_C123
    C2    := tb05_C2
    C3    := tb05_C3
    iota1 := { src := tb05_C123, dst := tb05_C123, coords := [.bvar 0] }
    f12   := { src := tb05_C123, dst := tb05_C2,   coords := [.bvar 0] }
    f23   := { src := tb05_C2,   dst := tb05_C3,   coords := [.bvar 0] }
    f13   := { src := tb05_C123, dst := tb05_C3,   coords := [.bvar 0] }
    obs3  := .bvar 0 }

def tb05_witness : Triangle2CellWitnessQ0 :=
  .bridgeDomainViolationCert [-1]

theorem tb05_intermediate_guard_domain_violation :
    auditTriangle2Cell tb05_spec tb05_witness = .verifiedBridgeDomainViolation ∧
    (∀ w : Triangle2CellWitnessQ0,
      auditTriangle2Cell tb05_spec w ≠ .verifiedExactBridge ∧
      auditTriangle2Cell tb05_spec w ≠ .verifiedEmptyOverlap) := by
  have h : auditTriangle2Cell tb05_spec tb05_witness = .verifiedBridgeDomainViolation := by
    with_unfolding_all rfl
  exact ⟨h, (thm_stageB_domain_violation_sound_and_exclusive tb05_spec tb05_witness h).2⟩

/-! ### Vector `TB-06`: 3D Product-Lattice Authority Escalation Blocked (`Tribunal 2.B`) -/

def tb06_spec : Triangle2CellSpecQ0 :=
  { tb01_spec with
    f12 := { tb01_spec.f12 with
             srcAuth := AuthorityVecQ0.formalOnly
             dstAuth := AuthorityVecQ0.formalEmpirical } }

theorem tb06_authority_escalation_blocked_all_witnesses :
    ∀ w : Triangle2CellWitnessQ0,
      auditTriangle2Cell tb06_spec w = .rejectedIllTypedOrUnverified .authorityEscalation := by
  apply thm_stageB_authority_universal_reject
  · with_unfolding_all rfl
  · with_unfolding_all rfl

/-! ### Structured Formatting Helpers for `stage_b_audit` Executable -/

def formatOutcome : TriangleAuditOutcomeQ0 → String
  | .verifiedExactBridge           => "verifiedExactBridge"
  | .verifiedPathDiscrepancy       => "verifiedPathDiscrepancy"
  | .verifiedEmptyOverlap          => "verifiedEmptyOverlap"
  | .verifiedBridgeDomainViolation => "verifiedBridgeDomainViolation"
  | .rejectedIllTypedOrUnverified .illTypedBridge =>
      "rejectedIllTypedOrUnverified(illTypedBridge)"
  | .rejectedIllTypedOrUnverified .authorityEscalation =>
      "rejectedIllTypedOrUnverified(authorityEscalation)"
  | .rejectedIllTypedOrUnverified .invalidWitnessOrConservativeUnverified =>
      "rejectedIllTypedOrUnverified(invalidWitnessOrConservativeUnverified)"

end GrandZero.StageB
