/-
  GRANDZERO Ω — Stage A (M1-P0 R3) Isolated Kernel
  Module A-3: Q0ValidTape.lean
  Scope: `RawTape` vs Dependent `ValidTape m n`, `strictBind` Wire Semantics,
         `validateTape`, `reifyTape` (`LEM-REIFY-EXACT`), `lowerExprTop`,
         `PO-TAPE-DEPS`, `PO-TAPE-LOCALITY`, and `PO-TAPE-EQUIV`.
-/

import StageA.Q0PartialSemantics

namespace GrandZero.StageA

/-- Flat serializable SSA node representation (`RawTape` element). -/
inductive RawNodeQ0 where
  | inVar      : Nat → RawNodeQ0
  | constRat   : Rat → UnitSpecQ0 → RawNodeQ0
  | unaryNeg   : Nat → RawNodeQ0
  | binOp      : BinOpQ0 → Nat → Nat → RawNodeQ0
  | strictBind : Nat → Nat → RawNodeQ0
  deriving DecidableEq, Repr, Inhabited

abbrev RawTape := Array RawNodeQ0

/-- Dependently-typed SSA node at row `k` with `m` free context variables:
    every wire reference is statically bounded in `Fin k` (strictly backward acyclic DAG). -/
inductive ValidNode (m k : Nat) where
  | inVar      : Fin m → ValidNode m k
  | constRat   : Rat → UnitSpecQ0 → ValidNode m k
  | unaryNeg   : Fin k → ValidNode m k
  | binOp      : BinOpQ0 → Fin k → Fin k → ValidNode m k
  | strictBind : Fin k → Fin k → ValidNode m k
  deriving DecidableEq, Repr

/-- Erase `Fin` proofs back to `RawNodeQ0` (injective erasure for locality comparison). -/
def ValidNode.toRaw {m k : Nat} : ValidNode m k → RawNodeQ0
  | .inVar s        => .inVar s.val
  | .constRat q u   => .constRat q u
  | .unaryNeg a     => .unaryNeg a.val
  | .binOp op a b   => .binOp op a.val b.val
  | .strictBind a b => .strictBind a.val b.val

theorem ValidNode.toRaw_inj {m k : Nat} {n1 n2 : ValidNode m k}
    (h : n1.toRaw = n2.toRaw) : n1 = n2 := by
  cases n1 <;> cases n2 <;> simp [ValidNode.toRaw] at h
  · exact congrArg ValidNode.inVar (Fin.ext h)
  · rcases h with ⟨hq, hu⟩; subst hq; subst hu; rfl
  · exact congrArg ValidNode.unaryNeg (Fin.ext h)
  · rcases h with ⟨hop, ha, hb⟩
    have ha' := Fin.ext ha
    have hb' := Fin.ext hb
    subst hop; subst ha'; subst hb'; rfl
  · rcases h with ⟨ha, hb⟩
    have ha' := Fin.ext ha
    have hb' := Fin.ext hb
    subst ha'; subst hb'; rfl

/-- Proof-carrying topological SSA tape telescope of length `n` over `m` free variables. -/
inductive ValidTape (m : Nat) : Nat → Type where
  | empty : ValidTape m 0
  | snoc  : {k : Nat} → ValidTape m k → ValidNode m k → ValidTape m (k + 1)

/-- Package of a validated/lowered SSA tape together with a designated root wire. -/
structure RootedTape (m : Nat) where
  len  : Nat
  tape : ValidTape m len
  root : Fin len

/-! ### Runtime Validator (`RawTape → Option (Σ n, ValidTape m n)`) -/

def validateNode (m k : Nat) : RawNodeQ0 → Option (ValidNode m k)
  | .inVar s =>
      if hs : s < m then some (.inVar ⟨s, hs⟩) else none
  | .constRat q u =>
      some (.constRat q u)
  | .unaryNeg a =>
      if ha : a < k then some (.unaryNeg ⟨a, ha⟩) else none
  | .binOp op a b =>
      if ha : a < k then
        if hb : b < k then some (.binOp op ⟨a, ha⟩ ⟨b, hb⟩) else none
      else none
  | .strictBind a b =>
      if ha : a < k then
        if hb : b < k then some (.strictBind ⟨a, ha⟩ ⟨b, hb⟩) else none
      else none

def validateTapeList (m : Nat) : List RawNodeQ0 → Option (Σ n, ValidTape m n)
  | [] => some ⟨0, .empty⟩
  | raw :: rest =>
      -- Fold left from empty so index `k` grows forward
      let rec go {k : Nat} (vt : ValidTape m k) : List RawNodeQ0 → Option (Σ n, ValidTape m n)
        | [] => some ⟨k, vt⟩
        | r :: rs =>
            match validateNode m k r with
            | some nd => go (vt.snoc nd) rs
            | none    => none
      match validateNode m 0 raw with
      | some nd0 => go (ValidTape.empty.snoc nd0) rest
      | none     => none

/-- Structural validator promoting untrusted `RawTape` into dependently-indexed `ValidTape`. -/
def validateTape (m : Nat) (raw : RawTape) : Option (Σ n, ValidTape m n) :=
  validateTapeList m raw.toList

/-- Validate both `RawTape` and `rootIdx < n` (`M1-P0 R3` §3 Tier-1 structural gate). -/
def validateRootedTape (m : Nat) (raw : RawTape) (rootIdx : Nat) : Option (RootedTape m) :=
  match validateTape m raw with
  | some ⟨n, vt⟩ =>
      if hr : rootIdx < n then some ⟨n, vt, ⟨rootIdx, hr⟩⟩ else none
  | none => none

/-! ### Local Wire Semantics: Value, Unit, Reification, Strict Dependencies -/

def nodeAt {m : Nat} : {n : Nat} → ValidTape m n → Fin n → RawNodeQ0
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i =>
      if h : i.val < k then nodeAt vt ⟨i.val, h⟩ else nd.toRaw

def evalNode {m k : Nat} (ρ : List Rat) (vals : Fin k → Option Rat) :
    ValidNode m k → Option Rat
  | .inVar s        => ρ[s.val]?
  | .constRat q _   => some q
  | .unaryNeg a     =>
      match vals a with
      | some va => some (-va)
      | none    => none
  | .binOp op a b   => evalBinOp op (vals a) (vals b)
  | .strictBind a b =>
      match vals a, vals b with
      | some _, some vb => some vb
      | _, _            => none

def evalValidTape {m : Nat} (ρ : List Rat) : {n : Nat} → ValidTape m n → Fin n → Option Rat
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i =>
      if h : i.val < k then evalValidTape ρ vt ⟨i.val, h⟩
      else evalNode ρ (evalValidTape ρ vt) nd

def evalTapeRoot {m : Nat} (ρ : List Rat) (rt : RootedTape m) : Option Rat :=
  evalValidTape ρ rt.tape rt.root

def unitNode {m k : Nat} (Γ : VarCtxQ0) (units : Fin k → Option UnitSpecQ0) :
    ValidNode m k → Option UnitSpecQ0
  | .inVar s        => Γ[s.val]?
  | .constRat _ u   => some u
  | .unaryNeg a     => units a
  | .binOp op a b   =>
      match units a, units b with
      | some u1, some u2 => synthBinOpUnit op u1 u2
      | _, _             => none
  | .strictBind a b =>
      match units a, units b with
      | some _, some ub => some ub
      | _, _            => none

def synthUnitTape {m : Nat} (Γ : VarCtxQ0) :
    {n : Nat} → ValidTape m n → Fin n → Option UnitSpecQ0
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i =>
      if h : i.val < k then synthUnitTape Γ vt ⟨i.val, h⟩
      else unitNode Γ (synthUnitTape Γ vt) nd

def synthUnitTapeRoot {m : Nat} (Γ : VarCtxQ0) (rt : RootedTape m) : Option UnitSpecQ0 :=
  synthUnitTape Γ rt.tape rt.root

/-- Tier-2 static unit check across ALL rows of a `ValidTape` (`M1-P0 R3` §3). -/
def checkAllRowsWellTyped {m : Nat} (Γ : VarCtxQ0) : {n : Nat} → ValidTape m n → Bool
  | 0, .empty => true
  | _ + 1, .snoc vt nd =>
      checkAllRowsWellTyped Γ vt && (unitNode Γ (synthUnitTape Γ vt) nd).isSome

def reifyNode {m k : Nat} (exprs : Fin k → ExprQ0) : ValidNode m k → ExprQ0
  | .inVar s        => .bvar s.val
  | .constRat q u   => .ratLit q u
  | .unaryNeg a     => .unaryNeg (exprs a)
  | .binOp op a b   => .binOp op (exprs a) (exprs b)
  | .strictBind a b => .letBind (exprs a) (liftExpr 0 1 (exprs b))

def reifyTape {m : Nat} : {n : Nat} → ValidTape m n → Fin n → ExprQ0
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i =>
      if h : i.val < k then reifyTape vt ⟨i.val, h⟩
      else reifyNode (reifyTape vt) nd

def depsNode {m k : Nat} (deps : Fin k → List Nat) : ValidNode m k → List Nat
  | .inVar _        => []
  | .constRat _ _   => []
  | .unaryNeg a     => a.val :: deps a
  | .binOp _ a b    => a.val :: b.val :: (deps a ++ deps b)
  | .strictBind a b => a.val :: b.val :: (deps a ++ deps b)

def strictDeps {m : Nat} : {n : Nat} → ValidTape m n → Fin n → List Nat
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i =>
      if h : i.val < k then strictDeps vt ⟨i.val, h⟩
      else depsNode (strictDeps vt) nd

/-! ### `snoc` Simplification Lemmas -/

@[simp] theorem nodeAt_snoc_lt {m k : Nat} (vt : ValidTape m k) (nd : ValidNode m k)
    (i : Fin k) : nodeAt (vt.snoc nd) (Fin.castSucc i) = nodeAt vt i := by
  simp [nodeAt, i.isLt]

@[simp] theorem nodeAt_snoc_last {m k : Nat} (vt : ValidTape m k) (nd : ValidNode m k) :
    nodeAt (vt.snoc nd) (Fin.last k) = nd.toRaw := by
  simp [nodeAt]

@[simp] theorem evalValidTape_snoc_lt {m k : Nat} (ρ : List Rat) (vt : ValidTape m k)
    (nd : ValidNode m k) (i : Fin k) :
    evalValidTape ρ (vt.snoc nd) (Fin.castSucc i) = evalValidTape ρ vt i := by
  simp [evalValidTape, i.isLt]

@[simp] theorem evalValidTape_snoc_last {m k : Nat} (ρ : List Rat) (vt : ValidTape m k)
    (nd : ValidNode m k) :
    evalValidTape ρ (vt.snoc nd) (Fin.last k) = evalNode ρ (evalValidTape ρ vt) nd := by
  simp [evalValidTape]

@[simp] theorem synthUnitTape_snoc_lt {m k : Nat} (Γ : VarCtxQ0) (vt : ValidTape m k)
    (nd : ValidNode m k) (i : Fin k) :
    synthUnitTape Γ (vt.snoc nd) (Fin.castSucc i) = synthUnitTape Γ vt i := by
  simp [synthUnitTape, i.isLt]

@[simp] theorem synthUnitTape_snoc_last {m k : Nat} (Γ : VarCtxQ0) (vt : ValidTape m k)
    (nd : ValidNode m k) :
    synthUnitTape Γ (vt.snoc nd) (Fin.last k) = unitNode Γ (synthUnitTape Γ vt) nd := by
  simp [synthUnitTape]

@[simp] theorem reifyTape_snoc_lt {m k : Nat} (vt : ValidTape m k)
    (nd : ValidNode m k) (i : Fin k) :
    reifyTape (vt.snoc nd) (Fin.castSucc i) = reifyTape vt i := by
  simp [reifyTape, i.isLt]

@[simp] theorem reifyTape_snoc_last {m k : Nat} (vt : ValidTape m k)
    (nd : ValidNode m k) :
    reifyTape (vt.snoc nd) (Fin.last k) = reifyNode (reifyTape vt) nd := by
  simp [reifyTape]

@[simp] theorem strictDeps_snoc_lt {m k : Nat} (vt : ValidTape m k)
    (nd : ValidNode m k) (i : Fin k) :
    strictDeps (vt.snoc nd) (Fin.castSucc i) = strictDeps vt i := by
  simp [strictDeps, i.isLt]

@[simp] theorem strictDeps_snoc_last {m k : Nat} (vt : ValidTape m k)
    (nd : ValidNode m k) :
    strictDeps (vt.snoc nd) (Fin.last k) = depsNode (strictDeps vt) nd := by
  simp [strictDeps]

/-! ### `LEM-REIFY-SCOPED` and `LEM-REIFY-EXACT` (`M1-P0 R3` §1.3) -/

theorem reifyTape_wellScoped {m : Nat} :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n),
      wellScoped m (reifyTape vt i) = true
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i => by
      simp only [reifyTape]
      split
      · rename_i hlt
        exact reifyTape_wellScoped vt ⟨i.val, hlt⟩
      · cases nd with
        | inVar s =>
            simp [reifyNode, wellScoped, s.isLt]
        | constRat q u =>
            rfl
        | unaryNeg a =>
            simpa [reifyNode, wellScoped] using reifyTape_wellScoped vt a
        | binOp op a b =>
            simp [reifyNode, wellScoped,
                  reifyTape_wellScoped vt a, reifyTape_wellScoped vt b]
        | strictBind a b =>
            have ha := reifyTape_wellScoped vt a
            have hb := wellScoped_liftExpr (reifyTape vt b) 0 1 m (Nat.zero_le m)
                         (reifyTape_wellScoped vt b)
            simp [reifyNode, wellScoped, ha, hb]

/-- Target Obligation `LEM-REIFY-EXACT` (`M1-P0 R3` §1.3):
    For EVERY `ValidTape m n` and EVERY wire `i : Fin n`, `reifyTape vt i` has
    exact denotational and static-unit agreement with the SSA wire `i`. -/
theorem lem_reify_exact {m : Nat} :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n),
      (∀ ρ : List Rat, denoteExpr ρ (reifyTape vt i) = evalValidTape ρ vt i) ∧
      (∀ Γ : VarCtxQ0, synthUnit Γ (reifyTape vt i) = synthUnitTape Γ vt i)
  | 0, .empty, i => i.elim0
  | k + 1, .snoc vt nd, i => by
      simp only [reifyTape, evalValidTape, synthUnitTape]
      split
      · rename_i hlt
        exact lem_reify_exact vt ⟨i.val, hlt⟩
      · constructor
        · intro ρ
          cases nd with
          | inVar s => rfl
          | constRat q u => rfl
          | unaryNeg a =>
              have iha := (lem_reify_exact vt a).1 ρ
              simp only [reifyNode, evalNode, denoteExpr, iha]
              cases evalValidTape ρ vt a <;> rfl
          | binOp op a b =>
              have iha := (lem_reify_exact vt a).1 ρ
              have ihb := (lem_reify_exact vt b).1 ρ
              simp [reifyNode, evalNode, denoteExpr, iha, ihb]
          | strictBind a b =>
              have iha := (lem_reify_exact vt a).1 ρ
              have ihb := (lem_reify_exact vt b).1 ρ
              simp only [reifyNode, evalNode, denoteExpr, iha]
              cases evalValidTape ρ vt a with
              | none => rfl
              | some va =>
                  dsimp only
                  rw [denoteExpr_lift0_one va ρ (reifyTape vt b), ihb]
                  cases evalValidTape ρ vt b <;> rfl
        · intro Γ
          cases nd with
          | inVar s => rfl
          | constRat q u => rfl
          | unaryNeg a =>
              have iha := (lem_reify_exact vt a).2 Γ
              simp [reifyNode, unitNode, synthUnit, iha]
          | binOp op a b =>
              have iha := (lem_reify_exact vt a).2 Γ
              have ihb := (lem_reify_exact vt b).2 Γ
              simp only [reifyNode, unitNode, synthUnit, iha, ihb]
              cases synthUnitTape Γ vt a <;> cases synthUnitTape Γ vt b <;> rfl
          | strictBind a b =>
              have iha := (lem_reify_exact vt a).2 Γ
              have ihb := (lem_reify_exact vt b).2 Γ
              simp only [reifyNode, unitNode, synthUnit, iha]
              cases synthUnitTape Γ vt a with
              | none => rfl
              | some ua =>
                  dsimp only
                  rw [synthUnit_lift0_one ua Γ (reifyTape vt b), ihb]
                  cases synthUnitTape Γ vt b <;> rfl

/-! ### `PO-TAPE-LOCALITY` (`M1-P0 R2/R3`): Dead-Row Locality Outside `{r} ∪ StrictDeps` -/

theorem strictDeps_lt {m : Nat} :
    ∀ {n : Nat} (vt : ValidTape m n) (i : Fin n) (x : Nat),
      x ∈ strictDeps vt i → x < i.val
  | 0, .empty, i, _, _ => i.elim0
  | k + 1, .snoc vt nd, i, x, hx => by
      simp only [strictDeps] at hx
      split at hx
      · rename_i hlt
        exact strictDeps_lt vt ⟨i.val, hlt⟩ x hx
      · rename_i hge
        have hi_eq : i.val = k := by omega
        rw [hi_eq]
        cases nd with
        | inVar _ => simp [depsNode] at hx
        | constRat _ _ => simp [depsNode] at hx
        | unaryNeg a =>
            simp only [depsNode, List.mem_cons] at hx
            cases hx with
            | inl h => subst h; exact a.isLt
            | inr h => exact Nat.lt_trans (strictDeps_lt vt a x h) a.isLt
        | binOp _ a b | strictBind a b =>
            simp only [depsNode, List.mem_cons, List.mem_append] at hx
            rcases hx with rfl | rfl | ha | hb
            · exact a.isLt
            · exact b.isLt
            · exact Nat.lt_trans (strictDeps_lt vt a x ha) a.isLt
            · exact Nat.lt_trans (strictDeps_lt vt b x hb) b.isLt

/-- Target Obligation `PO-TAPE-LOCALITY` (`M1-P0 R2/R3`):
    Any two valid tapes `vt₁, vt₂` that agree on the wire cone `r.val :: strictDeps vt₁ r`
    produce identical strict dependencies, identical root denotations, identical static units,
    and identical reified expressions — regardless of arbitrary dead-row failures (`1/0`, etc.)
    outside `{r} ∪ StrictDeps(vt₁, r)`. -/
theorem po_tape_locality {m : Nat} :
    ∀ {n : Nat} (vt₁ vt₂ : ValidTape m n) (r : Fin n),
      (∀ j : Fin n, j.val ∈ r.val :: strictDeps vt₁ r → nodeAt vt₁ j = nodeAt vt₂ j) →
      strictDeps vt₁ r = strictDeps vt₂ r ∧
      reifyTape vt₁ r = reifyTape vt₂ r ∧
      (∀ ρ : List Rat, evalValidTape ρ vt₁ r = evalValidTape ρ vt₂ r) ∧
      (∀ Γ : VarCtxQ0, synthUnitTape Γ vt₁ r = synthUnitTape Γ vt₂ r)
  | 0, .empty, .empty, r, _ => r.elim0
  | k + 1, .snoc u₁ nd₁, .snoc u₂ nd₂, r, hcone => by
      if hlt : r.val < k then
        let r' : Fin k := ⟨r.val, hlt⟩
        have hsub : ∀ j : Fin k, j.val ∈ r'.val :: strictDeps u₁ r' →
            nodeAt u₁ j = nodeAt u₂ j := by
          intro j hj
          have hj' : (Fin.castSucc j).val ∈ r.val :: strictDeps (u₁.snoc nd₁) r := by
            simpa [strictDeps, hlt, r'] using hj
          have hraw := hcone (Fin.castSucc j) hj'
          simpa [nodeAt, j.isLt] using hraw
        have ih := po_tape_locality u₁ u₂ r' hsub
        simp only [strictDeps, reifyTape, evalValidTape, synthUnitTape, hlt, dite_true]
        exact ih
      else
        have hr_eq : r = Fin.last k := by
          apply Fin.ext
          have hr_lt := r.isLt
          simp only [Fin.val_last]
          omega
        subst hr_eq
        have htop := hcone (Fin.last k) (by simp)
        simp only [nodeAt_snoc_last] at htop
        have hnd : nd₁ = nd₂ := ValidNode.toRaw_inj htop
        subst hnd
        simp only [strictDeps_snoc_last, reifyTape_snoc_last,
                   evalValidTape_snoc_last, synthUnitTape_snoc_last]
        have helper : ∀ a : Fin k,
            (∀ x ∈ a.val :: strictDeps u₁ a, x ∈ (Fin.last k).val :: depsNode (strictDeps u₁) nd₁) →
            strictDeps u₁ a = strictDeps u₂ a ∧
            reifyTape u₁ a = reifyTape u₂ a ∧
            (∀ ρ, evalValidTape ρ u₁ a = evalValidTape ρ u₂ a) ∧
            (∀ Γ, synthUnitTape Γ u₁ a = synthUnitTape Γ u₂ a) := by
          intro a hmem
          apply po_tape_locality u₁ u₂ a
          intro j hj
          have hj_in := hmem j.val hj
          have hraw := hcone (Fin.castSucc j) (by simpa [strictDeps] using hj_in)
          simpa [nodeAt, j.isLt] using hraw
        cases nd₁ with
        | inVar s =>
            simp [depsNode, reifyNode, evalNode, unitNode]
        | constRat q u =>
            simp [depsNode, reifyNode, evalNode, unitNode]
        | unaryNeg a =>
            have iha := helper a (by
              intro x hx
              simp only [depsNode, List.mem_cons] at hx ⊢
              exact Or.inr hx)
            rcases iha with ⟨hd, hr, he, hu⟩
            refine ⟨by simp [depsNode, hd], by simp [reifyNode, hr],
                    fun ρ => by simp [evalNode, he ρ],
                    fun Γ => by simp [unitNode, hu Γ]⟩
        | binOp op a b =>
            have iha := helper a (by
              intro x hx
              simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxa
              · exact Or.inr (Or.inl rfl)
              · exact Or.inr (Or.inr (Or.inr (Or.inl hxa))))
            have ihb := helper b (by
              intro x hx
              simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxb
              · exact Or.inr (Or.inr (Or.inl rfl))
              · exact Or.inr (Or.inr (Or.inr (Or.inr hxb))))
            rcases iha with ⟨hda, hra, hea, hua⟩
            rcases ihb with ⟨hdb, hrb, heb, hub⟩
            refine ⟨by simp [depsNode, hda, hdb],
                    by simp [reifyNode, hra, hrb],
                    fun ρ => by simp [evalNode, hea ρ, heb ρ],
                    fun Γ => by simp [unitNode, hua Γ, hub Γ]⟩
        | strictBind a b =>
            have iha := helper a (by
              intro x hx
              simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxa
              · exact Or.inr (Or.inl rfl)
              · exact Or.inr (Or.inr (Or.inr (Or.inl hxa))))
            have ihb := helper b (by
              intro x hx
              simp only [depsNode, List.mem_cons, List.mem_append] at hx ⊢
              rcases hx with rfl | hxb
              · exact Or.inr (Or.inr (Or.inl rfl))
              · exact Or.inr (Or.inr (Or.inr (Or.inr hxb))))
            rcases iha with ⟨hda, hra, hea, hua⟩
            rcases ihb with ⟨hdb, hrb, heb, hub⟩
            refine ⟨by simp [depsNode, hda, hdb],
                    by simp [reifyNode, hra, hrb],
                    fun ρ => by simp [evalNode, hea ρ, heb ρ],
                    fun Γ => by simp [unitNode, hua Γ, hub Γ]⟩

/-- Prefix extension predicate (`vt ⊑ vt'`) and automatic wire preservation via `po_tape_locality`. -/
def TapePrefix {m k n : Nat} (hle : k ≤ n) (vt : ValidTape m k) (vt' : ValidTape m n) : Prop :=
  ∀ j : Fin k, nodeAt vt' (Fin.castLE hle j) = nodeAt vt j

theorem TapePrefix.refl {m k : Nat} (vt : ValidTape m k) :
    TapePrefix (Nat.le_refl k) vt vt := fun _ => rfl

theorem TapePrefix.snoc_step {m k : Nat} (vt : ValidTape m k) (nd : ValidNode m k) :
    TapePrefix (Nat.le_succ k) vt (vt.snoc nd) := by
  intro j
  exact nodeAt_snoc_lt vt nd j

theorem TapePrefix.trans {m a b c : Nat} {h1 : a ≤ b} {h2 : b ≤ c}
    {t1 : ValidTape m a} {t2 : ValidTape m b} {t3 : ValidTape m c}
    (p1 : TapePrefix h1 t1 t2) (p2 : TapePrefix h2 t2 t3) :
    TapePrefix (Nat.le_trans h1 h2) t1 t3 := by
  intro j
  have e2 := p2 (Fin.castLE h1 j)
  have heq : Fin.castLE h2 (Fin.castLE h1 j) = Fin.castLE (Nat.le_trans h1 h2) j := rfl
  rw [heq] at e2
  exact e2.trans (p1 j)

theorem tapePrefix_preserves {m : Nat} :
    ∀ {k n : Nat} (hle : k ≤ n) (vt : ValidTape m k) (vt' : ValidTape m n),
      TapePrefix hle vt vt' →
      ∀ i : Fin k,
        strictDeps vt' (Fin.castLE hle i) = strictDeps vt i ∧
        reifyTape vt' (Fin.castLE hle i) = reifyTape vt i ∧
        (∀ ρ : List Rat, evalValidTape ρ vt' (Fin.castLE hle i) = evalValidTape ρ vt i) ∧
        (∀ Γ : VarCtxQ0, synthUnitTape Γ vt' (Fin.castLE hle i) = synthUnitTape Γ vt i)
  | k, n, hle, vt, vt', hpref, i => by
      induction n with
      | zero =>
          have hk0 : k = 0 := by omega
          subst hk0
          exact i.elim0
      | succ n' ih =>
          cases vt' with
          | snoc u nd =>
              if hk : k ≤ n' then
                have hpref' : TapePrefix hk vt u := by
                  intro j
                  have h1 := hpref j
                  have hlt : (Fin.castLE hle j).val < n' := by
                    simp [Fin.castLE]; omega
                  simp only [nodeAt, hlt, dite_true] at h1
                  exact h1
                have res := ih hk u hpref'
                have hi_lt : (Fin.castLE hle i).val < n' := by
                  simp [Fin.castLE]; omega
                simp only [strictDeps, reifyTape, evalValidTape, synthUnitTape, hi_lt, dite_true]
                exact res
              else
                have hkeq : k = n' + 1 := by omega
                subst hkeq
                have hc : Fin.castLE hle i = i := rfl
                rw [hc]
                apply (po_tape_locality (u.snoc nd) vt i _ )
                intro j _
                exact hpref j

/-! ### AST-to-SSA Lowering (`seedVars`, `lowerAux`, `lowerExprTop`) (`M1-P0 R3` §1.2) -/

structure LowerRes {m k : Nat} (vt : ValidTape m k) where
  len    : Nat
  hle    : k ≤ len
  tape   : ValidTape m len
  root   : Fin len
  isPref : TapePrefix hle vt tape

/-- Seed `0 .. count - 1` free variables onto `ValidTape m count` (for `count ≤ m`). -/
def seedVarsAux (m : Nat) : (count : Nat) → count ≤ m → ValidTape m count
  | 0, _ => .empty
  | c + 1, hc =>
      let prev := seedVarsAux m c (Nat.le_of_succ_le hc)
      prev.snoc (.inVar ⟨c, hc⟩)

def seedVars (m : Nat) : ValidTape m m :=
  seedVarsAux m m (Nat.le_refl m)

theorem seedVarsAux_nodeAt (m : Nat) :
    ∀ (count : Nat) (hc : count ≤ m) (j : Fin count),
      nodeAt (seedVarsAux m count hc) j = .inVar j.val
  | 0, _, j => j.elim0
  | c + 1, hc, j => by
      simp only [seedVarsAux, nodeAt]
      split
      · rename_i hlt
        exact seedVarsAux_nodeAt m c (Nat.le_of_succ_le hc) ⟨j.val, hlt⟩
      · rename_i hge
        have hjeq : j.val = c := by omega
        simp [ValidNode.toRaw, hjeq]

theorem seedVars_eval {m : Nat} (ρ : List Rat) (j : Fin m) :
    evalValidTape ρ (seedVars m) j = ρ[j.val]? := by
  have hAux : ∀ (c : Nat) (hc : c ≤ m) (i : Fin c),
      evalValidTape ρ (seedVarsAux m c hc) i = ρ[i.val]? := by
    intro c
    induction c with
    | zero => intro _ i; exact i.elim0
    | succ c' ih =>
        intro hc i
        simp only [seedVarsAux, evalValidTape]
        split
        · rename_i hlt
          exact ih (Nat.le_of_succ_le hc) ⟨i.val, hlt⟩
        · rename_i hge
          have hieq : i.val = c' := by omega
          simp [evalNode, hieq]
  exact hAux m (Nat.le_refl m) j

theorem seedVars_unit {m : Nat} (Γ : VarCtxQ0) (j : Fin m) :
    synthUnitTape Γ (seedVars m) j = Γ[j.val]? := by
  have hAux : ∀ (c : Nat) (hc : c ≤ m) (i : Fin c),
      synthUnitTape Γ (seedVarsAux m c hc) i = Γ[i.val]? := by
    intro c
    induction c with
    | zero => intro _ i; exact i.elim0
    | succ c' ih =>
        intro hc i
        simp only [seedVarsAux, synthUnitTape]
        split
        · rename_i hlt
          exact ih (Nat.le_of_succ_le hc) ⟨i.val, hlt⟩
        · rename_i hge
          have hieq : i.val = c' := by omega
          simp [unitNode, hieq]
  exact hAux m (Nat.le_refl m) j

/-- Initial identity wire environment `[0, 1, ..., m - 1]` of length `m`. -/
def initWireEnv (m : Nat) : List (Fin m) :=
  List.ofFn (fun i : Fin m => i)

@[simp] theorem initWireEnv_length (m : Nat) : (initWireEnv m).length = m := by
  simp [initWireEnv]

@[simp] theorem initWireEnv_get (m : Nat) (i : Nat) (hi : i < m) :
    (initWireEnv m)[i]? = some ⟨i, hi⟩ := by
  simp [initWireEnv, hi]

/-- Structural AST-to-SSA lowering with explicit De Bruijn wire environment `env`. -/
def lowerAux {m : Nat} :
    (e : ExprQ0) → {k : Nat} → (vt : ValidTape m k) → (env : List (Fin k)) →
    wellScoped env.length e = true → LowerRes vt
  | .bvar i, k, vt, env, hw =>
      have hi : i < env.length := by simpa [wellScoped] using hw
      ⟨k, Nat.le_refl k, vt, env[i], TapePrefix.refl vt⟩
  | .ratLit q u, k, vt, _, _ =>
      let vt1 := vt.snoc (.constRat q u)
      ⟨k + 1, Nat.le_succ k, vt1, Fin.last k, TapePrefix.snoc_step vt _⟩
  | .unaryNeg a, _, vt, env, hw =>
      let ra := lowerAux a vt env hw
      let vt2 := ra.tape.snoc (.unaryNeg ra.root)
      ⟨ra.len + 1, Nat.le_trans ra.hle (Nat.le_succ ra.len), vt2, Fin.last ra.len,
       TapePrefix.trans ra.isPref (TapePrefix.snoc_step ra.tape _)⟩
  | .binOp op a b, _, vt, env, hw =>
      have hwa : wellScoped env.length a = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.1
      have hwb : wellScoped env.length b = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.2
      let ra := lowerAux a vt env hwa
      let env1 := env.map (Fin.castLE ra.hle)
      have hwb1 : wellScoped env1.length b = true := by
        simpa [env1] using hwb
      let rb := lowerAux b ra.tape env1 hwb1
      let ka' := Fin.castLE rb.hle ra.root
      let vt3 := rb.tape.snoc (.binOp op ka' rb.root)
      ⟨rb.len + 1,
       Nat.le_trans ra.hle (Nat.le_trans rb.hle (Nat.le_succ rb.len)),
       vt3,
       Fin.last rb.len,
       TapePrefix.trans ra.isPref
         (TapePrefix.trans rb.isPref (TapePrefix.snoc_step rb.tape _))⟩
  | .letBind v body, _, vt, env, hw =>
      have hwv : wellScoped env.length v = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.1
      have hwb : wellScoped (env.length + 1) body = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.2
      let rv := lowerAux v vt env hwv
      let env' : List (Fin rv.len) := rv.root :: env.map (Fin.castLE rv.hle)
      have hwb' : wellScoped env'.length body = true := by
        simpa [env'] using hwb
      let rb := lowerAux body rv.tape env' hwb'
      let kv' := Fin.castLE rb.hle rv.root
      let vt3 := rb.tape.snoc (.strictBind kv' rb.root)
      ⟨rb.len + 1,
       Nat.le_trans rv.hle (Nat.le_trans rb.hle (Nat.le_succ rb.len)),
       vt3,
       Fin.last rb.len,
       TapePrefix.trans rv.isPref
         (TapePrefix.trans rb.isPref (TapePrefix.snoc_step rb.tape _))⟩

/-- Top-level lowering `lowerExprTop` (`M1-P0 R3` §1.2). -/
def lowerExprTop (m : Nat) (e : ScopedExpr m) : RootedTape m :=
  let hw : wellScoped (initWireEnv m).length e.val = true := by
    simpa [initWireEnv_length] using e.property
  let res := lowerAux e.val (seedVars m) (initWireEnv m) hw
  ⟨res.len, res.tape, res.root⟩

/-! ### Target Obligation `PO-TAPE-DEPS` (`M1-P0 R2/R3` §1.2) -/

theorem po_tape_deps_letBind {m k : Nat} (vt : ValidTape m k) (env : List (Fin k))
    (v body : ExprQ0) (hw : wellScoped env.length (.letBind v body) = true) :
    let hwv : wellScoped env.length v = true :=
      (Bool.and_eq_true _ _).mp hw |>.1
    let hwb : wellScoped (env.length + 1) body = true :=
      (Bool.and_eq_true _ _).mp hw |>.2
    let rv := lowerAux v vt env hwv
    let env' := rv.root :: env.map (Fin.castLE rv.hle)
    let rb := lowerAux body rv.tape env' (by simpa [env'] using hwb)
    let rlet := lowerAux (.letBind v body) vt env hw
    ∀ x : Nat,
      x ∈ strictDeps rlet.tape rlet.root ↔
        x = rv.root.val ∨ x = rb.root.val ∨
        x ∈ strictDeps rv.tape rv.root ∨ x ∈ strictDeps rb.tape rb.root := by
  intro hwv hwb rv env' rb rlet x
  have hpres := (tapePrefix_preserves rb.hle rv.tape rb.tape rb.isPref rv.root).1
  change x ∈ strictDeps (rb.tape.snoc (.strictBind (Fin.castLE rb.hle rv.root) rb.root))
               (Fin.last rb.len) ↔ _
  rw [strictDeps_snoc_last]
  simp only [depsNode, List.mem_cons, List.mem_append, hpres]
  constructor
  · rintro (h1 | h2 | h3 | h4)
    · exact Or.inl h1
    · exact Or.inr (Or.inl h2)
    · exact Or.inr (Or.inr (Or.inl h3))
    · exact Or.inr (Or.inr (Or.inr h4))
  · rintro (h1 | h2 | h3 | h4)
    · exact Or.inl h1
    · exact Or.inr (Or.inl h2)
    · exact Or.inr (Or.inr (Or.inl h3))
    · exact Or.inr (Or.inr (Or.inr h4))

/-! ### Target Obligation `PO-TAPE-EQUIV` (`M1-P0 R2/R3` §1.2) -/

theorem lowerAux_eval_correct {m : Nat} :
    ∀ (e : ExprQ0) {k : Nat} (vt : ValidTape m k) (env : List (Fin k))
      (hw : wellScoped env.length e = true) (ρ_base ρ_ext : List Rat),
      ρ_ext.length = env.length →
      (∀ (j : Nat) (hj : j < env.length), evalValidTape ρ_base vt env[j] = ρ_ext[j]?) →
      evalValidTape ρ_base (lowerAux e vt env hw).tape (lowerAux e vt env hw).root =
        denoteExpr ρ_ext e
  | .bvar i, _, vt, env, hw, ρ_base, ρ_ext, _, henv => by
      have hi : i < env.length := by simpa [wellScoped] using hw
      simpa [lowerAux, denoteExpr] using henv i hi
  | .ratLit q u, _, vt, _, _, ρ_base, _, _, _ => by
      simp [lowerAux, denoteExpr, evalNode]
  | .unaryNeg a, _, vt, env, hw, ρ_base, ρ_ext, hlen, henv => by
      have iha := lowerAux_eval_correct a vt env hw ρ_base ρ_ext hlen henv
      simp only [lowerAux, denoteExpr, evalValidTape_snoc_last, evalNode, iha]
      cases denoteExpr ρ_ext a <;> rfl
  | .binOp op a b, _, vt, env, hw, ρ_base, ρ_ext, hlen, henv => by
      have hwa : wellScoped env.length a = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.1
      have hwb : wellScoped env.length b = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.2
      let ra := lowerAux a vt env hwa
      have iha : evalValidTape ρ_base ra.tape ra.root = denoteExpr ρ_ext a :=
        lowerAux_eval_correct a vt env hwa ρ_base ρ_ext hlen henv
      let env1 := env.map (Fin.castLE ra.hle)
      have henv1 : ∀ (j : Nat) (hj : j < env1.length),
          evalValidTape ρ_base ra.tape env1[j] = ρ_ext[j]? := by
        intro j hj
        have hj0 : j < env.length := by simpa [env1] using hj
        have hget : env1[j] = Fin.castLE ra.hle env[j] := by simp [env1]
        rw [hget, (tapePrefix_preserves ra.hle vt ra.tape ra.isPref env[j]).2.2.1 ρ_base]
        exact henv j hj0
      have hlen1 : ρ_ext.length = env1.length := by simpa [env1] using hlen
      have hwb1 : wellScoped env1.length b = true := by simpa [env1] using hwb
      let rb := lowerAux b ra.tape env1 hwb1
      have ihb : evalValidTape ρ_base rb.tape rb.root = denoteExpr ρ_ext b :=
        lowerAux_eval_correct b ra.tape env1 hwb1 ρ_base ρ_ext hlen1 henv1
      have hpres_a : evalValidTape ρ_base rb.tape (Fin.castLE rb.hle ra.root) =
          evalValidTape ρ_base ra.tape ra.root :=
        (tapePrefix_preserves rb.hle ra.tape rb.tape rb.isPref ra.root).2.2.1 ρ_base
      change evalValidTape ρ_base (rb.tape.snoc (.binOp op (Fin.castLE rb.hle ra.root) rb.root))
               (Fin.last rb.len) = denoteExpr ρ_ext (.binOp op a b)
      rw [evalValidTape_snoc_last]
      simp [evalNode, denoteExpr, hpres_a, iha, ihb]
  | .letBind v body, _, vt, env, hw, ρ_base, ρ_ext, hlen, henv => by
      have hwv : wellScoped env.length v = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.1
      have hwb : wellScoped (env.length + 1) body = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.2
      let rv := lowerAux v vt env hwv
      have ihv : evalValidTape ρ_base rv.tape rv.root = denoteExpr ρ_ext v :=
        lowerAux_eval_correct v vt env hwv ρ_base ρ_ext hlen henv
      let env' : List (Fin rv.len) := rv.root :: env.map (Fin.castLE rv.hle)
      have hwb' : wellScoped env'.length body = true := by simpa [env'] using hwb
      let rb := lowerAux body rv.tape env' hwb'
      have hpres_v : evalValidTape ρ_base rb.tape (Fin.castLE rb.hle rv.root) =
          evalValidTape ρ_base rv.tape rv.root :=
        (tapePrefix_preserves rb.hle rv.tape rb.tape rb.isPref rv.root).2.2.1 ρ_base
      change evalValidTape ρ_base (rb.tape.snoc (.strictBind (Fin.castLE rb.hle rv.root) rb.root))
               (Fin.last rb.len) = denoteExpr ρ_ext (.letBind v body)
      rw [evalValidTape_snoc_last]
      simp only [evalNode, denoteExpr, hpres_v, ihv]
      cases hv : denoteExpr ρ_ext v with
      | none => rfl
      | some val_v =>
          dsimp only
          have henv' : ∀ (j : Nat) (hj : j < env'.length),
              evalValidTape ρ_base rv.tape env'[j] = (val_v :: ρ_ext)[j]? := by
            intro j hj
            cases j with
            | zero =>
                simpa [env', ihv] using hv
            | succ j' =>
                have hj0 : j' < env.length := by simp [env'] at hj; omega
                have hget : env'[j' + 1] = Fin.castLE rv.hle env[j'] := by simp [env']
                rw [hget, (tapePrefix_preserves rv.hle vt rv.tape rv.isPref env[j']).2.2.1 ρ_base]
                simpa using henv j' hj0
          have hlen' : (val_v :: ρ_ext).length = env'.length := by simp [env', hlen]
          have ihb : evalValidTape ρ_base rb.tape rb.root = denoteExpr (val_v :: ρ_ext) body :=
            lowerAux_eval_correct body rv.tape env' hwb' ρ_base (val_v :: ρ_ext) hlen' henv'
          rw [ihb]
          cases denoteExpr (val_v :: ρ_ext) body <;> rfl

theorem lowerAux_unit_correct {m : Nat} :
    ∀ (e : ExprQ0) {k : Nat} (vt : ValidTape m k) (env : List (Fin k))
      (hw : wellScoped env.length e = true) (Γ_base Γ_ext : VarCtxQ0),
      Γ_ext.length = env.length →
      (∀ (j : Nat) (hj : j < env.length), synthUnitTape Γ_base vt env[j] = Γ_ext[j]?) →
      synthUnitTape Γ_base (lowerAux e vt env hw).tape (lowerAux e vt env hw).root =
        synthUnit Γ_ext e
  | .bvar i, _, vt, env, hw, Γ_base, Γ_ext, _, henv => by
      have hi : i < env.length := by simpa [wellScoped] using hw
      simpa [lowerAux, synthUnit] using henv i hi
  | .ratLit q u, _, vt, _, _, Γ_base, _, _, _ => by
      simp [lowerAux, synthUnit, unitNode]
  | .unaryNeg a, _, vt, env, hw, Γ_base, Γ_ext, hlen, henv => by
      have iha := lowerAux_unit_correct a vt env hw Γ_base Γ_ext hlen henv
      simp [lowerAux, synthUnit, unitNode, iha]
  | .binOp op a b, _, vt, env, hw, Γ_base, Γ_ext, hlen, henv => by
      have hwa : wellScoped env.length a = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.1
      have hwb : wellScoped env.length b = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.2
      let ra := lowerAux a vt env hwa
      have iha : synthUnitTape Γ_base ra.tape ra.root = synthUnit Γ_ext a :=
        lowerAux_unit_correct a vt env hwa Γ_base Γ_ext hlen henv
      let env1 := env.map (Fin.castLE ra.hle)
      have henv1 : ∀ (j : Nat) (hj : j < env1.length),
          synthUnitTape Γ_base ra.tape env1[j] = Γ_ext[j]? := by
        intro j hj
        have hj0 : j < env.length := by simpa [env1] using hj
        have hget : env1[j] = Fin.castLE ra.hle env[j] := by simp [env1]
        rw [hget, (tapePrefix_preserves ra.hle vt ra.tape ra.isPref env[j]).2.2.2 Γ_base]
        exact henv j hj0
      have hlen1 : Γ_ext.length = env1.length := by simpa [env1] using hlen
      have hwb1 : wellScoped env1.length b = true := by simpa [env1] using hwb
      let rb := lowerAux b ra.tape env1 hwb1
      have ihb : synthUnitTape Γ_base rb.tape rb.root = synthUnit Γ_ext b :=
        lowerAux_unit_correct b ra.tape env1 hwb1 Γ_base Γ_ext hlen1 henv1
      have hpres_a : synthUnitTape Γ_base rb.tape (Fin.castLE rb.hle ra.root) =
          synthUnitTape Γ_base ra.tape ra.root :=
        (tapePrefix_preserves rb.hle ra.tape rb.tape rb.isPref ra.root).2.2.2 Γ_base
      change synthUnitTape Γ_base (rb.tape.snoc (.binOp op (Fin.castLE rb.hle ra.root) rb.root))
               (Fin.last rb.len) = synthUnit Γ_ext (.binOp op a b)
      rw [synthUnitTape_snoc_last]
      simp only [unitNode, synthUnit, hpres_a, iha, ihb]
      cases synthUnit Γ_ext a <;> cases synthUnit Γ_ext b <;> rfl
  | .letBind v body, _, vt, env, hw, Γ_base, Γ_ext, hlen, henv => by
      have hwv : wellScoped env.length v = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.1
      have hwb : wellScoped (env.length + 1) body = true := by
        simp only [wellScoped, Bool.and_eq_true] at hw; exact hw.2
      let rv := lowerAux v vt env hwv
      have ihv : synthUnitTape Γ_base rv.tape rv.root = synthUnit Γ_ext v :=
        lowerAux_unit_correct v vt env hwv Γ_base Γ_ext hlen henv
      let env' : List (Fin rv.len) := rv.root :: env.map (Fin.castLE rv.hle)
      have hwb' : wellScoped env'.length body = true := by simpa [env'] using hwb
      let rb := lowerAux body rv.tape env' hwb'
      have hpres_v : synthUnitTape Γ_base rb.tape (Fin.castLE rb.hle rv.root) =
          synthUnitTape Γ_base rv.tape rv.root :=
        (tapePrefix_preserves rb.hle rv.tape rb.tape rb.isPref rv.root).2.2.2 Γ_base
      change synthUnitTape Γ_base (rb.tape.snoc (.strictBind (Fin.castLE rb.hle rv.root) rb.root))
               (Fin.last rb.len) = synthUnit Γ_ext (.letBind v body)
      rw [synthUnitTape_snoc_last]
      simp only [unitNode, synthUnit, hpres_v, ihv]
      cases hv : synthUnit Γ_ext v with
      | none => rfl
      | some uv =>
          dsimp only
          have henv' : ∀ (j : Nat) (hj : j < env'.length),
              synthUnitTape Γ_base rv.tape env'[j] = (uv :: Γ_ext)[j]? := by
            intro j hj
            cases j with
            | zero =>
                simpa [env', ihv] using hv
            | succ j' =>
                have hj0 : j' < env.length := by simp [env'] at hj; omega
                have hget : env'[j' + 1] = Fin.castLE rv.hle env[j'] := by simp [env']
                rw [hget, (tapePrefix_preserves rv.hle vt rv.tape rv.isPref env[j']).2.2.2 Γ_base]
                simpa using henv j' hj0
          have hlen' : (uv :: Γ_ext).length = env'.length := by simp [env', hlen]
          have ihb : synthUnitTape Γ_base rb.tape rb.root = synthUnit (uv :: Γ_ext) body :=
            lowerAux_unit_correct body rv.tape env' hwb' Γ_base (uv :: Γ_ext) hlen' henv'
          rw [ihb]
          cases synthUnit (uv :: Γ_ext) body <;> rfl

/-- Target Obligation `PO-TAPE-EQUIV` (`M1-P0 R2/R3` §1.2):
    Top-level lowering `lowerExprTop` preserves BOTH exact partial value semantics (`Option Rat`)
    and static physical unit synthesis (`Option UnitSpecQ0`), including unused strict `let` binders. -/
theorem po_tape_equiv {m : Nat} (e : ScopedExpr m) :
    (∀ ρ : List Rat, ρ.length = m →
      evalTapeRoot ρ (lowerExprTop m e) = denoteExpr ρ e.val) ∧
    (∀ Γ : VarCtxQ0, Γ.length = m →
      synthUnitTapeRoot Γ (lowerExprTop m e) = synthUnit Γ e.val) := by
  constructor
  · intro ρ hρ
    unfold evalTapeRoot lowerExprTop
    apply lowerAux_eval_correct e.val (seedVars m) (initWireEnv m) _ ρ ρ
    · simp [hρ]
    · intro j hj
      have hj_m : j < m := by simpa using hj
      have hget : (initWireEnv m)[j] = ⟨j, hj_m⟩ := by simp [initWireEnv]
      rw [hget, seedVars_eval ρ ⟨j, hj_m⟩]
  · intro Γ hΓ
    unfold synthUnitTapeRoot lowerExprTop
    apply lowerAux_unit_correct e.val (seedVars m) (initWireEnv m) _ Γ Γ
    · simp [hΓ]
    · intro j hj
      have hj_m : j < m := by simpa using hj
      have hget : (initWireEnv m)[j] = ⟨j, hj_m⟩ := by simp [initWireEnv]
      rw [hget, seedVars_unit Γ ⟨j, hj_m⟩]

end GrandZero.StageA
