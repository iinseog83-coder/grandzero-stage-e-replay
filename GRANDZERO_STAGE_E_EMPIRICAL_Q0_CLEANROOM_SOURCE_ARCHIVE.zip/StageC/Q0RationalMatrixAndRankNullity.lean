/-
  GRANDZERO Ω — Stage C (Finite Rational Cellular Sheaf & Global Consistency Gate)
  Module C-1: Q0RationalMatrixAndRankNullity.lean
  Scope:
    1. Dimension-indexed exact rational vectors `VecQ0 n` & matrices `MatQ0 m n`
       over pure Lean 4 `Init` (`0` external dependencies).
    2. Complete associative matrix-ring & transpose-dot laws (`matMul_assoc`,
       `matVec_matMul`, `dotVec_matVec_transpose`).
    3. Fredholm / Farkas Dual Non-Image Obstruction (`thm_dual_obstruction_not_in_image`).
    4. Whitebox Detached Rank-Nullity Certificate (`RankNullityCertQ0`,
       `thm_rank_nullity_cert_kernel_exact`, `thm_rank_nullity_cert_image_exact`)
       verifying exact kernel and image bases without trusting external RREF solvers.
-/

import StageB

namespace GrandZero.StageC

open GrandZero.StageA
open GrandZero.StageB

/-! ### Part 1: Finite Index Quantification & Summation over `Fin n` -/

abbrev VecQ0 (n : Nat) := Fin n → Rat
abbrev MatQ0 (m n : Nat) := Fin m → Fin n → Rat

/-- Computable universal quantifier over `Fin n`. -/
def allFin : (n : Nat) → (Fin n → Bool) → Bool
  | 0, _     => true
  | k + 1, p => p ⟨0, Nat.zero_lt_succ k⟩ && allFin k (fun i => p ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)

theorem allFin_iff :
    ∀ (n : Nat) (p : Fin n → Bool), allFin n p = true ↔ ∀ i : Fin n, p i = true
  | 0, _ => ⟨fun _ i => i.elim0, fun _ => rfl⟩
  | k + 1, p => by
      simp only [allFin, Bool.and_eq_true, allFin_iff k]
      constructor
      · rintro ⟨h0, hrest⟩ ⟨idx, hlt⟩
        cases idx with
        | zero => exact h0
        | succ j => exact hrest ⟨j, Nat.lt_of_succ_lt_succ hlt⟩
      · intro hall
        exact ⟨hall ⟨0, Nat.zero_lt_succ k⟩, fun i => hall ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩⟩

/-- Decidable vector equality over `VecQ0 n`. -/
def vecEqBool {n : Nat} (u v : VecQ0 n) : Bool :=
  allFin n (fun i => u i == v i)

theorem vecEqBool_iff {n : Nat} (u v : VecQ0 n) :
    vecEqBool u v = true ↔ u = v := by
  unfold vecEqBool
  rw [allFin_iff]
  constructor
  · intro h
    funext i
    exact beq_iff_eq.mp (h i)
  · intro h i
    subst h
    exact beq_self_eq_true (u i)

/-- Decidable matrix equality over `MatQ0 m n`. -/
def matEqBool {m n : Nat} (A B : MatQ0 m n) : Bool :=
  allFin m (fun i => allFin n (fun j => A i j == B i j))

theorem matEqBool_iff {m n : Nat} (A B : MatQ0 m n) :
    matEqBool A B = true ↔ A = B := by
  unfold matEqBool
  rw [allFin_iff]
  constructor
  · intro h
    funext i j
    have hi := (allFin_iff n _).mp (h i) j
    exact beq_iff_eq.mp hi
  · intro h i
    subst h
    rw [allFin_iff]
    intro j
    exact beq_self_eq_true (A i j)

/-- Exact finite rational sum `∑_{i : Fin n} f i`. -/
def finSum : (n : Nat) → (Fin n → Rat) → Rat
  | 0, _     => 0
  | k + 1, f => f ⟨0, Nat.zero_lt_succ k⟩ + finSum k (fun i => f ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)

theorem finSum_ext {n : Nat} {f g : Fin n → Rat} (h : ∀ i, f i = g i) :
    finSum n f = finSum n g := by
  have heq : f = g := funext h
  subst heq
  rfl

theorem finSum_zero : ∀ (n : Nat), finSum n (fun _ => 0) = 0
  | 0     => rfl
  | k + 1 => by simp [finSum, finSum_zero k, Rat.zero_add]

theorem finSum_add :
    ∀ (n : Nat) (f g : Fin n → Rat),
      finSum n (fun i => f i + g i) = finSum n f + finSum n g
  | 0, _, _     => by simp [finSum, Rat.zero_add]
  | k + 1, f, g => by
      simp only [finSum, finSum_add k]
      grind

theorem finSum_mul_left (c : Rat) :
    ∀ (n : Nat) (f : Fin n → Rat),
      c * finSum n f = finSum n (fun i => c * f i)
  | 0, _     => by simp [finSum, Rat.mul_zero]
  | k + 1, f => by
      simp only [finSum, ← finSum_mul_left c k]
      grind

theorem finSum_mul_right (c : Rat) :
    ∀ (n : Nat) (f : Fin n → Rat),
      finSum n f * c = finSum n (fun i => f i * c)
  | 0, _     => by simp [finSum, Rat.zero_mul]
  | k + 1, f => by
      simp only [finSum, ← finSum_mul_right c k]
      grind

theorem finSum_comm :
    ∀ (m n : Nat) (h : Fin m → Fin n → Rat),
      finSum m (fun i => finSum n (fun j => h i j)) =
        finSum n (fun j => finSum m (fun i => h i j))
  | 0, n, _ => by simp [finSum, finSum_zero n]
  | k + 1, n, h => by
      simp only [finSum, finSum_comm k n]
      rw [← finSum_add]

theorem finSum_delta_left :
    ∀ (n : Nat) (i₀ : Fin n) (f : Fin n → Rat),
      finSum n (fun j => (if i₀ = j then (1 : Rat) else 0) * f j) = f i₀
  | 0, i₀, _ => i₀.elim0
  | k + 1, ⟨0, hlt⟩, f => by
      simp only [finSum, ↓reduceIte, Rat.one_mul]
      have htail : finSum k (fun i : Fin k =>
          (if (⟨0, hlt⟩ : Fin (k + 1)) = ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩ then (1 : Rat) else 0) *
            f ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩) = 0 := by
        rw [finSum_ext (g := fun _ => 0)]
        · exact finSum_zero k
        · intro i
          simp [Rat.zero_mul]
      rw [htail, Rat.add_zero]
  | k + 1, ⟨idx + 1, hlt⟩, f => by
      simp only [finSum]
      have hne0 : (⟨idx + 1, hlt⟩ : Fin (k + 1)) ≠ ⟨0, Nat.zero_lt_succ k⟩ := by
        intro heq
        have hv := congrArg Fin.val heq
        simp at hv
      simp only [if_neg hne0, Rat.zero_mul, Rat.zero_add]
      let i' : Fin k := ⟨idx, Nat.lt_of_succ_lt_succ hlt⟩
      have hmatch : ∀ j : Fin k,
          ((⟨idx + 1, hlt⟩ : Fin (k + 1)) = ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩) ↔ (i' = j) := by
        intro j
        constructor
        · intro heq
          apply Fin.ext
          have hv := congrArg Fin.val heq
          dsimp [i'] at hv ⊢
          omega
        · intro heq
          apply Fin.ext
          have hv := congrArg Fin.val heq
          dsimp [i'] at hv ⊢
          omega
      have hrew : finSum k (fun j : Fin k =>
          (if (⟨idx + 1, hlt⟩ : Fin (k + 1)) = ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩ then (1 : Rat) else 0) *
            f ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩) =
          finSum k (fun j : Fin k => (if i' = j then (1 : Rat) else 0) * f ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩) := by
        apply finSum_ext
        intro j
        by_cases hij : i' = j
        · have h1 := (hmatch j).mpr hij
          simp [hij, h1]
        · have h1 : ¬ ((⟨idx + 1, hlt⟩ : Fin (k + 1)) = ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩) :=
            fun hc => hij ((hmatch j).mp hc)
          simp [hij, h1]
      rw [hrew, finSum_delta_left k i' (fun j => f ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩)]

theorem finSum_delta_right (n : Nat) (j₀ : Fin n) (f : Fin n → Rat) :
    finSum n (fun i => f i * (if i = j₀ then (1 : Rat) else 0)) = f j₀ := by
  have heq : finSum n (fun i => f i * (if i = j₀ then (1 : Rat) else 0)) =
      finSum n (fun i => (if j₀ = i then (1 : Rat) else 0) * f i) := by
    apply finSum_ext
    intro i
    by_cases h : i = j₀
    · subst h; simp [Rat.mul_one, Rat.one_mul]
    · have h' : ¬ (j₀ = i) := fun hc => h hc.symm
      simp [h, h', Rat.mul_zero, Rat.zero_mul]
  rw [heq, finSum_delta_left]

/-! ### Part 2: Vector & Matrix Operations and Ring/Module Laws -/

def zeroVec (n : Nat) : VecQ0 n := fun _ => 0
def addVec {n : Nat} (u v : VecQ0 n) : VecQ0 n := fun i => u i + v i
def subVec {n : Nat} (u v : VecQ0 n) : VecQ0 n := fun i => u i - v i
def scaleVec {n : Nat} (c : Rat) (v : VecQ0 n) : VecQ0 n := fun i => c * v i
def dotVec {n : Nat} (u v : VecQ0 n) : Rat := finSum n (fun i => u i * v i)

def vecOfList (n : Nat) (xs : List Rat) : VecQ0 n :=
  fun i => xs.getD i.val 0

def vecToList : {n : Nat} → VecQ0 n → List Rat
  | 0, _     => []
  | k + 1, v => v ⟨0, Nat.zero_lt_succ k⟩ :: vecToList (fun i => v ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)

theorem vecToList_length : ∀ {n : Nat} (v : VecQ0 n), (vecToList v).length = n
  | 0, _     => rfl
  | k + 1, v => by simp [vecToList, vecToList_length]

theorem vecToList_getElem :
    ∀ {n : Nat} (v : VecQ0 n) (i : Fin n), (vecToList v)[i.val]? = some (v i)
  | 0, _, i => i.elim0
  | k + 1, v, ⟨0, _⟩ => rfl
  | k + 1, v, ⟨idx + 1, hlt⟩ => by
      simp only [vecToList, List.getElem?_cons_succ]
      exact vecToList_getElem (fun j => v ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩)
        ⟨idx, Nat.lt_of_succ_lt_succ hlt⟩

def zeroMat (m n : Nat) : MatQ0 m n := fun _ _ => 0
def idMat (n : Nat) : MatQ0 n n := fun i j => if i = j then 1 else 0
def addMat {m n : Nat} (A B : MatQ0 m n) : MatQ0 m n := fun i j => A i j + B i j
def subMat {m n : Nat} (A B : MatQ0 m n) : MatQ0 m n := fun i j => A i j - B i j
def transposeMat {m n : Nat} (M : MatQ0 m n) : MatQ0 n m := fun j i => M i j

def matVec {m n : Nat} (M : MatQ0 m n) (x : VecQ0 n) : VecQ0 m :=
  fun i => finSum n (fun j => M i j * x j)

def matMul {m k n : Nat} (A : MatQ0 m k) (B : MatQ0 k n) : MatQ0 m n :=
  fun i j => finSum k (fun s => A i s * B s j)

def matOfLists (m n : Nat) (rows : List (List Rat)) : MatQ0 m n :=
  fun i j => (rows.getD i.val []).getD j.val 0

/-- Horizontal block concatenation `[A | B] ∈ ℚ^{m × (n1 + n2)}`. -/
def hcatMat {m n1 n2 : Nat} (A : MatQ0 m n1) (B : MatQ0 m n2) : MatQ0 m (n1 + n2) :=
  fun i j =>
    if h : j.val < n1 then A i ⟨j.val, h⟩
    else B i ⟨j.val - n1, by omega⟩

/-- Vertical block concatenation `[A ; B] ∈ ℚ^{(m1 + m2) × n}`. -/
def vcatMat {m1 m2 n : Nat} (A : MatQ0 m1 n) (B : MatQ0 m2 n) : MatQ0 (m1 + m2) n :=
  fun i j =>
    if h : i.val < m1 then A ⟨i.val, h⟩ j
    else B ⟨i.val - m1, by omega⟩ j

/-- Vertical vector concatenation `[u ; v] ∈ ℚ^{n1 + n2}`. -/
def vcatVec {n1 n2 : Nat} (u : VecQ0 n1) (v : VecQ0 n2) : VecQ0 (n1 + n2) :=
  fun i =>
    if h : i.val < n1 then u ⟨i.val, h⟩
    else v ⟨i.val - n1, by omega⟩

@[simp] theorem matVec_zero {m n : Nat} (M : MatQ0 m n) :
    matVec M (zeroVec n) = zeroVec m := by
  funext i
  unfold matVec zeroVec
  rw [finSum_ext (g := fun _ => 0)]
  · exact finSum_zero n
  · intro j; exact Rat.mul_zero (M i j)

@[simp] theorem zeroMat_vec {m n : Nat} (x : VecQ0 n) :
    matVec (zeroMat m n) x = zeroVec m := by
  funext i
  unfold matVec zeroMat zeroVec
  rw [finSum_ext (g := fun _ => 0)]
  · exact finSum_zero n
  · intro j; exact Rat.zero_mul (x j)

@[simp] theorem idMat_vec {n : Nat} (x : VecQ0 n) :
    matVec (idMat n) x = x := by
  funext i
  exact finSum_delta_left n i x

theorem addVec_zero_left {n : Nat} (v : VecQ0 n) : addVec (zeroVec n) v = v := by
  funext i; simp [addVec, zeroVec, Rat.zero_add]

theorem addVec_zero_right {n : Nat} (v : VecQ0 n) : addVec v (zeroVec n) = v := by
  funext i; simp [addVec, zeroVec, Rat.add_zero]

theorem matVec_add {m n : Nat} (M : MatQ0 m n) (x y : VecQ0 n) :
    matVec M (addVec x y) = addVec (matVec M x) (matVec M y) := by
  funext i
  unfold matVec addVec
  rw [← finSum_add]
  apply finSum_ext
  intro j
  grind

theorem addMat_vec {m n : Nat} (A B : MatQ0 m n) (x : VecQ0 n) :
    matVec (addMat A B) x = addVec (matVec A x) (matVec B x) := by
  funext i
  unfold matVec addMat addVec
  rw [← finSum_add]
  apply finSum_ext
  intro j
  grind

theorem matVec_matMul {m k n : Nat} (A : MatQ0 m k) (B : MatQ0 k n) (x : VecQ0 n) :
    matVec (matMul A B) x = matVec A (matVec B x) := by
  funext i
  unfold matVec matMul
  calc
    finSum n (fun j => finSum k (fun s => A i s * B s j) * x j)
        = finSum n (fun j => finSum k (fun s => (A i s * B s j) * x j)) := by
            apply finSum_ext; intro j; exact finSum_mul_right (x j) k _
    _ = finSum k (fun s => finSum n (fun j => (A i s * B s j) * x j)) :=
            finSum_comm n k _
    _ = finSum k (fun s => finSum n (fun j => A i s * (B s j * x j))) := by
            apply finSum_ext; intro s; apply finSum_ext; intro j; rw [Rat.mul_assoc]
    _ = finSum k (fun s => A i s * finSum n (fun j => B s j * x j)) := by
            apply finSum_ext; intro s; exact (finSum_mul_left (A i s) n _).symm

theorem matMul_assoc {m k l n : Nat} (A : MatQ0 m k) (B : MatQ0 k l) (C : MatQ0 l n) :
    matMul (matMul A B) C = matMul A (matMul B C) := by
  funext i j
  change matVec (matMul A B) (fun r => C r j) i = matVec A (matVec B (fun r => C r j)) i
  rw [matVec_matMul]

@[simp] theorem matMul_id_left {m n : Nat} (A : MatQ0 m n) :
    matMul (idMat m) A = A := by
  funext i j
  exact finSum_delta_left m i (fun s => A s j)

@[simp] theorem matMul_id_right {m n : Nat} (A : MatQ0 m n) :
    matMul A (idMat n) = A := by
  funext i j
  exact finSum_delta_right n j (fun s => A i s)

@[simp] theorem matMul_zero_right {m k n : Nat} (A : MatQ0 m k) :
    matMul A (zeroMat k n) = zeroMat m n := by
  funext i j
  unfold matMul zeroMat
  rw [finSum_ext (g := fun _ => 0)]
  · exact finSum_zero k
  · intro s; exact Rat.mul_zero (A i s)

@[simp] theorem matMul_zero_left {m k n : Nat} (B : MatQ0 k n) :
    matMul (zeroMat m k) B = zeroMat m n := by
  funext i j
  unfold matMul zeroMat
  rw [finSum_ext (g := fun _ => 0)]
  · exact finSum_zero k
  · intro s; exact Rat.zero_mul (B s j)

theorem matMul_add_right {m k n : Nat} (A : MatQ0 m k) (B C : MatQ0 k n) :
    matMul A (addMat B C) = addMat (matMul A B) (matMul A C) := by
  funext i j
  change matVec A (addVec (fun s => B s j) (fun s => C s j)) i =
    addVec (matVec A (fun s => B s j)) (matVec A (fun s => C s j)) i
  rw [matVec_add]

theorem matMul_add_left {m k n : Nat} (A B : MatQ0 m k) (C : MatQ0 k n) :
    matMul (addMat A B) C = addMat (matMul A C) (matMul B C) := by
  funext i j
  change matVec (addMat A B) (fun s => C s j) i =
    addVec (matVec A (fun s => C s j)) (matVec B (fun s => C s j)) i
  rw [addMat_vec]

@[simp] theorem dotVec_zero_left {n : Nat} (x : VecQ0 n) :
    dotVec (zeroVec n) x = 0 := by
  unfold dotVec zeroVec
  rw [finSum_ext (g := fun _ => 0)]
  · exact finSum_zero n
  · intro i; exact Rat.zero_mul (x i)

/-- Transpose Adjointness Law: `⟨y, M x⟩ = ⟨Mᵀ y, x⟩`. -/
theorem dotVec_matVec_transpose {m n : Nat} (M : MatQ0 m n) (y : VecQ0 m) (x : VecQ0 n) :
    dotVec y (matVec M x) = dotVec (matVec (transposeMat M) y) x := by
  unfold dotVec matVec transposeMat
  calc
    finSum m (fun i => y i * finSum n (fun j => M i j * x j))
        = finSum m (fun i => finSum n (fun j => y i * (M i j * x j))) := by
            apply finSum_ext; intro i; exact finSum_mul_left (y i) n _
    _ = finSum n (fun j => finSum m (fun i => y i * (M i j * x j))) :=
            finSum_comm m n _
    _ = finSum n (fun j => finSum m (fun i => (M i j * y i) * x j)) := by
            apply finSum_ext; intro j; apply finSum_ext; intro i; grind
    _ = finSum n (fun j => finSum m (fun i => M i j * y i) * x j) := by
            apply finSum_ext; intro j; exact (finSum_mul_right (x j) m _).symm

/-! ### Part 3: Fredholm / Farkas Dual Obstruction (`thm_dual_obstruction_not_in_image`) -/

/-- Computable dual obstruction check: `Mᵀ y == 0 && ⟨y, η⟩ != 0`. -/
def checkDualObstruction {m n : Nat} (M : MatQ0 m n) (η : VecQ0 m) (y : VecQ0 m) : Bool :=
  vecEqBool (matVec (transposeMat M) y) (zeroVec n) &&
  decide (dotVec y η ≠ 0)

/-- Target Theorem `thm_dual_obstruction_not_in_image`:
    Whenever `Mᵀ y = 0` and `⟨y, η⟩ ≠ 0`, NO rational vector `x ∈ ℚ^n` satisfies `M x = η`. -/
theorem thm_dual_obstruction_not_in_image {m n : Nat}
    (M : MatQ0 m n) (η y : VecQ0 m)
    (hchk : checkDualObstruction M η y = true) :
    ∀ x : VecQ0 n, matVec M x ≠ η := by
  unfold checkDualObstruction at hchk
  simp only [Bool.and_eq_true, vecEqBool_iff, decide_eq_true_eq] at hchk
  rcases hchk with ⟨hty, hdot_nz⟩
  intro x hMx
  have h1 : dotVec y η = dotVec y (matVec M x) := by rw [hMx]
  rw [dotVec_matVec_transpose, hty, dotVec_zero_left] at h1
  exact hdot_nz h1

/-! ### Part 4: Whitebox Detached Rank-Nullity Certificate (`RankNullityCertQ0`) -/

/-- Whitebox Rank-Nullity Decomposition Certificate for `M : MatQ0 m n`:
    `B ∈ ℚ^{m × r}` certifies an independent basis of `im(M)`,
    `K ∈ ℚ^{n × k}` certifies an independent basis of `ker(M)`,
    and `U L M + K R = I_n` certifies completeness without trusting any external solver. -/
structure RankNullityCertQ0 (m n : Nat) where
  r : Nat
  k : Nat
  U : MatQ0 n r
  B : MatQ0 m r
  L : MatQ0 r m
  K : MatQ0 n k
  R : MatQ0 k n

def checkRankNullityCert {m n : Nat} (M : MatQ0 m n) (c : RankNullityCertQ0 m n) : Bool :=
  decide (c.r + c.k = n) &&
  matEqBool (matMul M c.K) (zeroMat m c.k) &&
  matEqBool (matMul M c.U) c.B &&
  matEqBool (matMul c.L c.B) (idMat c.r) &&
  matEqBool (matMul c.R c.K) (idMat c.k) &&
  matEqBool (addMat (matMul c.U (matMul c.L M)) (matMul c.K c.R)) (idMat n)

/-- Target Theorem `thm_rank_nullity_cert_kernel_exact`:
    An accepted `RankNullityCertQ0` certifies that `c.K` is an exact, linearly independent
    basis of `ker(M)`:
      1. `r + k = n`,
      2. `∀ α, M (K α) = 0`,
      3. `∀ α, K α = 0 → α = 0` (linear independence),
      4. `∀ x, M x = 0 → x = K (R x)` (spanning of `ker(M)`). -/
theorem thm_rank_nullity_cert_kernel_exact {m n : Nat}
    (M : MatQ0 m n) (c : RankNullityCertQ0 m n)
    (hchk : checkRankNullityCert M c = true) :
    c.r + c.k = n ∧
    (∀ α : VecQ0 c.k, matVec M (matVec c.K α) = zeroVec m) ∧
    (∀ α : VecQ0 c.k, matVec c.K α = zeroVec n → α = zeroVec c.k) ∧
    (∀ x : VecQ0 n, matVec M x = zeroVec m → x = matVec c.K (matVec c.R x)) := by
  unfold checkRankNullityCert at hchk
  simp only [Bool.and_eq_true, decide_eq_true_eq, matEqBool_iff] at hchk
  rcases hchk with ⟨⟨⟨⟨⟨hdim, hMK⟩, _⟩, _⟩, hRK⟩, hpart⟩
  refine ⟨hdim, ?_, ?_, ?_⟩
  · intro α
    rw [← matVec_matMul, hMK, zeroMat_vec]
  · intro α hKα
    calc
      α = matVec (idMat c.k) α := (idMat_vec α).symm
      _ = matVec (matMul c.R c.K) α := by rw [hRK]
      _ = matVec c.R (matVec c.K α) := matVec_matMul c.R c.K α
      _ = matVec c.R (zeroVec n) := by rw [hKα]
      _ = zeroVec c.k := matVec_zero c.R
  · intro x hMx
    calc
      x = matVec (idMat n) x := (idMat_vec x).symm
      _ = matVec (addMat (matMul c.U (matMul c.L M)) (matMul c.K c.R)) x := by rw [← hpart]
      _ = addVec (matVec (matMul c.U (matMul c.L M)) x) (matVec (matMul c.K c.R) x) :=
            addMat_vec _ _ x
      _ = addVec (matVec c.U (matVec c.L (matVec M x))) (matVec c.K (matVec c.R x)) := by
            rw [matVec_matMul, matVec_matMul, matVec_matMul]
      _ = addVec (matVec c.U (matVec c.L (zeroVec m))) (matVec c.K (matVec c.R x)) := by
            rw [hMx]
      _ = matVec c.K (matVec c.R x) := by
            rw [matVec_zero, matVec_zero, addVec_zero_left]

/-- Target Theorem `thm_rank_nullity_cert_image_exact`:
    An accepted `RankNullityCertQ0` certifies that `c.B` is an exact, linearly independent
    basis of `im(M)` and `U L` is a generalized inverse projector onto `im(M)`:
      1. `∀ β, B β = M (U β)`,
      2. `∀ β, B β = 0 → β = 0` (linear independence of `B`),
      3. `∀ η, (∃ x, M x = η) ↔ M (U (L η)) = η`. -/
theorem thm_rank_nullity_cert_image_exact {m n : Nat}
    (M : MatQ0 m n) (c : RankNullityCertQ0 m n)
    (hchk : checkRankNullityCert M c = true) :
    (∀ β : VecQ0 c.r, matVec c.B β = matVec M (matVec c.U β)) ∧
    (∀ β : VecQ0 c.r, matVec c.B β = zeroVec m → β = zeroVec c.r) ∧
    (∀ η : VecQ0 m, (∃ x : VecQ0 n, matVec M x = η) ↔ matVec M (matVec c.U (matVec c.L η)) = η) := by
  unfold checkRankNullityCert at hchk
  simp only [Bool.and_eq_true, decide_eq_true_eq, matEqBool_iff] at hchk
  rcases hchk with ⟨⟨⟨⟨⟨_, hMK⟩, hMU⟩, hLB⟩, _⟩, hpart⟩
  refine ⟨?_, ?_, ?_⟩
  · intro β
    rw [← hMU, matVec_matMul]
  · intro β hBβ
    calc
      β = matVec (idMat c.r) β := (idMat_vec β).symm
      _ = matVec (matMul c.L c.B) β := by rw [hLB]
      _ = matVec c.L (matVec c.B β) := matVec_matMul c.L c.B β
      _ = matVec c.L (zeroVec m) := by rw [hBβ]
      _ = zeroVec c.r := matVec_zero c.L
  · intro η
    constructor
    · rintro ⟨x, rfl⟩
      have hMx : matVec M x = matVec M (matVec (idMat n) x) := by rw [idMat_vec]
      rw [← hpart, addMat_vec, matVec_add] at hMx
      have hMK0 : matVec M (matVec (matMul c.K c.R) x) = zeroVec m := by
        rw [matVec_matMul, ← matVec_matMul M c.K, hMK, zeroMat_vec]
      rw [hMK0, addVec_zero_right, matVec_matMul, matVec_matMul] at hMx
      exact hMx.symm
    · intro hproj
      exact ⟨matVec c.U (matVec c.L η), hproj⟩

end GrandZero.StageC
