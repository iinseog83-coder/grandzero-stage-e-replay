/-
  GRANDZERO Ω — Stage C (Finite Rational Cellular Sheaf & Global Consistency Gate)
  Module C-2: Q0CellularComplexAndSheaf.lean
  Scope:
    1. Finite 2-dimensional cell complexes & unit-typed rational cellular sheaves
       `CellularSheafQ0` binding per-vertex `StageB.ContextQ0`, `StageA.UnitSpecQ0`,
       and 3D `AuthorityVecQ0`.
    2. Explicit 3-tier separation required by `Tribunal Condition A`:
         - Step 1: Topological boundary nilpotence `∂₁ ∂₂ = 0` (`.boundaryNotNilpotent`)
         - Step 2: Static `UnitSpecQ0` (`DimVec7` + `KindTagQ0`) stalk & matrix check (`.illTypedStalkOrMatrix`)
         - Step 3: Sheaf face-vertex flag functoriality `ρ_{e1≼f} ∘ ρ_{v≼e1} = ρ_{e2≼f} ∘ ρ_{v≼e2}`
                   (`.nonFunctorialSheafRestriction`)
         - Step 4: Assembled coboundary nilpotence `δ¹ δ⁰ = 0` (`.cochainNotNilpotent`)
         - Step 5: 3D Authority Global Lattice Meet non-escalation (`.authorityEscalation`)
    3. Core soundness theorems `thm_sheaf_flag_functorial_sound`, `thm_cochain_nilpotent_sound`,
       and `thm_stageC_global_authority_meet_nonescalation`.
-/

import StageC.Q0RationalMatrixAndRankNullity

namespace GrandZero.StageC

open GrandZero.StageA
open GrandZero.StageB

/-! ### Part 1: Flattened Block-Index Decoding & Encoding for Variable-Dimension Stalks -/

/-- Sum of stalk dimensions across `m` cells. -/
def sumFinNat : (m : Nat) → (Fin m → Nat) → Nat
  | 0, _     => 0
  | k + 1, d => d ⟨0, Nat.zero_lt_succ k⟩ + sumFinNat k (fun i => d ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)

/-- Decode a flattened cochain coordinate `I : Fin (sumFinNat m d)` into `(cell, localCoord)`. -/
def decodeBlockIdx : (m : Nat) → (d : Fin m → Nat) → Fin (sumFinNat m d) → Σ (c : Fin m), Fin (d c)
  | 0, _, idx => idx.elim0
  | k + 1, d, idx =>
      let d0 := d ⟨0, Nat.zero_lt_succ k⟩
      if h : idx.val < d0 then
        ⟨⟨0, Nat.zero_lt_succ k⟩, ⟨idx.val, h⟩⟩
      else
        let sub := decodeBlockIdx k (fun i => d ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
          ⟨idx.val - d0, by
            have hlt := idx.isLt
            simp only [sumFinNat] at hlt
            omega⟩
        ⟨⟨sub.1.val + 1, Nat.succ_lt_succ sub.1.isLt⟩, sub.2⟩

/-- Starting offset of cell `c` inside `sumFinNat m d`. -/
def blockOffset : (m : Nat) → (d : Fin m → Nat) → Fin m → Nat
  | 0, _, c => c.elim0
  | _ + 1, _, ⟨0, _⟩ => 0
  | k + 1, d, ⟨idx + 1, hlt⟩ =>
      d ⟨0, Nat.zero_lt_succ k⟩ +
      blockOffset k (fun i => d ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩) ⟨idx, Nat.lt_of_succ_lt_succ hlt⟩

theorem blockOffset_add_lt :
    ∀ (m : Nat) (d : Fin m → Nat) (c : Fin m) (j : Fin (d c)),
      blockOffset m d c + j.val < sumFinNat m d
  | 0, _, c, _ => c.elim0
  | k + 1, d, ⟨0, hlt⟩, j => by
      simp only [blockOffset, sumFinNat, Nat.zero_add]
      have hj := j.isLt
      omega
  | k + 1, d, ⟨idx + 1, hlt⟩, j => by
      simp only [blockOffset, sumFinNat]
      have ih := blockOffset_add_lt k (fun i => d ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
        ⟨idx, Nat.lt_of_succ_lt_succ hlt⟩ j
      omega

/-- Encode `(cell, localCoord)` into a flattened index `Fin (sumFinNat m d)`. -/
def encodeBlockIdx (m : Nat) (d : Fin m → Nat) (c : Fin m) (j : Fin (d c)) : Fin (sumFinNat m d) :=
  ⟨blockOffset m d c + j.val, blockOffset_add_lt m d c j⟩

/-! ### Part 2: Unit-Typed Finite 2D `CellularSheafQ0` & Static Structural Checks -/

/-- Fine-grained invalid-complex / invalid-sheaf diagnostic reason (`Tribunal Condition C` Steps 1–5). -/
inductive StageCInvalidReasonQ0 where
  | boundaryNotNilpotent          : StageCInvalidReasonQ0
  | illTypedStalkOrMatrix         : StageCInvalidReasonQ0
  | nonFunctorialSheafRestriction : StageCInvalidReasonQ0
  | cochainNotNilpotent           : StageCInvalidReasonQ0
  | authorityEscalation           : StageCInvalidReasonQ0
  deriving DecidableEq, Repr, Inhabited

/-- Unit-typed finite 2D cellular sheaf over `X = (V, E, F)` with per-vertex semi-algebraic
    `ContextQ0` and 3D `AuthorityVecQ0` annotations. -/
structure CellularSheafQ0 where
  nV       : Nat
  nE       : Nat
  nF       : Nat
  vCtx     : Fin nV → ContextQ0
  eVars    : Fin nE → VarCtxQ0
  fVars    : Fin nF → VarCtxQ0
  incVE    : MatQ0 nV nE
  incEF    : MatQ0 nE nF
  resVE    : (v : Fin nV) → (e : Fin nE) → MatQ0 (eVars e).length (vCtx v).vars.length
  unitVE   : (v : Fin nV) → (e : Fin nE) → Fin (eVars e).length → Fin (vCtx v).vars.length → UnitSpecQ0
  resEF    : (e : Fin nE) → (f : Fin nF) → MatQ0 (fVars f).length (eVars e).length
  unitEF   : (e : Fin nE) → (f : Fin nF) → Fin (fVars f).length → Fin (eVars e).length → UnitSpecQ0
  vAuth    : Fin nV → AuthorityVecQ0
  eAuth    : Fin nE → AuthorityVecQ0
  claimedGlobalAuth : AuthorityVecQ0

namespace CellularSheafQ0

def dV (S : CellularSheafQ0) (v : Fin S.nV) : Nat := (S.vCtx v).vars.length
def dE (S : CellularSheafQ0) (e : Fin S.nE) : Nat := (S.eVars e).length
def dF (S : CellularSheafQ0) (f : Fin S.nF) : Nat := (S.fVars f).length

def N0 (S : CellularSheafQ0) : Nat := sumFinNat S.nV S.dV
def N1 (S : CellularSheafQ0) : Nat := sumFinNat S.nE S.dE
def N2 (S : CellularSheafQ0) : Nat := sumFinNat S.nF S.dF

end CellularSheafQ0

/-- Extract the local rational assignment `x_v : List Rat` at vertex `v` from global `x ∈ C⁰`. -/
def extractVertexVec (S : CellularSheafQ0) (x : VecQ0 S.N0) (v : Fin S.nV) : VecQ0 (S.dV v) :=
  fun j => x (encodeBlockIdx S.nV S.dV v j)

def extractVertexList (S : CellularSheafQ0) (x : VecQ0 S.N0) (v : Fin S.nV) : List Rat :=
  vecToList (extractVertexVec S x v)

theorem extractVertexList_length (S : CellularSheafQ0) (x : VecQ0 S.N0) (v : Fin S.nV) :
    (extractVertexList S x v).length = (S.vCtx v).vars.length :=
  vecToList_length (extractVertexVec S x v)

/-- Assemble flattened coboundary matrix `δ⁰ : C⁰ → C¹` (`MatQ0 S.N1 S.N0`). -/
def assembleDelta0 (S : CellularSheafQ0) : MatQ0 S.N1 S.N0 :=
  fun I J =>
    let ⟨e, i_e⟩ := decodeBlockIdx S.nE S.dE I
    let ⟨v, j_v⟩ := decodeBlockIdx S.nV S.dV J
    S.incVE v e * S.resVE v e i_e j_v

/-- Assemble flattened coboundary matrix `δ¹ : C¹ → C²` (`MatQ0 S.N2 S.N1`). -/
def assembleDelta1 (S : CellularSheafQ0) : MatQ0 S.N2 S.N1 :=
  fun I J =>
    let ⟨f, i_f⟩ := decodeBlockIdx S.nF S.dF I
    let ⟨e, j_e⟩ := decodeBlockIdx S.nE S.dE J
    S.incEF e f * S.resEF e f i_f j_e

/-! ### Part 3: Five-Step Ordered Structural Validator (`Tribunal Conditions A & C`) -/

/-- Step 1: Topological boundary nilpotence `∂₁ ∂₂ = 0`. -/
def checkBoundaryNilpotent (S : CellularSheafQ0) : Bool :=
  matEqBool (matMul S.incVE S.incEF) (zeroMat S.nV S.nF)

/-- Helper: check unit compatibility of all non-zero entries of a restriction matrix. -/
def checkRestrictionMatrixUnits
    (srcVars dstVars : VarCtxQ0)
    (M : MatQ0 dstVars.length srcVars.length)
    (W : Fin dstVars.length → Fin srcVars.length → UnitSpecQ0) : Bool :=
  allFin dstVars.length fun i =>
    allFin srcVars.length fun j =>
      if M i j == 0 then true
      else
        match dstVars[i.val]?, srcVars[j.val]? with
        | some u_dst, some u_src => synthBinOpUnit .mul (W i j) u_src == some u_dst
        | _, _ => false

/-- Step 2: Vertex context well-typedness & `UnitSpecQ0` (`DimVec7` + `KindTagQ0`) matrix check. -/
def checkSheafUnitsAndContexts (S : CellularSheafQ0) : Bool :=
  (allFin S.nV fun v => wellTypedContext (S.vCtx v)) &&
  (allFin S.nV fun v =>
    allFin S.nE fun e =>
      if S.incVE v e == 0 then true
      else checkRestrictionMatrixUnits (S.vCtx v).vars (S.eVars e) (S.resVE v e) (S.unitVE v e)) &&
  (allFin S.nE fun e =>
    allFin S.nF fun f =>
      if S.incEF e f == 0 then true
      else checkRestrictionMatrixUnits (S.eVars e) (S.fVars f) (S.resEF e f) (S.unitEF e f))

/-- Step 3 (`Condition A`): Face-vertex diamond functoriality:
    For every vertex `v`, face `f`, and opposing incident boundary edges `e1, e2`
    (`incVE v e1 * incEF e1 f ≠ 0` and `incVE v e1 * incEF e1 f + incVE v e2 * incEF e2 f = 0`),
    the composite restriction maps commute: `ρ_{e1≼f} ∘ ρ_{v≼e1} = ρ_{e2≼f} ∘ ρ_{v≼e2}`. -/
def checkSheafFlagFunctoriality (S : CellularSheafQ0) : Bool :=
  allFin S.nV fun v =>
    allFin S.nF fun f =>
      allFin S.nE fun e1 =>
        allFin S.nE fun e2 =>
          if S.incVE v e1 * S.incEF e1 f != 0 &&
             S.incVE v e1 * S.incEF e1 f + S.incVE v e2 * S.incEF e2 f == 0 then
            matEqBool (matMul (S.resEF e1 f) (S.resVE v e1))
                      (matMul (S.resEF e2 f) (S.resVE v e2))
          else true

/-- Step 4: Assembled cochain nilpotence `δ¹ ∘ δ⁰ = 0`. -/
def checkCochainNilpotent (S : CellularSheafQ0) : Bool :=
  matEqBool (matMul (assembleDelta1 S) (assembleDelta0 S)) (zeroMat S.N2 S.N0)

/-- Step 5: Global 3D Authority Meet non-escalation (`∀ v, A_global ≼ A_v` and `∀ e, A_global ≼ A_e`). -/
def checkGlobalAuthorityMeet (S : CellularSheafQ0) : Bool :=
  (allFin S.nV fun v => checkAuthorityLe S.claimedGlobalAuth (S.vAuth v)) &&
  (allFin S.nE fun e => checkAuthorityLe S.claimedGlobalAuth (S.eAuth e))

/-- Deterministic 5-step structural validator returning `none` iff valid, or `some reason`
    in exact `Condition C` precedence order. -/
def validateSheafComplexStructure (S : CellularSheafQ0) : Option StageCInvalidReasonQ0 :=
  if !checkBoundaryNilpotent S then
    some .boundaryNotNilpotent
  else if !checkSheafUnitsAndContexts S then
    some .illTypedStalkOrMatrix
  else if !checkSheafFlagFunctoriality S then
    some .nonFunctorialSheafRestriction
  else if !checkCochainNilpotent S then
    some .cochainNotNilpotent
  else if !checkGlobalAuthorityMeet S then
    some .authorityEscalation
  else
    none

/-! ### Part 4: Core Structural Soundness Theorems (`C-2`) -/

/-- Target Theorem `thm_sheaf_flag_functorial_sound` (`Tribunal Condition A`):
    Passing `checkSheafFlagFunctoriality` guarantees exact equality of composite stalk
    restriction matrices `ρ_{e1≼f} ∘ ρ_{v≼e1} = ρ_{e2≼f} ∘ ρ_{v≼e2}` across every opposing
    face-vertex incidence diamond `(v, e1, e2, f)`. -/
theorem thm_sheaf_flag_functorial_sound
    (S : CellularSheafQ0)
    (hfunc : checkSheafFlagFunctoriality S = true)
    (v : Fin S.nV) (f : Fin S.nF) (e1 e2 : Fin S.nE)
    (hnz : S.incVE v e1 * S.incEF e1 f ≠ 0)
    (hopp : S.incVE v e1 * S.incEF e1 f + S.incVE v e2 * S.incEF e2 f = 0) :
    matMul (S.resEF e1 f) (S.resVE v e1) = matMul (S.resEF e2 f) (S.resVE v e2) := by
  unfold checkSheafFlagFunctoriality at hfunc
  have hv  := (allFin_iff S.nV _).mp hfunc v
  have hf  := (allFin_iff S.nF _).mp hv f
  have he1 := (allFin_iff S.nE _).mp hf e1
  have he2 := (allFin_iff S.nE _).mp he1 e2
  have hcond : (S.incVE v e1 * S.incEF e1 f != 0 &&
                S.incVE v e1 * S.incEF e1 f + S.incVE v e2 * S.incEF e2 f == 0) = true := by
    simp [bne_iff_ne, hnz, hopp]
  rw [hcond] at he2
  simp only [↓reduceIte] at he2
  exact (matEqBool_iff _ _).mp he2

/-- Pairwise Diamond Cancellation Theorem `thm_sheaf_functorial_imp_nilpotent`:
    Whenever a vertex-face pair `(v, f)` is connected through two opposing incident boundary
    edges `e1, e2` (`c1 + c2 = 0`, `c1 ≠ 0`), sheaf flag functoriality (`Condition A`)
    forces their signed composite restriction contributions to cancel identically to `0`. -/
theorem thm_sheaf_functorial_imp_nilpotent
    (S : CellularSheafQ0)
    (hfunc : checkSheafFlagFunctoriality S = true)
    (v : Fin S.nV) (f : Fin S.nF) (e1 e2 : Fin S.nE)
    (hnz : S.incVE v e1 * S.incEF e1 f ≠ 0)
    (hopp : S.incVE v e1 * S.incEF e1 f + S.incVE v e2 * S.incEF e2 f = 0)
    (i_f : Fin (S.dF f)) (j_v : Fin (S.dV v)) :
    (S.incVE v e1 * S.incEF e1 f) * matMul (S.resEF e1 f) (S.resVE v e1) i_f j_v +
    (S.incVE v e2 * S.incEF e2 f) * matMul (S.resEF e2 f) (S.resVE v e2) i_f j_v = 0 := by
  have hcomm := thm_sheaf_flag_functorial_sound S hfunc v f e1 e2 hnz hopp
  rw [hcomm, ← Rat.add_mul, hopp, Rat.zero_mul]

/-- Target Theorem `thm_cochain_nilpotent_sound`:
    Passing `checkCochainNilpotent S = true` guarantees `δ¹ (δ⁰ x) = 0` for ALL `x ∈ C⁰`
    (i.e. `im(δ⁰) ⊆ ker(δ¹)`). -/
theorem thm_cochain_nilpotent_sound
    (S : CellularSheafQ0)
    (hnil : checkCochainNilpotent S = true) :
    ∀ x : VecQ0 S.N0, matVec (assembleDelta1 S) (matVec (assembleDelta0 S) x) = zeroVec S.N2 := by
  have hm := (matEqBool_iff _ _).mp hnil
  intro x
  rw [← matVec_matMul, hm, zeroMat_vec]

/-- Target Theorem `thm_stageC_global_authority_meet_nonescalation`:
    Passing `checkGlobalAuthorityMeet S = true` guarantees `claimedGlobalAuth ≼ vAuth v`
    and `claimedGlobalAuth ≼ eAuth e` for EVERY vertex and edge; in particular, if ANY cell
    lacks empirical (`= 0`) or institutional (`= 0`) authority, the global section cannot gain it. -/
theorem thm_stageC_global_authority_meet_nonescalation
    (S : CellularSheafQ0)
    (hauth : checkGlobalAuthorityMeet S = true) :
    (∀ v : Fin S.nV, AuthorityLe S.claimedGlobalAuth (S.vAuth v)) ∧
    (∀ e : Fin S.nE, AuthorityLe S.claimedGlobalAuth (S.eAuth e)) ∧
    ((∃ v : Fin S.nV, (S.vAuth v).empirical = 0) → S.claimedGlobalAuth.empirical = 0) ∧
    ((∃ v : Fin S.nV, (S.vAuth v).institutional = 0) → S.claimedGlobalAuth.institutional = 0) := by
  unfold checkGlobalAuthorityMeet at hauth
  simp only [Bool.and_eq_true, allFin_iff] at hauth
  have hv_le : ∀ v : Fin S.nV, AuthorityLe S.claimedGlobalAuth (S.vAuth v) :=
    fun v => (lem_checkAuthorityLe_iff _ _).mp (hauth.1 v)
  have he_le : ∀ e : Fin S.nE, AuthorityLe S.claimedGlobalAuth (S.eAuth e) :=
    fun e => (lem_checkAuthorityLe_iff _ _).mp (hauth.2 e)
  refine ⟨hv_le, he_le, ?_, ?_⟩
  · rintro ⟨v, hv0⟩
    have h := (hv_le v).2.1
    omega
  · rintro ⟨v, hv0⟩
    have h := (hv_le v).2.2
    omega

end GrandZero.StageC
