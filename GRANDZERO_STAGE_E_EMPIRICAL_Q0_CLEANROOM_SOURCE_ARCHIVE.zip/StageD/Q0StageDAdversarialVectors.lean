/-
  GRANDZERO Ω — Stage D (Algebraic Dynamics, Invariants, Barriers & Memory Gate)
  Module D-5: Q0StageDAdversarialVectors.lean
  Scope:
    Mechanized formal theorems (`0 sorry`, `0 custom axiom`, `0 native_decide`)
    and structured audit records for orthogonal verification vectors `TD-01 ~ TD-07b`,
    explicitly verifying `Tribunal F-D01 ~ F-D05`:
      - `TD-01`  : Cayley Rational Symplectic Harmonic Oscillator (`verifiedForwardSafeAndInvariant`
                   via frozen `StageB.checkBridgeCert` + SOS pole proof + all-time energy conservation).
      - `TD-02`  : Forward Euler Discretization Drift (`verifiedDiscreteDriftObstruction` + `F-D01`
                   exact `ΔH = Δt² ω² H`, `0` at `(0,0)`, and strict `> 0` under `Δt≠0 ∧ ω≠0 ∧ H>0`).
      - `TD-03`  : Guarded Contraction & Discrete CBF (`0 < γ ≤ 1`, `F-D04` scalar `V(ρ_t)` geometric
                   decay `0 ≤ V(ρ_t) ≤ (1/4)^t V(ρ_0)` & `B(ρ_t) ≥ 0` for all `t ∈ ℕ`).
      - `TD-04a` : Discrete CBF Overshoot Parameter `γ = 2 > 1` (`∀ bundle, .invalidBarrierOrRate`).
      - `TD-04b` : Over-damped 1-Step Safe-Domain Escape (`verifiedBarrierSafetyViolation` + `¬ ForwardInvariant`).
      - `TD-05`  : Multi-Cell Sheaf `H⁰` Tearing on Hollow 3-Cycle (`F-D02`: `x₀ ∈ ker(δ⁰) ∧ δ⁰(A₀ x₀) ≠ 0`,
                   while proving `[δ⁰(A₀ x₀)] = 0 ∈ H¹` via `LH(δ⁰(A₀ x₀)) = 0` even when `h¹ = 1 ≠ 0`!).
      - `TD-06`  : Finite-Window Time-Homogeneous `ℚ`-Linear Markov No-Go (`F-D05`: `∀ M ∈ ℚ^{1×1}, M X ≠ Y`)
                   paired with exact 2D Hidden-Velocity Semigroup Realization.
      - `TD-07a` : Dimensional Step-Update Smuggling `q + v` without `Δt` (`∀ bundle, .illTypedDynamics`).
      - `TD-07b` : Dynamical 3D Authority Escalation `(1,0,0) → (1,1,0)` (`∀ bundle, .authorityEscalation`).
-/

import StageD.Q0SheafDynamicsAndMemoryObstruction

namespace GrandZero.StageD

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC

/-! ### Helper SI Units for Dynamical Scenarios -/

def invSecUnit : UnitSpecQ0 :=
  { dim := { T := -1 }, kind := .canonical }

def invSecSqUnit : UnitSpecQ0 :=
  { dim := { T := -2 }, kind := .canonical }

def accelUnit : UnitSpecQ0 :=
  { dim := { L := 1, T := -2 }, kind := .canonical }

def specEnergyUnit : UnitSpecQ0 :=
  { dim := { L := 2, T := -2 }, kind := .canonical }

def invMeterUnit : UnitSpecQ0 :=
  { dim := { L := -1 }, kind := .canonical }

def invMeterSqUnit : UnitSpecQ0 :=
  { dim := { L := -2 }, kind := .canonical }

/-! ### Vector `TD-01`: Cayley Rational Symplectic Harmonic Oscillator (`verifiedForwardSafeAndInvariant`) -/

/-- State/parameter context `(q : m, v : m/s, ω : s⁻¹, Δt : s)` with `ω > 0, Δt > 0`. -/
def td01_ctx : ContextQ0 :=
  { vars   := [UnitSpecQ0.meter, velUnit, invSecUnit, UnitSpecQ0.second]
    hyps   := []
    guards := [.pos (.bvar 2), .pos (.bvar 3)] }

/-- Continuous harmonic-oscillator vector field `(v, -ω² q, 0, 0)`. -/
def td01_rates : List ExprQ0 :=
  [ .bvar 1,
    .unaryNeg (.binOp .mul (.binOp .mul (.bvar 2) (.bvar 2)) (.bvar 0)),
    .ratLit 0 invSecSqUnit,
    .ratLit 0 UnitSpecQ0.unitless ]

/-- Specific mechanical energy `H(q, v, ω, Δt) = (1/2) v² + (1/2) ω² q²` (`[L² T⁻²]`). -/
def td01_H : ExprQ0 :=
  .binOp .add
    (.binOp .mul (.ratLit (1 / 2) UnitSpecQ0.unitless) (.binOp .mul (.bvar 1) (.bvar 1)))
    (.binOp .mul (.ratLit (1 / 2) UnitSpecQ0.unitless)
      (.binOp .mul (.binOp .mul (.bvar 2) (.bvar 2)) (.binOp .mul (.bvar 0) (.bvar 0))))

/-- Dimensionless half-step phase `τ = (1/2) * (ω * Δt)` and Cayley denominator `1 + τ * τ`. -/
def td01_tau : ExprQ0 :=
  .binOp .mul (.ratLit (1 / 2) UnitSpecQ0.unitless) (.binOp .mul (.bvar 2) (.bvar 3))

def td01_numFactor : ExprQ0 :=
  .binOp .sub (.ratLit 1 UnitSpecQ0.unitless) (.binOp .mul td01_tau td01_tau)

def td01_denCayley : ExprQ0 :=
  .binOp .add (.ratLit 1 UnitSpecQ0.unitless) (.binOp .mul td01_tau td01_tau)

def td01_cayleyCoords : List ExprQ0 :=
  [ .binOp .div
      (.binOp .add (.binOp .mul td01_numFactor (.bvar 0)) (.binOp .mul (.bvar 3) (.bvar 1)))
      td01_denCayley,
    .binOp .div
      (.binOp .add
        (.unaryNeg (.binOp .mul (.binOp .mul (.binOp .mul (.bvar 2) (.bvar 2)) (.bvar 3)) (.bvar 0)))
        (.binOp .mul td01_numFactor (.bvar 1)))
      td01_denCayley,
    .bvar 2,
    .bvar 3 ]

def td01_dyn : GuardedDynSpecQ0 :=
  { ctx          := td01_ctx
    stepCoords   := td01_cayleyCoords
    optRateField := some td01_rates }

def td01_spec : StageDSpecQ0 :=
  { dyn    := td01_dyn
    optObs := some td01_H }

/-- Whitebox SOS proof that `1 + τ² > 0` (hence `≠ 0`) everywhere over `ℚ`! -/
def td01_denNzProof : BridgeGuardProofQ0 :=
  .gPosImpNzB (.gPosAddNNeg (.fromStageA .gRatLit) (.gSqNNeg []))

def td01_stepCert : BridgeCertQ0 :=
  { coordPoleProofs := [td01_denNzProof, td01_denNzProof]
    hypPullProofs   := []
    guardPullProofs := [.fromStageA (.gActiveMem 0), .fromStageA (.gActiveMem 1)] }

def td01_invCert : DiscreteInvariantCertQ0 :=
  .viaBridgePoleGPR [td01_denNzProof] []

def td01_bundle : StageDCertBundleQ0 :=
  .forwardSafeAndInvariant [2, 0, 1, 1] td01_stepCert (some td01_invCert) none none

theorem td01_cayley_symplectic_exact_conservation :
    computePolyLieDeriv td01_ctx.vars td01_H td01_rates = some PolyQ0.zero ∧
    auditStageDDynamicsGate td01_spec td01_bundle = .verifiedForwardSafeAndInvariant ∧
    NonVacuousForwardInvariant td01_dyn ∧
    (∀ t : Nat, ∃ (ρt : List Rat) (val₀ : Rat),
      iterateStep td01_dyn.stepCoords t [2, 0, 1, 1] = some ρt ∧
      ValidDomainQ0 ρt td01_ctx ∧
      denoteExpr [2, 0, 1, 1] td01_H = some val₀ ∧
      denoteExpr ρt td01_H = some val₀) := by
  have hlie : computePolyLieDeriv td01_ctx.vars td01_H td01_rates = some PolyQ0.zero := by
    with_unfolding_all rfl
  have haud : auditStageDDynamicsGate td01_spec td01_bundle = .verifiedForwardSafeAndInvariant := by
    with_unfolding_all rfl
  have hnv := (thm_stageD_forward_safe_sound td01_spec td01_bundle haud).2.1
  have hinv_c : checkDiscreteInvariantCert td01_dyn td01_H td01_invCert = true := by
    with_unfolding_all rfl
  have hdom0 : ValidDomainQ0 [2, 0, 1, 1] td01_ctx :=
    (lem_checkValidDomain_iff [2, 0, 1, 1] td01_ctx).mp (by with_unfolding_all rfl)
  exact ⟨hlie, haud, hnv, thm_discrete_invariant_all_time td01_dyn td01_H td01_invCert hnv.2 hinv_c [2, 0, 1, 1] hdom0⟩

/-! ### Vector `TD-02`: Forward Euler Discretization Drift (`verifiedDiscreteDriftObstruction`, `F-D01`) -/

def td02_eulerCoords : List ExprQ0 :=
  [ .binOp .add (.bvar 0) (.binOp .mul (.bvar 3) (.bvar 1)),
    .binOp .sub (.bvar 1) (.binOp .mul (.bvar 3) (.binOp .mul (.binOp .mul (.bvar 2) (.bvar 2)) (.bvar 0))),
    .bvar 2,
    .bvar 3 ]

def td02_dyn : GuardedDynSpecQ0 :=
  { ctx          := td01_ctx
    stepCoords   := td02_eulerCoords
    optRateField := some td01_rates }

def td02_spec : StageDSpecQ0 :=
  { dyn    := td02_dyn
    optObs := some td01_H }

def td02_bundle : StageDCertBundleQ0 :=
  .discreteDriftWitness [2, 0, 1, 1]

/-- Exact theoretical Forward Euler drift expression `Δt² · ω² · H(q, v)` (`Tribunal F-D01`). -/
def td02_exactDriftFormula : ExprQ0 :=
  .binOp .mul
    (.binOp .mul (.bvar 3) (.bvar 3))
    (.binOp .mul (.binOp .mul (.bvar 2) (.bvar 2)) td01_H)

theorem td02_forward_euler_discretization_drift :
    computePolyLieDeriv td01_ctx.vars td01_H td01_rates = some PolyQ0.zero ∧
    auditStageDDynamicsGate td02_spec td02_bundle = .verifiedDiscreteDriftObstruction ∧
    (∀ b_any : StageDCertBundleQ0,
      auditStageDDynamicsGate td02_spec b_any ≠ .verifiedForwardSafeAndInvariant ∧
      auditStageDDynamicsGate td02_spec b_any ≠ .verifiedEmptySafeDomain) := by
  have hlie : computePolyLieDeriv td01_ctx.vars td01_H td01_rates = some PolyQ0.zero := by
    with_unfolding_all rfl
  have haud : auditStageDDynamicsGate td02_spec td02_bundle = .verifiedDiscreteDriftObstruction := by
    with_unfolding_all rfl
  exact ⟨hlie, haud, (thm_stageD_drift_obstruction_sound_and_exclusive td02_spec td02_bundle haud).2⟩

theorem rat_sq_pos_of_ne_zero {a : Rat} (ha : a ≠ 0) : 0 < a * a := by
  by_cases hp : 0 < a
  · exact Rat.mul_pos hp hp
  · have hn : 0 < -a := by grind
    have hprod : 0 < (-a) * (-a) := Rat.mul_pos hn hn
    have heq : (-a) * (-a) = a * a := by grind
    rw [heq] at hprod
    exact hprod

/-- Explicit `Tribunal F-D01` Theorem `td02_exact_euler_drift_formula_and_positivity`:
    1. For ALL `(q, v, ω, dt) ∈ ℚ⁴`, Forward Euler energy drift equals `dt² · ω² · H(q, v)`
       identically via `StrongEq`,
    2. Vanishes (`= some 0`) at equilibrium `(q, v) = (0, 0)`, AND
    3. Satisfies strict positivity `0 < ΔH` whenever `dt ≠ 0 ∧ ω ≠ 0 ∧ 0 < H(q, v)`. -/
theorem td02_exact_euler_drift_formula_and_positivity :
    (∀ q v ω dt : Rat,
      StrongEq [q, v, ω, dt] (stepDriftExpr td02_dyn td01_H) td02_exactDriftFormula) ∧
    (∀ ω dt : Rat,
      denoteExpr [0, 0, ω, dt] (stepDriftExpr td02_dyn td01_H) = some 0) ∧
    (∀ q v ω dt : Rat,
      dt ≠ 0 → ω ≠ 0 →
      let Hval := (1 / 2 : Rat) * (v * v) + (1 / 2 : Rat) * ((ω * ω) * (q * q))
      0 < Hval →
      denoteExpr [q, v, ω, dt] (stepDriftExpr td02_dyn td01_H) =
        some ((dt * dt) * ((ω * ω) * Hval)) ∧
      0 < (dt * dt) * ((ω * ω) * Hval)) := by
  have haud_eq : auditProof td01_ctx.vars [] [] (.gprAstCert [] [])
      (stepDriftExpr td02_dyn td01_H) td02_exactDriftFormula = SyndromeQ0.zero := by
    with_unfolding_all rfl
  have hstrong_all : ∀ q v ω dt : Rat,
      StrongEq [q, v, ω, dt] (stepDriftExpr td02_dyn td01_H) td02_exactDriftFormula := by
    intro q v ω dt
    have henv : EnvModelsCtx [q, v, ω, dt] td01_ctx.vars := rfl
    exact (thm_syndrome_sound (.gprAstCert [] []) td01_ctx.vars [] []
      (stepDriftExpr td02_dyn td01_H) td02_exactDriftFormula haud_eq).2
      [q, v, ω, dt] henv (fun _ h => by simp at h) (fun _ h => by simp at h)
  refine ⟨hstrong_all, ?_, ?_⟩
  · intro ω dt
    rcases hstrong_all 0 0 ω dt with ⟨val, h1, h2⟩
    have hrhs0 : denoteExpr [0, 0, ω, dt] td02_exactDriftFormula = some 0 := by
      simp [td02_exactDriftFormula, td01_H, denoteExpr, evalBinOp,
            Rat.mul_zero, Rat.add_zero]
    rw [hrhs0] at h2; injection h2 with hv0; subst hv0
    exact h1
  · intro q v ω dt hdt hω Hval hHpos
    rcases hstrong_all q v ω dt with ⟨val, h1, h2⟩
    have hrhs : denoteExpr [q, v, ω, dt] td02_exactDriftFormula =
        some ((dt * dt) * ((ω * ω) * Hval)) := by
      simp [td02_exactDriftFormula, td01_H, denoteExpr, evalBinOp, Hval]
    rw [hrhs] at h2; injection h2 with hveq; subst hveq
    have hdt2 : 0 < dt * dt := rat_sq_pos_of_ne_zero hdt
    have hω2  : 0 < ω * ω   := rat_sq_pos_of_ne_zero hω
    exact ⟨h1, Rat.mul_pos hdt2 (Rat.mul_pos hω2 hHpos)⟩

/-! ### Vector `TD-03`: Guarded Contraction & Discrete CBF (`0 < γ ≤ 1`, `F-D04` Scoped) -/

def td03_ctx : ContextQ0 :=
  { vars   := [UnitSpecQ0.meter]
    hyps   := []
    guards := [.pos (.bvar 0)] }

/-- Contractive positive map `x⁺ = (1/2)_m + (1/2) * x` preserving `x > 0` and equilibrium `x = 1_m`. -/
def td03_dyn : GuardedDynSpecQ0 :=
  { ctx        := td03_ctx
    stepCoords := [.binOp .add (.ratLit (1 / 2) UnitSpecQ0.meter)
                     (.binOp .mul (.ratLit (1 / 2) UnitSpecQ0.unitless) (.bvar 0))] }

def td03_B : ExprQ0 :=
  .binOp .sub (.bvar 0) (.ratLit 1 UnitSpecQ0.meter)

def td03_V : ExprQ0 :=
  .binOp .mul td03_B td03_B

def td03_stepCert : BridgeCertQ0 :=
  { coordPoleProofs := []
    hypPullProofs   := []
    guardPullProofs := [.gPosAddPos (.fromStageA .gRatLit)
                         (.gPosMulPos (.fromStageA .gRatLit) (.fromStageA (.gActiveMem 0)))] }

def td03_zeroMarginCert : NonnegCertQ0 :=
  { c0        := 0
    posTerms  := []
    nnegTerms := []
    eqTerms   := []
    eqProof   := .gprAstCert [.gRatLit] [] }

def td03_vNonnegCert : NonnegCertQ0 :=
  { c0        := 0
    posTerms  := []
    nnegTerms := [{ weight := 1, weightUnit := invMeterSqUnit, expr := td03_V, proof := .gSqNNeg [] }]
    eqTerms   := []
    eqProof   := .gprAstCert [.gRatLit] [] }

def td03_lyap2Cert : LyapunovTier2CertQ0 :=
  { V              := td03_V
    alpha          := 3 / 4
    vNonnegCert    := td03_vNonnegCert
    geomNonnegCert := td03_zeroMarginCert }

def td03_cbfCert : DiscreteCBFCertQ0 :=
  { B          := td03_B
    gamma      := 1 / 2
    marginCert := td03_zeroMarginCert }

def td03_spec : StageDSpecQ0 :=
  { dyn          := td03_dyn
    optCBFGamma  := some (1 / 2)
    optLyapAlpha := some (3 / 4) }

def td03_bundle : StageDCertBundleQ0 :=
  .forwardSafeAndInvariant [5] td03_stepCert none (some td03_lyap2Cert) (some td03_cbfCert)

theorem td03_guarded_lyapunov_and_cbf_all_time :
    auditStageDDynamicsGate td03_spec td03_bundle = .verifiedForwardSafeAndInvariant ∧
    (∀ t : Nat, ∃ (ρt : List Rat) (v0 vt bt : Rat),
      iterateStep td03_dyn.stepCoords t [5] = some ρt ∧
      denoteExpr [5] td03_V = some v0 ∧
      denoteExpr ρt td03_V = some vt ∧
      denoteExpr ρt td03_B = some bt ∧
      0 ≤ vt ∧ vt ≤ ratPow (1 / 4) t * v0 ∧ 0 ≤ bt) := by
  have haud : auditStageDDynamicsGate td03_spec td03_bundle = .verifiedForwardSafeAndInvariant := by
    with_unfolding_all rfl
  have hfwd := (thm_stageD_forward_safe_sound td03_spec td03_bundle haud).2.1.2
  have hdom0 : ValidDomainQ0 [5] td03_ctx :=
    (lem_checkValidDomain_iff [5] td03_ctx).mp (by with_unfolding_all rfl)
  have hlyap : checkLyapunovTier2Cert td03_dyn td03_lyap2Cert = true := by with_unfolding_all rfl
  have hcbf  : checkDiscreteCBFCert td03_dyn td03_cbfCert = true := by with_unfolding_all rfl
  have hb0   : denoteExpr [5] td03_B = some 4 := by with_unfolding_all rfl
  refine ⟨haud, fun t => ?_⟩
  rcases thm_lyapunov_scalar_geometric_decay td03_dyn td03_lyap2Cert hfwd hlyap [5] hdom0 t with
    ⟨ρt, v0, vt, hit, hdv0, hdvt, hvt0, hvt_le⟩
  rcases thm_discrete_cbf_all_time td03_dyn td03_cbfCert hfwd hcbf [5] hdom0 4 hb0 (by decide) t with
    ⟨ρt', bt, hit', hdbt, _, hbt0⟩
  rw [hit] at hit'; injection hit' with heq; subst heq
  have h1m : (1 : Rat) - td03_lyap2Cert.alpha = 1 / 4 := by with_unfolding_all rfl
  rw [h1m] at hvt_le
  exact ⟨ρt, v0, vt, bt, hit, hdv0, hdvt, hdbt, hvt0, hvt_le, hbt0⟩

/-! ### Vectors `TD-04a` & `TD-04b`: Discrete CBF Overshoot (`γ = 2 > 1`) & Safety Escape -/

def td04a_spec : StageDSpecQ0 :=
  { dyn         := td03_dyn
    optCBFGamma := some 2 }

theorem td04a_invalid_cbf_gamma_rejected :
    validateStageDSpec td04a_spec = some .invalidBarrierOrRate ∧
    ∀ bundle : StageDCertBundleQ0,
      auditStageDDynamicsGate td04a_spec bundle = .rejectedInvalidDynamicsSpec .invalidBarrierOrRate := by
  have hv : validateStageDSpec td04a_spec = some .invalidBarrierOrRate := by
    with_unfolding_all rfl
  exact ⟨hv, thm_stageD_invalid_spec_universal_reject td04a_spec _ hv⟩

/-- `TD-04b`: Over-damped step `x⁺ = 1_m - (3/2) * (x - 1_m)` (`γ = 5/2 > 1`);
    from safe `x₀ = 3 > 0`, `x₁ = -2 ∉ Real_ℚ(td03_ctx)`! -/
def td04b_dyn : GuardedDynSpecQ0 :=
  { ctx        := td03_ctx
    stepCoords := [.binOp .sub (.ratLit 1 UnitSpecQ0.meter)
                     (.binOp .mul (.ratLit (3 / 2) UnitSpecQ0.unitless) td03_B)] }

def td04b_spec : StageDSpecQ0 :=
  { dyn := td04b_dyn }

def td04b_bundle : StageDCertBundleQ0 :=
  .barrierEscapeWitness [3] 1

theorem td04b_reachable_barrier_escape :
    auditStageDDynamicsGate td04b_spec td04b_bundle = .verifiedBarrierSafetyViolation ∧
    ¬ ForwardInvariant td04b_dyn ∧
    (∀ b_any : StageDCertBundleQ0,
      auditStageDDynamicsGate td04b_spec b_any ≠ .verifiedForwardSafeAndInvariant ∧
      auditStageDDynamicsGate td04b_spec b_any ≠ .verifiedEmptySafeDomain) := by
  have haud : auditStageDDynamicsGate td04b_spec td04b_bundle = .verifiedBarrierSafetyViolation := by
    with_unfolding_all rfl
  rcases thm_stageD_barrier_violation_sound_and_exclusive td04b_spec td04b_bundle haud with
    ⟨_, hninv, hexcl⟩
  exact ⟨haud, hninv, hexcl⟩

/-! ### Vector `TD-05`: Sheaf `H⁰` Tearing with Trivial `H¹` Class (`verifiedSheafDynamicsTear`, `F-D02`) -/

/-- Heterogeneous vertex decay `A0 = diag(1, 1/2, 1/2)` on hollow 3-cycle `StageC.tc02_sheaf`
    (where `h¹ = 1 ≠ 0` and `LH = [[1, 1, 1]]`!). -/
def td05_A0 : MatQ0 tc02_sheaf.N0 tc02_sheaf.N0 :=
  matOfLists tc02_sheaf.N0 tc02_sheaf.N0 [
    [1,     0,     0],
    [0, 1 / 2,     0],
    [0,     0, 1 / 2]
  ]

def td05_x0 : VecQ0 tc02_sheaf.N0 :=
  vecOfList tc02_sheaf.N0 [2, 2, 2]

def td05_spec : StageDSpecQ0 :=
  { dyn      := td03_dyn
    optSheaf := some tc02_sheaf }

def td05_bundle : StageDCertBundleQ0 :=
  .sheafTearWitness tc02_sheaf tc02_cohomCert td05_A0 td05_x0

theorem td05_sheaf_h0_tear_with_zero_h1 :
    auditStageDDynamicsGate td05_spec td05_bundle = .verifiedSheafDynamicsTear ∧
    tc02_cohomCert.h1 = 1 ∧
    matVec (assembleDelta0 tc02_sheaf) td05_x0 = zeroVec tc02_sheaf.N1 ∧
    matVec (assembleDelta0 tc02_sheaf) (matVec td05_A0 td05_x0) ≠ zeroVec tc02_sheaf.N1 ∧
    matVec tc02_cohomCert.LH (matVec (assembleDelta0 tc02_sheaf) (matVec td05_A0 td05_x0)) =
      zeroVec tc02_cohomCert.h1 := by
  have haud : auditStageDDynamicsGate td05_spec td05_bundle = .verifiedSheafDynamicsTear := by
    with_unfolding_all rfl
  have htear : checkSheafDynamicsTear tc02_sheaf tc02_cohomCert td05_A0 td05_x0 = true := by
    with_unfolding_all rfl
  rcases thm_sheaf_dynamics_tear_coboundary tc02_sheaf tc02_cohomCert td05_A0 td05_x0 htear with
    ⟨hx0, hnz, _, hlh0⟩
  exact ⟨haud, rfl, hx0, hnz, hlh0⟩

/-! ### Vector `TD-06`: Scoped Linear Markov No-Go & Hidden-Fiber Lift (`F-D05`) -/

def td06_Xpast : MatQ0 1 2 := matOfLists 1 2 [[1, 0]]
def td06_Ynext : MatQ0 1 2 := matOfLists 1 2 [[0, -1]]
def td06_uDual : VecQ0 2   := vecOfList 2 [0, 1]

def td06_lift : HiddenFiberLiftQ0 1 :=
  { dMem   := 1
    Atilde := matOfLists 2 2 [[0, 1], [-1, 0]]
    PiProj := matOfLists 1 2 [[1, 0]]
    z0     := vecOfList 2 [1, 0] }

def td06_spec : StageDSpecQ0 :=
  { dyn := td03_dyn }

def td06_bundle : StageDCertBundleQ0 :=
  .markovNoGoWitness 1 2 td06_Xpast td06_Ynext td06_uDual td06_lift

theorem td06_linear_markov_no_go_and_hidden_lift :
    auditStageDDynamicsGate td06_spec td06_bundle = .verifiedMarkovianClosureObstruction ∧
    (∀ M : MatQ0 1 1, matMul M td06_Xpast ≠ td06_Ynext) ∧
    (∀ k : Fin 2,
      matCol td06_Xpast k = liftedTrajectoryObs td06_lift k.val ∧
      matCol td06_Ynext k = liftedTrajectoryObs td06_lift (k.val + 1)) := by
  have haud : auditStageDDynamicsGate td06_spec td06_bundle = .verifiedMarkovianClosureObstruction := by
    with_unfolding_all rfl
  have hng : checkLinearMarkovNoGo td06_Xpast td06_Ynext td06_uDual = true := by
    with_unfolding_all rfl
  have hrl : checkHiddenFiberRealization td06_Xpast td06_Ynext td06_lift = true := by
    with_unfolding_all rfl
  exact ⟨haud,
         thm_markov_closure_no_go td06_Xpast td06_Ynext td06_uDual hng,
         (thm_hidden_fiber_markov_realization td06_Xpast td06_Ynext td06_lift hrl).2⟩

/-! ### Vectors `TD-07a` & `TD-07b`: Dimensional Step Smuggling & Dynamical Authority Escalation -/

/-- `TD-07a`: Updating position `q` (`[L]`) by `q + v` (`[L] + [L T⁻¹]`) without multiplying by `Δt` (`[T]`). -/
def td07a_dyn : GuardedDynSpecQ0 :=
  { ctx        := td01_ctx
    stepCoords := [.binOp .add (.bvar 0) (.bvar 1), .bvar 1, .bvar 2, .bvar 3] }

def td07a_spec : StageDSpecQ0 :=
  { dyn := td07a_dyn }

theorem td07a_dimensional_step_smuggling_rejected :
    validateStageDSpec td07a_spec = some .illTypedDynamics ∧
    ∀ bundle : StageDCertBundleQ0,
      auditStageDDynamicsGate td07a_spec bundle = .rejectedInvalidDynamicsSpec .illTypedDynamics := by
  have hv : validateStageDSpec td07a_spec = some .illTypedDynamics := by
    with_unfolding_all rfl
  exact ⟨hv, thm_stageD_invalid_spec_universal_reject td07a_spec _ hv⟩

/-- `TD-07b`: Attempting to escalate purely formal dynamics `(1, 0, 0)` to empirical authority `(1, 1, 0)`. -/
def td07b_dyn : GuardedDynSpecQ0 :=
  { td03_dyn with claimedAuth := AuthorityVecQ0.formalEmpirical }

def td07b_spec : StageDSpecQ0 :=
  { dyn := td07b_dyn }

theorem td07b_dynamical_authority_escalation_rejected :
    validateStageDSpec td07b_spec = some .authorityEscalation ∧
    ∀ bundle : StageDCertBundleQ0,
      auditStageDDynamicsGate td07b_spec bundle = .rejectedInvalidDynamicsSpec .authorityEscalation := by
  have hv : validateStageDSpec td07b_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  exact ⟨hv, thm_stageD_invalid_spec_universal_reject td07b_spec _ hv⟩

/-! ### Structured Runtime Formatting & Vector Table (`stage_d_audit`) -/

def formatStageDInvalidReason : StageDInvalidReasonQ0 → String
  | .illTypedDynamics     => "illTypedDynamics"
  | .authorityEscalation  => "authorityEscalation"
  | .invalidBarrierOrRate => "invalidBarrierOrRate"
  | .invalidSheafBase     => "invalidSheafBase"

def formatStageDOutcome : StageDGateOutcomeQ0 → String
  | .verifiedEmptySafeDomain             => "verifiedEmptySafeDomain"
  | .verifiedForwardSafeAndInvariant     => "verifiedForwardSafeAndInvariant"
  | .verifiedDiscreteDriftObstruction    => "verifiedDiscreteDriftObstruction"
  | .verifiedBarrierSafetyViolation      => "verifiedBarrierSafetyViolation"
  | .verifiedSheafDynamicsTear           => "verifiedSheafDynamicsTear"
  | .verifiedMarkovianClosureObstruction => "verifiedMarkovianClosureObstruction"
  | .rejectedInvalidDynamicsSpec r       => s!"rejectedInvalidDynamicsSpec({formatStageDInvalidReason r})"
  | .rejectedInvalidCertificate          => "rejectedInvalidCertificate"

structure StageDVectorRecord where
  vecId    : String
  expected : StageDGateOutcomeQ0
  actual   : StageDGateOutcomeQ0
  detail   : String

def td_dummyBundle : StageDCertBundleQ0 :=
  .discreteDriftWitness []

def stageDVectorRecords : List StageDVectorRecord :=
  [ { vecId    := "TD-01"
      expected := .verifiedForwardSafeAndInvariant
      actual   := auditStageDDynamicsGate td01_spec td01_bundle
      detail   := "CayleyRationalSymplectic_AllTimePoleFree_ExactEnergyConservation" },
    { vecId    := "TD-02"
      expected := .verifiedDiscreteDriftObstruction
      actual   := auditStageDDynamicsGate td02_spec td02_bundle
      detail   := "ForwardEuler_DiscretizationDrift_dt2_omega2_H_FD01" },
    { vecId    := "TD-03"
      expected := .verifiedForwardSafeAndInvariant
      actual   := auditStageDDynamicsGate td03_spec td03_bundle
      detail   := "GuardedScalarLyapunovDecay_And_DiscreteCBF_GammaHalf_FD04" },
    { vecId    := "TD-04a"
      expected := .rejectedInvalidDynamicsSpec .invalidBarrierOrRate
      actual   := auditStageDDynamicsGate td04a_spec td_dummyBundle
      detail   := "DiscreteCBF_OvershootGamma2Gt1_StaticallyBlocked" },
    { vecId    := "TD-04b"
      expected := .verifiedBarrierSafetyViolation
      actual   := auditStageDDynamicsGate td04b_spec td04b_bundle
      detail   := "OverdampedStep_ReachableOneStepSafeDomainEscape" },
    { vecId    := "TD-05"
      expected := .verifiedSheafDynamicsTear
      actual   := auditStageDDynamicsGate td05_spec td05_bundle
      detail   := "Hollow3Cycle_H0GluingTear_WithZeroH1CoboundaryClass_FD02" },
    { vecId    := "TD-06"
      expected := .verifiedMarkovianClosureObstruction
      actual   := auditStageDDynamicsGate td06_spec td06_bundle
      detail   := "TimeHomogeneousLinearMarkovNoGo_And_2DHiddenVelocityLift_FD05" },
    { vecId    := "TD-07a"
      expected := .rejectedInvalidDynamicsSpec .illTypedDynamics
      actual   := auditStageDDynamicsGate td07a_spec td_dummyBundle
      detail   := "DimensionalStepSmuggling_PositionPlusVelocityWithoutDt_Blocked" },
    { vecId    := "TD-07b"
      expected := .rejectedInvalidDynamicsSpec .authorityEscalation
      actual   := auditStageDDynamicsGate td07b_spec td_dummyBundle
      detail   := "DynamicalAuthorityEscalation_FormalOnlyToEmpirical_Blocked" } ]

end GrandZero.StageD
