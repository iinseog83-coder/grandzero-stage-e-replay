/-
  GRANDZERO Ω — Stage D (Algebraic Dynamics, Invariants, Barriers & Memory Gate)
  Module D-3: Q0LyapunovAndBarrierCerts.lean
  Scope:
    1. Whitebox Positivstellensatz / Cone-SOS Non-Negativity Verifier `NonnegCertQ0`
       extending `StageB` cone/ideal terms with explicit unit normalization and
       `StageA.auditProof` denominator-pole verification (`thm_nonneg_cert_sound`).
    2. Scope-exact Scalar Lyapunov Certificates (`Tribunal F-D04`):
         - Tier 1 (`thm_lyapunov_scalar_monotone`): `0 ≤ V(ρ_{t+1}) ≤ V(ρ_t) ≤ V(ρ_0)`
           on scalar values `V(ρ_t)` ONLY (no state-vector boundedness overclaim).
         - Tier 2 (`thm_lyapunov_scalar_geometric_decay`): `0 ≤ V(ρ_t) ≤ (1 - α)^t V(ρ_0)`
           for `0 < α ≤ 1` on scalar values `V(ρ_t)` ONLY (no state-convergence overclaim).
    3. Discrete Control Barrier Certificate (`checkDiscreteCBFCert`, `0 < γ ≤ 1`,
       `thm_discrete_cbf_all_time`), statically blocking `γ > 1` overshoot hazards.
-/

import StageD.Q0ConservationLawsAndDriftDefect

namespace GrandZero.StageD

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC

/-! ### Part 1: Unit-Safe Whitebox Cone-SOS Non-Negativity Verifier (`NonnegCertQ0`) -/

/-- Normalize any expression `target` of synthesized unit `u_target` into `UnitSpecQ0.unitless`
    by dividing by `1_{u_target}`, preserving exact rational value `v / 1 = v`. -/
def unitNormalizeExpr (target : ExprQ0) (u_target : UnitSpecQ0) : ExprQ0 :=
  .binOp .div target (.ratLit 1 u_target)

theorem lem_unitNormalizeExpr_eval {ρ : List Rat} {target : ExprQ0} {u_t : UnitSpecQ0} {w : Rat}
    (h : denoteExpr ρ (unitNormalizeExpr target u_t) = some w) :
    denoteExpr ρ target = some w := by
  unfold unitNormalizeExpr at h
  cases hdt : denoteExpr ρ target with
  | none => simp [denoteExpr, evalBinOp, hdt] at h
  | some vt =>
      have h10 : ¬ ((1 : Rat) = 0) := by decide
      simp only [denoteExpr, evalBinOp, hdt, if_neg h10, Option.some.injEq] at h
      rw [rat_div_one vt] at h
      subst h
      rfl

/-- Whitebox detached Cone-SOS certificate proving `target(ρ)` is pole-free and `≥ c0 ≥ 0`
    for ALL `ρ ∈ Real_ℚ(C)`. -/
structure NonnegCertQ0 where
  c0        : Rat
  posTerms  : List PosConeTermQ0
  nnegTerms : List NNegConeTermQ0
  eqTerms   : List EqIdealTermQ0
  eqProof   : ProofCertQ0
  deriving DecidableEq, Repr, Inhabited

def buildConeNonnegRHS (cert : NonnegCertQ0) (e_eq : ExprQ0) : ExprQ0 :=
  .binOp .add (.ratLit cert.c0 UnitSpecQ0.unitless)
    (.binOp .add (.binOp .add (sumPosConeExprs cert.posTerms) (sumNNegConeExprs cert.nnegTerms)) e_eq)

/-- Computable whitebox checker for `NonnegCertQ0`:
    1. Verifies non-negative constant `c0 ≥ 0` and all `pos`, `nonNeg` (including `.gSqNNeg` SOS),
       and equality-ideal terms over `C`.
    2. Uses `StageA.auditProof` to verify BOTH denominator pole-freeness of `target` AND exact
       `StrongEq` equality between `unitNormalizeExpr target u_t` and the non-negative cone sum! -/
def checkNonnegCert (C : ContextQ0) (target : ExprQ0) (cert : NonnegCertQ0) : Bool :=
  if !(decide (0 ≤ cert.c0) &&
       cert.posTerms.all (checkPosConeTerm C) &&
       cert.nnegTerms.all (checkNNegConeTerm C) &&
       cert.eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless)) then
    false
  else
    match synthUnit C.vars target, buildSumEqIdealExpr C UnitSpecQ0.unitless cert.eqTerms with
    | some u_t, some e_eq =>
        auditProof C.vars C.hyps C.guards cert.eqProof
          (unitNormalizeExpr target u_t) (buildConeNonnegRHS cert e_eq) == SyndromeQ0.zero
    | _, _ => false

/-- Target Theorem `thm_nonneg_cert_sound`:
    Whenever `checkNonnegCert C target cert = true`, for EVERY `ρ ∈ Real_ℚ(C)`,
    `target` evaluates without division-by-zero (`some v`) and satisfies `cert.c0 ≤ v` and `0 ≤ v`. -/
theorem thm_nonneg_cert_sound
    (C : ContextQ0) (target : ExprQ0) (cert : NonnegCertQ0)
    (hchk : checkNonnegCert C target cert = true) :
    ∀ ρ : List Rat, ValidDomainQ0 ρ C →
      ∃ v : Rat, denoteExpr ρ target = some v ∧ cert.c0 ≤ v ∧ 0 ≤ v := by
  unfold checkNonnegCert at hchk
  by_cases hpre : !(decide (0 ≤ cert.c0) &&
                    cert.posTerms.all (checkPosConeTerm C) &&
                    cert.nnegTerms.all (checkNNegConeTerm C) &&
                    cert.eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless))
  · simp [hpre] at hchk
  · simp only [hpre, Bool.false_eq_true, ↓reduceIte] at hchk
    have hall : 0 ≤ cert.c0 ∧
                cert.posTerms.all (checkPosConeTerm C) = true ∧
                cert.nnegTerms.all (checkNNegConeTerm C) = true ∧
                cert.eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless) = true := by
      cases b0 : decide (0 ≤ cert.c0) <;>
      cases b1 : cert.posTerms.all (checkPosConeTerm C) <;>
      cases b2 : cert.nnegTerms.all (checkNNegConeTerm C) <;>
      cases b3 : cert.eqTerms.all (checkEqIdealTerm C UnitSpecQ0.unitless) <;>
      simp [b0, b1, b2, b3] at hpre ⊢
      exact decide_eq_true_eq.mp b0
    cases hut : synthUnit C.vars target with
    | none => rw [hut] at hchk; contradiction
    | some u_t =>
      cases hbeq : buildSumEqIdealExpr C UnitSpecQ0.unitless cert.eqTerms with
      | none => rw [hut, hbeq] at hchk; contradiction
      | some e_eq =>
          rw [hut, hbeq] at hchk
          simp only [beq_iff_eq] at hchk
          intro ρ hdom
          rcases lem_sumPosConeExprs_sound hdom cert.posTerms hall.2.1 with
            ⟨_, v_pos, hd_pos, hpos_ne, hpos_nil⟩
          rcases lem_sumNNegConeExprs_sound hdom cert.nnegTerms hall.2.2.1 with
            ⟨_, v_nn, hd_nn, hnn_ge⟩
          rcases lem_sumEqIdealExpr_sound hdom cert.eqTerms hall.2.2.2 with
            ⟨e_eq', hbeq', _, hd_eq⟩
          rw [hbeq] at hbeq'
          injection hbeq' with heq_e
          subst heq_e
          have hv_pos_ge : 0 ≤ v_pos := by
            by_cases hnil : cert.posTerms = []
            · rw [hpos_nil hnil]; grind
            · have hp := hpos_ne hnil; grind
          rcases (thm_syndrome_sound cert.eqProof C.vars C.hyps C.guards
            (unitNormalizeExpr target u_t) (buildConeNonnegRHS cert e_eq) hchk).2
            ρ hdom.1 hdom.2.1 hdom.2.2 with ⟨w, hnorm_w, hrhs_w⟩
          have hdt : denoteExpr ρ target = some w := lem_unitNormalizeExpr_eval hnorm_w
          have hrhs_eval : denoteExpr ρ (buildConeNonnegRHS cert e_eq) =
              some (cert.c0 + ((v_pos + v_nn) + 0)) := by
            simp [buildConeNonnegRHS, denoteExpr, evalBinOp, hd_pos, hd_nn, hd_eq]
          rw [hrhs_eval] at hrhs_w
          injection hrhs_w with hw_eq
          have hc0_le : cert.c0 ≤ w := by
            have hc0 := hall.1
            grind
          have h0_le : 0 ≤ w := by
            have hc0 := hall.1
            grind
          exact ⟨w, hdt, hc0_le, h0_le⟩

/-! ### Part 2: Scope-Exact Scalar Lyapunov Certificates (`Tribunal F-D04`) -/

/-- Helper lemma: evaluating `substMap D.stepCoords expr` equals evaluating `expr` at `ρ'`. -/
theorem lem_eval_pulled_at_next
    {D : GuardedDynSpecQ0} {expr : ExprQ0} {u_e : UnitSpecQ0}
    (hdyn : checkDynUnitsOnly D = true)
    (hu : synthUnit D.ctx.vars expr = some u_e)
    {ρ ρ' : List Rat} (hstep : evalCoords ρ D.stepCoords = some ρ') :
    denoteExpr ρ (substMap D.stepCoords expr) = denoteExpr ρ' expr := by
  unfold checkDynUnitsOnly checkBridgeUnitsOnly GuardedDynSpecQ0.toStepBridge at hdyn
  simp only [Bool.and_eq_true] at hdyn
  have hlen : D.stepCoords.length = D.ctx.vars.length := checkCoordsUnits_length hdyn.1.2
  have hws : wellScoped D.stepCoords.length expr = true := by
    rw [hlen]; exact synthUnit_imp_wellScoped expr hu
  exact lem_substMap_denote expr hstep hws

/-- Tier-1 Monotone Scalar Lyapunov Certificate (`V ≥ 0` ∧ `V(x) - V(Φ(x)) ≥ 0`). -/
structure LyapunovTier1CertQ0 where
  V             : ExprQ0
  vNonnegCert   : NonnegCertQ0
  decNonnegCert : NonnegCertQ0
  deriving DecidableEq, Repr, Inhabited

def checkLyapunovTier1Cert (D : GuardedDynSpecQ0) (lc : LyapunovTier1CertQ0) : Bool :=
  checkDynUnitsOnly D &&
  (synthUnit D.ctx.vars lc.V).isSome &&
  checkNonnegCert D.ctx lc.V lc.vNonnegCert &&
  checkNonnegCert D.ctx (.binOp .sub lc.V (substMap D.stepCoords lc.V)) lc.decNonnegCert

/-- Target Theorem `thm_lyapunov_scalar_monotone` (`Tribunal F-D04`):
    Certifies boundedness and monotone non-increase of the **scalar Lyapunov value** `V(ρ_t)`:
      `∀ t ∈ ℕ, 0 ≤ V(ρ_{t+1}) ≤ V(ρ_t) ≤ V(ρ_0)`.
    (State-vector norm boundedness is NOT claimed without separate sublevel-set coercivity.) -/
theorem thm_lyapunov_scalar_monotone
    (D : GuardedDynSpecQ0) (lc : LyapunovTier1CertQ0)
    (hfwd : ForwardInvariant D)
    (hlc : checkLyapunovTier1Cert D lc = true)
    (ρ₀ : List Rat) (h₀ : ValidDomainQ0 ρ₀ D.ctx) :
    ∀ t : Nat, ∃ (ρt ρt1 : List Rat) (v0 vt vt1 : Rat),
      iterateStep D.stepCoords t ρ₀ = some ρt ∧
      iterateStep D.stepCoords (t + 1) ρ₀ = some ρt1 ∧
      denoteExpr ρ₀ lc.V = some v0 ∧
      denoteExpr ρt lc.V = some vt ∧
      denoteExpr ρt1 lc.V = some vt1 ∧
      0 ≤ vt1 ∧ vt1 ≤ vt ∧ vt ≤ v0 := by
  unfold checkLyapunovTier1Cert at hlc
  simp only [Bool.and_eq_true] at hlc
  rcases hlc with ⟨⟨⟨hdyn, hu_some⟩, hv_nn⟩, hdec_nn⟩
  cases huV : synthUnit D.ctx.vars lc.V with
  | none => rw [huV] at hu_some; contradiction
  | some uV =>
      have one_step_le : ∀ {ρa ρb : List Rat}, ValidDomainQ0 ρa D.ctx → ValidDomainQ0 ρb D.ctx →
          evalCoords ρa D.stepCoords = some ρb →
          ∃ va vb : Rat, denoteExpr ρa lc.V = some va ∧ denoteExpr ρb lc.V = some vb ∧
            0 ≤ vb ∧ vb ≤ va := by
        intro ρa ρb hda hdb hstep
        rcases thm_nonneg_cert_sound D.ctx lc.V lc.vNonnegCert hv_nn ρa hda with ⟨va, hdva, _, _⟩
        rcases thm_nonneg_cert_sound D.ctx lc.V lc.vNonnegCert hv_nn ρb hdb with ⟨vb, hdvb, _, hvb0⟩
        rcases thm_nonneg_cert_sound D.ctx (.binOp .sub lc.V (substMap D.stepCoords lc.V))
          lc.decNonnegCert hdec_nn ρa hda with ⟨dval, hdd, _, hd0⟩
        have hpulled : denoteExpr ρa (substMap D.stepCoords lc.V) = some vb := by
          rw [lem_eval_pulled_at_next hdyn huV hstep, hdvb]
        have hsub : denoteExpr ρa (.binOp .sub lc.V (substMap D.stepCoords lc.V)) = some (va - vb) := by
          simp [denoteExpr, evalBinOp, hdva, hpulled]
        rw [hsub] at hdd
        injection hdd with hd_eq
        exact ⟨va, vb, hdva, hdvb, hvb0, by grind⟩
      have upper_ind : ∀ t : Nat, ∃ (ρt : List Rat) (v0 vt : Rat),
          iterateStep D.stepCoords t ρ₀ = some ρt ∧ ValidDomainQ0 ρt D.ctx ∧
          denoteExpr ρ₀ lc.V = some v0 ∧ denoteExpr ρt lc.V = some vt ∧ 0 ≤ vt ∧ vt ≤ v0 := by
        intro s
        induction s with
        | zero =>
            rcases thm_nonneg_cert_sound D.ctx lc.V lc.vNonnegCert hv_nn ρ₀ h₀ with ⟨v0, hdv0, _, hv0_nn⟩
            exact ⟨ρ₀, v0, v0, rfl, h₀, hdv0, hdv0, hv0_nn, by grind⟩
        | succ s ih =>
            rcases ih with ⟨ρs, v0, vs, his, hds, hdv0, hdvs, _, hvs_le⟩
            rcases hfwd ρs hds with ⟨ρs1, hstep, hds1⟩
            rcases one_step_le hds hds1 hstep with ⟨vs', vs1, hdvs', hdvs1, hvs1_nn, hvs1_le⟩
            rw [hdvs] at hdvs'; injection hdvs' with h_eq; subst h_eq
            exact ⟨ρs1, v0, vs1, by simp [iterateStep, his, hstep], hds1, hdv0, hdvs1, hvs1_nn, by grind⟩
      intro t
      rcases upper_ind t with ⟨ρt, v0, vt, hit, hdt, hdv0, hdvt, _, hvt_le⟩
      rcases hfwd ρt hdt with ⟨ρt1, hstep, hdt1⟩
      rcases one_step_le hdt hdt1 hstep with ⟨vt', vt1, hdvt', hdvt1, hvt1_nn, hvt1_le⟩
      rw [hdvt] at hdvt'; injection hdvt' with h_eq; subst h_eq
      exact ⟨ρt, ρt1, v0, vt, vt1, hit, by simp [iterateStep, hit, hstep],
             hdv0, hdvt, hdvt1, hvt1_nn, hvt1_le, hvt_le⟩

/-- Tier-2 Geometric Scalar Contraction Certificate (`0 < α ≤ 1`, `(1 - α) V(x) - V(Φ(x)) ≥ 0`). -/
structure LyapunovTier2CertQ0 where
  V              : ExprQ0
  alpha          : Rat
  vNonnegCert    : NonnegCertQ0
  geomNonnegCert : NonnegCertQ0
  deriving DecidableEq, Repr, Inhabited

def lyapunovGeomMarginExpr (D : GuardedDynSpecQ0) (V : ExprQ0) (alpha : Rat) : ExprQ0 :=
  .binOp .sub (.binOp .mul (.ratLit (1 - alpha) UnitSpecQ0.unitless) V) (substMap D.stepCoords V)

def checkLyapunovTier2Cert (D : GuardedDynSpecQ0) (lc : LyapunovTier2CertQ0) : Bool :=
  decide (0 < lc.alpha && lc.alpha ≤ 1) &&
  checkDynUnitsOnly D &&
  (synthUnit D.ctx.vars lc.V).isSome &&
  checkNonnegCert D.ctx lc.V lc.vNonnegCert &&
  checkNonnegCert D.ctx (lyapunovGeomMarginExpr D lc.V lc.alpha) lc.geomNonnegCert

theorem rat_mul_le_mul_of_nonneg_left {c a b : Rat} (hc : 0 ≤ c) (hab : a ≤ b) :
    c * a ≤ c * b := by
  have hdiff : 0 ≤ b - a := by grind
  have hprod : 0 ≤ c * (b - a) := Rat.mul_nonneg hc hdiff
  grind

/-- Target Theorem `thm_lyapunov_scalar_geometric_decay` (`Tribunal F-D04`):
    Certifies exact geometric decay of the **scalar Lyapunov value** `V(ρ_t)`:
      `∀ t ∈ ℕ, 0 ≤ V(ρ_t) ≤ (1 - α)^t · V(ρ_0)` (`0 < α ≤ 1`).
    (Equilibrium convergence of the state vector `ρ_t` is NOT claimed without coercivity.) -/
theorem thm_lyapunov_scalar_geometric_decay
    (D : GuardedDynSpecQ0) (lc : LyapunovTier2CertQ0)
    (hfwd : ForwardInvariant D)
    (hlc : checkLyapunovTier2Cert D lc = true)
    (ρ₀ : List Rat) (h₀ : ValidDomainQ0 ρ₀ D.ctx) :
    ∀ t : Nat, ∃ (ρt : List Rat) (v0 vt : Rat),
      iterateStep D.stepCoords t ρ₀ = some ρt ∧
      denoteExpr ρ₀ lc.V = some v0 ∧
      denoteExpr ρt lc.V = some vt ∧
      0 ≤ vt ∧ vt ≤ ratPow (1 - lc.alpha) t * v0 := by
  unfold checkLyapunovTier2Cert at hlc
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hlc
  rcases hlc with ⟨⟨⟨⟨⟨halpha_pos, halpha_le1⟩, hdyn⟩, hu_some⟩, hv_nn⟩, hgeom_nn⟩
  have h1ma_nn : 0 ≤ 1 - lc.alpha := by grind
  cases huV : synthUnit D.ctx.vars lc.V with
  | none => rw [huV] at hu_some; contradiction
  | some uV =>
      intro t
      induction t with
      | zero =>
          rcases thm_nonneg_cert_sound D.ctx lc.V lc.vNonnegCert hv_nn ρ₀ h₀ with ⟨v0, hdv0, _, hv0_nn⟩
          refine ⟨ρ₀, v0, v0, rfl, hdv0, hdv0, hv0_nn, ?_⟩
          simp [ratPow, Rat.one_mul]
      | succ s ih =>
          rcases ih with ⟨ρs, v0, vs, his, hdv0, hdvs, _, hvs_bound⟩
          rcases thm_forward_invariant_all_steps D hfwd ρ₀ h₀ s with ⟨ρs', his', hds⟩
          rw [his] at his'; injection his' with h_eq; subst h_eq
          rcases hfwd ρs hds with ⟨ρs1, hstep, hds1⟩
          rcases thm_nonneg_cert_sound D.ctx lc.V lc.vNonnegCert hv_nn ρs1 hds1 with ⟨vs1, hdvs1, _, hvs1_nn⟩
          rcases thm_nonneg_cert_sound D.ctx (lyapunovGeomMarginExpr D lc.V lc.alpha)
            lc.geomNonnegCert hgeom_nn ρs hds with ⟨mval, hdm, _, hm0⟩
          have hpulled : denoteExpr ρs (substMap D.stepCoords lc.V) = some vs1 := by
            rw [lem_eval_pulled_at_next hdyn huV hstep, hdvs1]
          have hmeval : denoteExpr ρs (lyapunovGeomMarginExpr D lc.V lc.alpha) =
              some ((1 - lc.alpha) * vs - vs1) := by
            simp [lyapunovGeomMarginExpr, denoteExpr, evalBinOp, hdvs, hpulled]
          rw [hmeval] at hdm; injection hdm with hm_eq
          have hstep_decay : vs1 ≤ (1 - lc.alpha) * vs := by grind
          have hmult := rat_mul_le_mul_of_nonneg_left h1ma_nn hvs_bound
          have htot : vs1 ≤ ratPow (1 - lc.alpha) (s + 1) * v0 := by
            simp only [ratPow_succ]
            rw [Rat.mul_assoc]
            grind
          exact ⟨ρs1, v0, vs1, by simp [iterateStep, his, hstep], hdv0, hdvs1, hvs1_nn, htot⟩

/-! ### Part 3: Discrete Control Barrier Certificate & The `0 < γ ≤ 1` Overshoot Gate -/

/-- Discrete CBF margin `B(Φ(x)) - (1 - γ) B(x)` (`0 < γ ≤ 1`). -/
def cbfMarginExpr (D : GuardedDynSpecQ0) (B : ExprQ0) (gamma : Rat) : ExprQ0 :=
  .binOp .sub (substMap D.stepCoords B) (.binOp .mul (.ratLit (1 - gamma) UnitSpecQ0.unitless) B)

structure DiscreteCBFCertQ0 where
  B          : ExprQ0
  gamma      : Rat
  marginCert : NonnegCertQ0
  deriving DecidableEq, Repr, Inhabited

def checkCBFGammaValid (gamma : Rat) : Bool :=
  decide (0 < gamma && gamma ≤ 1)

def checkDiscreteCBFCert (D : GuardedDynSpecQ0) (cbf : DiscreteCBFCertQ0) : Bool :=
  checkCBFGammaValid cbf.gamma &&
  checkDynUnitsOnly D &&
  (synthUnit D.ctx.vars cbf.B).isSome &&
  checkNonnegCert D.ctx (cbfMarginExpr D cbf.B cbf.gamma) cbf.marginCert

/-- Target Theorem `thm_discrete_cbf_all_time`:
    Whenever `0 < γ ≤ 1` (`checkDiscreteCBFCert D cbf = true`), `ForwardInvariant D` holds,
    and `B(ρ₀) ≥ 0` at `ρ₀ ∈ Real_ℚ(D.ctx)`, the barrier superlevel condition `B(ρ_t) ≥ 0`
    (specifically `B(ρ_t) ≥ (1 - γ)^t B(ρ₀) ≥ 0`) holds for ALL `t ∈ ℕ`! -/
theorem thm_discrete_cbf_all_time
    (D : GuardedDynSpecQ0) (cbf : DiscreteCBFCertQ0)
    (hfwd : ForwardInvariant D)
    (hcbf : checkDiscreteCBFCert D cbf = true)
    (ρ₀ : List Rat) (h₀ : ValidDomainQ0 ρ₀ D.ctx)
    (b₀ : Rat) (hb₀_eval : denoteExpr ρ₀ cbf.B = some b₀) (hb₀_nn : 0 ≤ b₀) :
    ∀ t : Nat, ∃ (ρt : List Rat) (bt : Rat),
      iterateStep D.stepCoords t ρ₀ = some ρt ∧
      denoteExpr ρt cbf.B = some bt ∧
      ratPow (1 - cbf.gamma) t * b₀ ≤ bt ∧ 0 ≤ bt := by
  unfold checkDiscreteCBFCert checkCBFGammaValid at hcbf
  simp only [Bool.and_eq_true, decide_eq_true_eq] at hcbf
  rcases hcbf with ⟨⟨⟨⟨_, hgamma_le1⟩, hdyn⟩, hu_some⟩, hmargin_nn⟩
  have h1mg_nn : 0 ≤ 1 - cbf.gamma := by grind
  cases huB : synthUnit D.ctx.vars cbf.B with
  | none => rw [huB] at hu_some; contradiction
  | some uB =>
      intro t
      induction t with
      | zero =>
          refine ⟨ρ₀, b₀, rfl, hb₀_eval, ?_, hb₀_nn⟩
          simp [ratPow, Rat.one_mul]
      | succ s ih =>
          rcases ih with ⟨ρs, bs, his, hdbs, hbs_low, hbs_nn⟩
          rcases thm_forward_invariant_all_steps D hfwd ρ₀ h₀ s with ⟨ρs', his', hds⟩
          rw [his] at his'; injection his' with h_eq; subst h_eq
          rcases hfwd ρs hds with ⟨ρs1, hstep, _⟩
          rcases thm_nonneg_cert_sound D.ctx (cbfMarginExpr D cbf.B cbf.gamma)
            cbf.marginCert hmargin_nn ρs hds with ⟨mval, hdm, _, hm0⟩
          -- Since `cbfMarginExpr` evaluated to `some mval` and `(1 - γ) * B(ρs)` is `some`,
          -- `substMap D.stepCoords B` at `ρs` (= `denoteExpr ρs1 B`) MUST be `some bs1`!
          have hpulled_eq := lem_eval_pulled_at_next hdyn huB hstep
          unfold cbfMarginExpr at hdm
          cases hdbs1 : denoteExpr ρs1 cbf.B with
          | none =>
              simp [denoteExpr, evalBinOp, hpulled_eq, hdbs1] at hdm
          | some bs1 =>
              have hmeval : denoteExpr ρs (.binOp .sub (substMap D.stepCoords cbf.B)
                  (.binOp .mul (.ratLit (1 - cbf.gamma) UnitSpecQ0.unitless) cbf.B)) =
                  some (bs1 - (1 - cbf.gamma) * bs) := by
                simp [denoteExpr, evalBinOp, hpulled_eq, hdbs1, hdbs]
              rw [hmeval] at hdm; injection hdm with hm_eq
              have hstep_ge : (1 - cbf.gamma) * bs ≤ bs1 := by grind
              have hmult := rat_mul_le_mul_of_nonneg_left h1mg_nn hbs_low
              have hlow_next : ratPow (1 - cbf.gamma) (s + 1) * b₀ ≤ bs1 := by
                simp only [ratPow_succ]
                rw [Rat.mul_assoc]
                grind
              have hbs1_nn : 0 ≤ bs1 := by
                have hprod_nn := Rat.mul_nonneg h1mg_nn hbs_nn
                grind
              exact ⟨ρs1, bs1, by simp [iterateStep, his, hstep], hdbs1, hlow_next, hbs1_nn⟩

end GrandZero.StageD
