/-
  GRANDZERO Ω — Stage D (Algebraic Dynamics, Invariants, Barriers & Memory Gate)
  Module D-4: Q0SheafDynamicsAndMemoryObstruction.lean
  Scope:
    1. Matrix powers `matPow` & semigroup law `matPow_add`.
    2. Cellular Sheaf `H⁰` Dynamical Equivariance (`thm_sheaf_h0_dynamics_invariant`)
       vs. Vertex-Driven Sheaf Tearing (`thm_sheaf_dynamics_tear_coboundary`, `Tribunal F-D02`:
       proving `x₀ ∈ ker(δ⁰) ∧ δ⁰(A₀ x₀) ≠ 0` while simultaneously proving
       `LH(δ⁰(A₀ x₀)) = 0`, i.e. `[η₁] = 0 ∈ H¹(X; F)` identically!).
    3. Finite-Window Time-Homogeneous `ℚ`-Linear Markov Closure No-Go (`thm_markov_closure_no_go`,
       `Tribunal F-D05`) & Exact Hidden-Fiber Semigroup Realization (`thm_hidden_fiber_markov_realization`).
    4. Deterministic 8-Way `auditStageDDynamicsGate` & Master Soundness / Mutual-Exclusion Theorems.
-/

import StageD.Q0LyapunovAndBarrierCerts

namespace GrandZero.StageD

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC

/-! ### Part 1: Exact Rational Matrix Powers & Semigroup Homomorphism -/

def matPow {n : Nat} (A : MatQ0 n n) : Nat → MatQ0 n n
  | 0     => idMat n
  | t + 1 => matMul A (matPow A t)

@[simp] theorem matPow_zero {n : Nat} (A : MatQ0 n n) :
    matPow A 0 = idMat n := rfl

@[simp] theorem matPow_succ {n : Nat} (A : MatQ0 n n) (t : Nat) :
    matPow A (t + 1) = matMul A (matPow A t) := rfl

theorem matPow_add {n : Nat} (A : MatQ0 n n) :
    ∀ (s t : Nat), matPow A (s + t) = matMul (matPow A s) (matPow A t)
  | 0, t => by simp [matPow, matMul_id_left]
  | s + 1, t => by
      have h : s + 1 + t = (s + t) + 1 := by omega
      rw [h, matPow_succ, matPow_succ, matPow_add A s t, matMul_assoc]

/-! ### Part 2: Cellular Sheaf `H⁰` Equivariance vs. Coboundary Tearing (`Tribunal F-D02`) -/

/-- Check cochain intertwining `δ⁰ A₀ == A₁ δ⁰` on a `CellularSheafQ0`. -/
def checkSheafDynEquivariant
    (S : CellularSheafQ0) (A0 : MatQ0 S.N0 S.N0) (A1 : MatQ0 S.N1 S.N1) : Bool :=
  (validateSheafComplexStructure S == none) &&
  matEqBool (matMul (assembleDelta0 S) A0) (matMul A1 (assembleDelta0 S))

theorem thm_sheaf_intertwine_all_steps
    (S : CellularSheafQ0) (A0 : MatQ0 S.N0 S.N0) (A1 : MatQ0 S.N1 S.N1)
    (heq : checkSheafDynEquivariant S A0 A1 = true) :
    ∀ (t : Nat), matMul (assembleDelta0 S) (matPow A0 t) = matMul (matPow A1 t) (assembleDelta0 S)
  | 0 => by simp [matPow, matMul_id_right, matMul_id_left]
  | t + 1 => by
      unfold checkSheafDynEquivariant at heq
      simp only [Bool.and_eq_true, matEqBool_iff] at heq
      calc
        matMul (assembleDelta0 S) (matMul A0 (matPow A0 t))
            = matMul (matMul (assembleDelta0 S) A0) (matPow A0 t) := (matMul_assoc _ _ _).symm
        _ = matMul (matMul A1 (assembleDelta0 S)) (matPow A0 t) := by rw [heq.2]
        _ = matMul A1 (matMul (assembleDelta0 S) (matPow A0 t)) := matMul_assoc _ _ _
        _ = matMul A1 (matMul (matPow A1 t) (assembleDelta0 S)) := by
              rw [thm_sheaf_intertwine_all_steps S A0 A1 (by
                unfold checkSheafDynEquivariant
                simp [heq.1, matEqBool_iff, heq.2]) t]
        _ = matMul (matMul A1 (matPow A1 t)) (assembleDelta0 S) := (matMul_assoc _ _ _).symm

/-- Target Theorem `thm_sheaf_h0_dynamics_invariant`:
    Under cochain intertwining `δ⁰ A₀ = A₁ δ⁰`, every global section `x₀ ∈ H⁰(X; F) = ker(δ⁰)`
    remains a valid global section `A₀^t x₀ ∈ ker(δ⁰)` for ALL `t ∈ ℕ`. -/
theorem thm_sheaf_h0_dynamics_invariant
    (S : CellularSheafQ0) (A0 : MatQ0 S.N0 S.N0) (A1 : MatQ0 S.N1 S.N1)
    (heq : checkSheafDynEquivariant S A0 A1 = true)
    (x0 : VecQ0 S.N0) (hx0 : matVec (assembleDelta0 S) x0 = zeroVec S.N1) :
    ∀ t : Nat, matVec (assembleDelta0 S) (matVec (matPow A0 t) x0) = zeroVec S.N1 := by
  intro t
  rw [← matVec_matMul, thm_sheaf_intertwine_all_steps S A0 A1 heq t, matVec_matMul, hx0, matVec_zero]

/-- Executable check for 1-step vertex-driven sheaf `H⁰` gluing tear (`Tribunal F-D02`). -/
def checkSheafDynamicsTear
    (S : CellularSheafQ0)
    (cc : CohomologyComplementBasis S.N0 S.N1 S.N2)
    (A0 : MatQ0 S.N0 S.N0) (x0 : VecQ0 S.N0) : Bool :=
  (validateSheafComplexStructure S == none) &&
  checkCohomologyCert (assembleDelta0 S) (assembleDelta1 S) cc &&
  vecEqBool (matVec (assembleDelta0 S) x0) (zeroVec S.N1) &&
  !vecEqBool (matVec (assembleDelta0 S) (matVec A0 x0)) (zeroVec S.N1)

/-- Target Theorem `thm_sheaf_dynamics_tear_coboundary` (`Tribunal F-D02` Exact Resolution):
    Whenever `checkSheafDynamicsTear S cc A0 x0 = true`:
      1. `x0 ∈ ker(δ⁰)` (valid initial global section in `H⁰`),
      2. `δ⁰ (A0 x0) ≠ 0` (1-step breakdown of `H⁰` global-section gluing),
      3. `∀ A1, checkSheafDynEquivariant S A0 A1 = false` (no 1-cochain intertwiner exists), AND
      4. `LH (δ⁰ (A0 x0)) = 0` — i.e., the induced edge discrepancy `η₁ = δ⁰(A₀ x₀)` lies in
         `im(δ⁰)` and therefore defines the **ZERO** class `[η₁] = 0 ∈ H¹(X; F)`! -/
theorem thm_sheaf_dynamics_tear_coboundary
    (S : CellularSheafQ0)
    (cc : CohomologyComplementBasis S.N0 S.N1 S.N2)
    (A0 : MatQ0 S.N0 S.N0) (x0 : VecQ0 S.N0)
    (htear : checkSheafDynamicsTear S cc A0 x0 = true) :
    matVec (assembleDelta0 S) x0 = zeroVec S.N1 ∧
    matVec (assembleDelta0 S) (matVec A0 x0) ≠ zeroVec S.N1 ∧
    (∀ A1 : MatQ0 S.N1 S.N1, checkSheafDynEquivariant S A0 A1 = false) ∧
    matVec cc.LH (matVec (assembleDelta0 S) (matVec A0 x0)) = zeroVec cc.h1 := by
  unfold checkSheafDynamicsTear at htear
  simp only [Bool.and_eq_true, vecEqBool_iff, Bool.not_eq_true'] at htear
  rcases htear with ⟨⟨⟨_, hcc⟩, hx0_ker⟩, htear_b⟩
  have htear_nz : matVec (assembleDelta0 S) (matVec A0 x0) ≠ zeroVec S.N1 := by
    intro heq
    rw [(vecEqBool_iff _ _).mpr heq] at htear_b
    contradiction
  have hno_intertwine : ∀ A1 : MatQ0 S.N1 S.N1, checkSheafDynEquivariant S A0 A1 = false := by
    intro A1
    cases heq : checkSheafDynEquivariant S A0 A1 with
    | false => rfl
    | true =>
        have h1 := thm_sheaf_h0_dynamics_invariant S A0 A1 heq x0 hx0_ker 1
        simp only [matPow_succ, matPow_zero, matMul_id_right] at h1
        exact False.elim (htear_nz h1)
  have hlh_zero : matVec cc.LH (matVec (assembleDelta0 S) (matVec A0 x0)) = zeroVec cc.h1 :=
    (thm_h1_quotient_decomp_unique (assembleDelta0 S) (assembleDelta1 S) cc hcc).2.1 (matVec A0 x0)
  exact ⟨hx0_ker, htear_nz, hno_intertwine, hlh_zero⟩

/-! ### Part 3: Scoped Finite-Window Linear Markov No-Go & Hidden-Fiber Lift (`Tribunal F-D05`) -/

/-- Extract column `k : Fin K` of a matrix `X : MatQ0 d K`. -/
def matCol {d K : Nat} (X : MatQ0 d K) (k : Fin K) : VecQ0 d :=
  fun i => X i k

/-- Computable witness checker proving `Xpast · u = 0 ∧ Ynext · u ≠ 0` (`F-D05`). -/
def checkLinearMarkovNoGo {dVis K : Nat}
    (Xpast Ynext : MatQ0 dVis K) (u : VecQ0 K) : Bool :=
  vecEqBool (matVec Xpast u) (zeroVec dVis) &&
  !vecEqBool (matVec Ynext u) (zeroVec dVis)

/-- Target Theorem `thm_markov_closure_no_go` (`Tribunal F-D05` Explicit Model-Class Scope):
    Over the finite observed transition window `(Xpast, Ynext) ∈ ℚ^{dVis × K}`, if
    `checkLinearMarkovNoGo Xpast Ynext u = true`, then **NO time-homogeneous `ℚ`-linear
    Markov transition operator `M ∈ MatQ0 dVis dVis`** satisfies `M · Xpast = Ynext`.
    (Nonlinear Markov maps and time-varying linear operators lie outside this quantified class.) -/
theorem thm_markov_closure_no_go {dVis K : Nat}
    (Xpast Ynext : MatQ0 dVis K) (u : VecQ0 K)
    (hng : checkLinearMarkovNoGo Xpast Ynext u = true) :
    ∀ M : MatQ0 dVis dVis, matMul M Xpast ≠ Ynext := by
  unfold checkLinearMarkovNoGo at hng
  simp only [Bool.and_eq_true, vecEqBool_iff, Bool.not_eq_true'] at hng
  rcases hng with ⟨hXu, hYu_b⟩
  have hYu_nz : matVec Ynext u ≠ zeroVec dVis := by
    intro heq
    rw [(vecEqBool_iff _ _).mpr heq] at hYu_b
    contradiction
  intro M hMX
  have h1 : matVec Ynext u = matVec (matMul M Xpast) u := by rw [hMX]
  rw [matVec_matMul, hXu, matVec_zero] at h1
  exact hYu_nz h1

/-- Exact hidden-memory linear semigroup lift `(Atilde, PiProj, z0)` on `ℚ^{dVis + dMem}`. -/
structure HiddenFiberLiftQ0 (dVis : Nat) where
  dMem   : Nat
  Atilde : MatQ0 (dVis + dMem) (dVis + dMem)
  PiProj : MatQ0 dVis (dVis + dMem)
  z0     : VecQ0 (dVis + dMem)

/-- Projected visible trajectory `y^{lift}(t) = Π (Ã^t z₀)` for arbitrary `t ∈ ℕ`. -/
def liftedTrajectoryObs {dVis : Nat} (L : HiddenFiberLiftQ0 dVis) (t : Nat) : VecQ0 dVis :=
  matVec L.PiProj (matVec (matPow L.Atilde t) L.z0)

/-- Finite-window observation match check (`∀ k < K`, `Xpast[:,k] = y(k)` ∧ `Ynext[:,k] = y(k+1)`). -/
def checkHiddenFiberRealization {dVis K : Nat}
    (Xpast Ynext : MatQ0 dVis K) (L : HiddenFiberLiftQ0 dVis) : Bool :=
  allFin K fun k =>
    vecEqBool (matCol Xpast k) (liftedTrajectoryObs L k.val) &&
    vecEqBool (matCol Ynext k) (liftedTrajectoryObs L (k.val + 1))

/-- Target Theorem `thm_hidden_fiber_markov_realization` (`Tribunal F-D05`):
    Separates (1) the all-time semigroup law of the lifted state `z(s + t) = Ã^s z(t)` on
    `ℚ^{dVis + dMem}` from (2) exact reproduction of all `K` observed finite-window transitions. -/
theorem thm_hidden_fiber_markov_realization {dVis K : Nat}
    (Xpast Ynext : MatQ0 dVis K) (L : HiddenFiberLiftQ0 dVis)
    (hreal : checkHiddenFiberRealization Xpast Ynext L = true) :
    (∀ s t : Nat,
      matVec (matPow L.Atilde (s + t)) L.z0 =
      matVec (matPow L.Atilde s) (matVec (matPow L.Atilde t) L.z0)) ∧
    (∀ k : Fin K,
      matCol Xpast k = liftedTrajectoryObs L k.val ∧
      matCol Ynext k = liftedTrajectoryObs L (k.val + 1)) := by
  refine ⟨?_, ?_⟩
  · intro s t
    rw [matPow_add, matVec_matMul]
  · intro k
    unfold checkHiddenFiberRealization at hreal
    have hk := (allFin_iff K _).mp hreal k
    simp only [Bool.and_eq_true, vecEqBool_iff] at hk
    exact hk

/-! ### Part 4: Deterministic 8-Way `auditStageDDynamicsGate` & Master Soundness Theorems -/

/-- Strict 8-way `Stage D` Gate Outcome (`Section 3`). -/
inductive StageDGateOutcomeQ0 where
  | verifiedEmptySafeDomain             : StageDGateOutcomeQ0
  | verifiedForwardSafeAndInvariant     : StageDGateOutcomeQ0
  | verifiedDiscreteDriftObstruction    : StageDGateOutcomeQ0
  | verifiedBarrierSafetyViolation      : StageDGateOutcomeQ0
  | verifiedSheafDynamicsTear           : StageDGateOutcomeQ0
  | verifiedMarkovianClosureObstruction : StageDGateOutcomeQ0
  | rejectedInvalidDynamicsSpec         : StageDInvalidReasonQ0 → StageDGateOutcomeQ0
  | rejectedInvalidCertificate          : StageDGateOutcomeQ0
  deriving DecidableEq, Repr, Inhabited

/-- Unified `Stage D` specification supporting guarded dynamics, observables, Lyapunov/CBF
    rate parameters, and optional underlying `Stage C` cellular sheaf. -/
structure StageDSpecQ0 where
  dyn          : GuardedDynSpecQ0
  optObs       : Option ExprQ0 := none
  optCBFGamma  : Option Rat := none
  optLyapAlpha : Option Rat := none
  optSheaf     : Option CellularSheafQ0 := none

/-- Deterministic 4-step static validator for `StageDSpecQ0`. -/
def validateStageDSpec (S : StageDSpecQ0) : Option StageDInvalidReasonQ0 :=
  let obsTypedOk :=
    match S.optObs with
    | none     => true
    | some obs => (synthUnit S.dyn.ctx.vars obs).isSome
  if !(checkDynUnitsOnly S.dyn && obsTypedOk) then
    some .illTypedDynamics
  else if !checkAuthorityLe S.dyn.claimedAuth S.dyn.sysAuth then
    some .authorityEscalation
  else
    let gammaOk :=
      match S.optCBFGamma with
      | none   => true
      | some γ => checkCBFGammaValid γ
    let alphaOk :=
      match S.optLyapAlpha with
      | none   => true
      | some α => decide (0 < α && α ≤ 1)
    if !(gammaOk && alphaOk) then
      some .invalidBarrierOrRate
    else
      match S.optSheaf with
      | none    => none
      | some sh =>
          if (validateSheafComplexStructure sh).isSome then
            some .invalidSheafBase
          else
            none

/-- Mode-specific certificate bundle submitted to `auditStageDDynamicsGate`. -/
inductive StageDCertBundleQ0 where
  | emptySafeDomain
      (emptyCert : EmptyOverlapCertQ0)
  | forwardSafeAndInvariant
      (initPt   : List Rat)
      (stepCert : BridgeCertQ0)
      (optInv   : Option DiscreteInvariantCertQ0)
      (optLyap2 : Option LyapunovTier2CertQ0)
      (optCBF   : Option DiscreteCBFCertQ0)
  | discreteDriftWitness
      (initPt   : List Rat)
  | barrierEscapeWitness
      (initPt   : List Rat)
      (tEscape  : Nat)
  | sheafTearWitness
      (sh : CellularSheafQ0)
      (cc : CohomologyComplementBasis sh.N0 sh.N1 sh.N2)
      (A0 : MatQ0 sh.N0 sh.N0)
      (x0 : VecQ0 sh.N0)
  | markovNoGoWitness
      (dVis K : Nat)
      (Xpast  : MatQ0 dVis K)
      (Ynext  : MatQ0 dVis K)
      (uDual  : VecQ0 K)
      (lift   : HiddenFiberLiftQ0 dVis)

/-- Extracted helper checker for `.forwardSafeAndInvariant` bundles. -/
def checkForwardSafeBundle
    (S : StageDSpecQ0)
    (ρ₀ : List Rat)
    (stepCert : BridgeCertQ0)
    (optInv : Option DiscreteInvariantCertQ0)
    (optLyap2 : Option LyapunovTier2CertQ0)
    (optCBF : Option DiscreteCBFCertQ0) : Bool :=
  let baseOk :=
    checkValidDomainQ0 ρ₀ S.dyn.ctx &&
    checkBridgeCert S.dyn.toStepBridge stepCert
  let invOk :=
    match S.optObs, optInv with
    | none,     none    => true
    | some obs, some ic => checkDiscreteInvariantCert S.dyn obs ic
    | _,        _       => false
  let lyapOk :=
    match S.optLyapAlpha, optLyap2 with
    | none,   none    => true
    | some α, some lc => decide (lc.alpha = α) && checkLyapunovTier2Cert S.dyn lc
    | _,      _       => false
  let cbfOk :=
    match S.optCBFGamma, optCBF with
    | none,   none     => true
    | some γ, some cbf =>
        decide (cbf.gamma = γ) &&
        checkDiscreteCBFCert S.dyn cbf &&
        match denoteExpr ρ₀ cbf.B with
        | some b0 => decide (0 ≤ b0)
        | none    => false
    | _,      _        => false
  baseOk && invOk && lyapOk && cbfOk

/-- Extracted helper checker for `.barrierEscapeWitness` bundles. -/
def checkBarrierEscapeBundle
    (S : StageDSpecQ0) (ρ₀ : List Rat) (tEsc : Nat) : Bool :=
  decide (1 ≤ tEsc) &&
  checkValidDomainQ0 ρ₀ S.dyn.ctx &&
  match iterateStep S.dyn.stepCoords tEsc ρ₀ with
  | none    => true
  | some ρt => !checkValidDomainQ0 ρt S.dyn.ctx

/-- Trusted Deterministic `Stage D` Gate (`auditStageDDynamicsGate`). -/
def auditStageDDynamicsGate (S : StageDSpecQ0) (bundle : StageDCertBundleQ0) : StageDGateOutcomeQ0 :=
  match validateStageDSpec S with
  | some invalidReason =>
      .rejectedInvalidDynamicsSpec invalidReason
  | none =>
      match bundle with
      | .emptySafeDomain ec =>
          if checkEmptyOverlapCert S.dyn.ctx ec then
            .verifiedEmptySafeDomain
          else
            .rejectedInvalidCertificate
      | .forwardSafeAndInvariant ρ₀ stepCert optInv optLyap2 optCBF =>
          if checkForwardSafeBundle S ρ₀ stepCert optInv optLyap2 optCBF then
            .verifiedForwardSafeAndInvariant
          else
            .rejectedInvalidCertificate
      | .discreteDriftWitness ρ₀ =>
          match S.optObs with
          | none     => .rejectedInvalidCertificate
          | some obs =>
              if checkStepDriftWitness S.dyn obs ρ₀ then
                .verifiedDiscreteDriftObstruction
              else
                .rejectedInvalidCertificate
      | .barrierEscapeWitness ρ₀ tEsc =>
          if checkBarrierEscapeBundle S ρ₀ tEsc then
            .verifiedBarrierSafetyViolation
          else
            .rejectedInvalidCertificate
      | .sheafTearWitness sh cc A0 x0 =>
          if checkSheafDynamicsTear sh cc A0 x0 then
            .verifiedSheafDynamicsTear
          else
            .rejectedInvalidCertificate
      | .markovNoGoWitness _ _ Xpast Ynext uDual lift =>
          if checkLinearMarkovNoGo Xpast Ynext uDual &&
             checkHiddenFiberRealization Xpast Ynext lift then
            .verifiedMarkovianClosureObstruction
          else
            .rejectedInvalidCertificate

/-- Universal Static Rejection Precedence Theorem:
    Any invalid `StageDSpecQ0` (`.illTypedDynamics`, `.authorityEscalation`,
    `.invalidBarrierOrRate`, `.invalidSheafBase`) deterministically rejects **ALL** bundles. -/
theorem thm_stageD_invalid_spec_universal_reject
    (S : StageDSpecQ0) (reason : StageDInvalidReasonQ0)
    (hval : validateStageDSpec S = some reason) :
    ∀ bundle : StageDCertBundleQ0,
      auditStageDDynamicsGate S bundle = .rejectedInvalidDynamicsSpec reason := by
  intro bundle
  simp [auditStageDDynamicsGate, hval]

/-- Master Soundness Theorem for `.verifiedForwardSafeAndInvariant`:
    Guarantees 3D authority conservation, `NonVacuousForwardInvariant S.dyn`,
    and all-time (`∀ t ∈ ℕ`) pole-free domain safety (plus exact discrete conservation
    whenever `S.optObs = some obs`). -/
theorem thm_stageD_forward_safe_sound
    (S : StageDSpecQ0) (bundle : StageDCertBundleQ0)
    (hok : auditStageDDynamicsGate S bundle = .verifiedForwardSafeAndInvariant) :
    AuthorityLe S.dyn.claimedAuth S.dyn.sysAuth ∧
    NonVacuousForwardInvariant S.dyn ∧
    (∃ ρ₀ : List Rat, ValidDomainQ0 ρ₀ S.dyn.ctx ∧
      ∀ t : Nat, ∃ ρt : List Rat,
        iterateStep S.dyn.stepCoords t ρ₀ = some ρt ∧ ValidDomainQ0 ρt S.dyn.ctx) ∧
    (∀ obs : ExprQ0, S.optObs = some obs →
      ∃ ic : DiscreteInvariantCertQ0, checkDiscreteInvariantCert S.dyn obs ic = true) := by
  unfold auditStageDDynamicsGate at hok
  cases hval : validateStageDSpec S with
  | some _ => rw [hval] at hok; contradiction
  | none =>
      rw [hval] at hok; dsimp only at hok
      cases bundle with
      | emptySafeDomain ec =>
          cases he : checkEmptyOverlapCert S.dyn.ctx ec <;> simp [he] at hok
      | discreteDriftWitness ρ₀ =>
          cases ho : S.optObs with
          | none => simp [ho] at hok
          | some obs =>
              rw [ho] at hok; dsimp only at hok
              cases hd : checkStepDriftWitness S.dyn obs ρ₀ <;> simp [hd] at hok
      | barrierEscapeWitness ρ₀ tEsc =>
          cases hb : checkBarrierEscapeBundle S ρ₀ tEsc <;> simp [hb] at hok
      | sheafTearWitness sh cc A0 x0 =>
          cases ht : checkSheafDynamicsTear sh cc A0 x0 <;> simp [ht] at hok
      | markovNoGoWitness _ _ Xp Yn uD lf =>
          cases hm : (checkLinearMarkovNoGo Xp Yn uD && checkHiddenFiberRealization Xp Yn lf) <;>
            simp [hm] at hok
      | forwardSafeAndInvariant ρ₀ stepCert optInv optLyap2 optCBF =>
          cases hf : checkForwardSafeBundle S ρ₀ stepCert optInv optLyap2 optCBF with
          | false => simp [hf] at hok
          | true =>
              unfold checkForwardSafeBundle at hf
              simp only [Bool.and_eq_true] at hf
              rcases hf with ⟨⟨⟨⟨hdom_b, hcert_b⟩, hinv_b⟩, _⟩, _⟩
              rcases thm_certified_step_all_time_safe S.dyn stepCert ρ₀ hcert_b hdom_b with
                ⟨hauth, hnv, hall_t⟩
              have h₀ : ValidDomainQ0 ρ₀ S.dyn.ctx := (lem_checkValidDomain_iff ρ₀ S.dyn.ctx).mp hdom_b
              refine ⟨hauth, hnv, ⟨ρ₀, h₀, hall_t⟩, ?_⟩
              intro obs hobs
              rw [hobs] at hinv_b
              cases optInv with
              | none => simp at hinv_b
              | some ic => exact ⟨ic, hinv_b⟩

/-- Master Soundness & Exclusion Theorem for `.verifiedEmptySafeDomain`:
    Proves `∀ ρ, ¬ ValidDomainQ0 ρ S.dyn.ctx` and universally excludes `.verifiedForwardSafeAndInvariant`. -/
theorem thm_stageD_empty_domain_sound_and_exclusive
    (S : StageDSpecQ0) (bundle : StageDCertBundleQ0)
    (hemp : auditStageDDynamicsGate S bundle = .verifiedEmptySafeDomain) :
    (∀ ρ : List Rat, ¬ ValidDomainQ0 ρ S.dyn.ctx) ∧
    (∀ b_any : StageDCertBundleQ0,
      auditStageDDynamicsGate S b_any ≠ .verifiedForwardSafeAndInvariant) := by
  have hno_dom : ∀ ρ : List Rat, ¬ ValidDomainQ0 ρ S.dyn.ctx := by
    unfold auditStageDDynamicsGate at hemp
    cases hval : validateStageDSpec S with
    | some _ => rw [hval] at hemp; contradiction
    | none =>
        rw [hval] at hemp; dsimp only at hemp
        cases bundle with
        | emptySafeDomain ec =>
            cases he : checkEmptyOverlapCert S.dyn.ctx ec with
            | false => simp [he] at hemp
            | true => exact thm_empty_overlap_sound S.dyn.ctx ec he
        | forwardSafeAndInvariant ρ₀ sc oi ol oc =>
            cases hf : checkForwardSafeBundle S ρ₀ sc oi ol oc <;> simp [hf] at hemp
        | discreteDriftWitness ρ₀ =>
            cases ho : S.optObs with
            | none => simp [ho] at hemp
            | some obs =>
                rw [ho] at hemp; dsimp only at hemp
                cases hd : checkStepDriftWitness S.dyn obs ρ₀ <;> simp [hd] at hemp
        | barrierEscapeWitness ρ₀ tEsc =>
            cases hb : checkBarrierEscapeBundle S ρ₀ tEsc <;> simp [hb] at hemp
        | sheafTearWitness sh cc A0 x0 =>
            cases ht : checkSheafDynamicsTear sh cc A0 x0 <;> simp [ht] at hemp
        | markovNoGoWitness _ _ Xp Yn uD lf =>
            cases hm : (checkLinearMarkovNoGo Xp Yn uD && checkHiddenFiberRealization Xp Yn lf) <;>
              simp [hm] at hemp
  refine ⟨hno_dom, fun b_any hsafe => ?_⟩
  rcases (thm_stageD_forward_safe_sound S b_any hsafe).2.1.1 with ⟨ρ₀, h₀⟩
  exact hno_dom ρ₀ h₀

/-- Master Soundness & Exclusion Theorem for `.verifiedDiscreteDriftObstruction`:
    Proves non-zero 1-step drift at a valid state `ρ₀ ∈ Real_ℚ(S.dyn.ctx)` AND universally
    excludes BOTH `.verifiedForwardSafeAndInvariant` and `.verifiedEmptySafeDomain`! -/
theorem thm_stageD_drift_obstruction_sound_and_exclusive
    (S : StageDSpecQ0) (bundle : StageDCertBundleQ0)
    (hdrift : auditStageDDynamicsGate S bundle = .verifiedDiscreteDriftObstruction) :
    (∃ (obs : ExprQ0) (ρ₀ : List Rat) (d : Rat),
      S.optObs = some obs ∧
      ValidDomainQ0 ρ₀ S.dyn.ctx ∧
      denoteExpr ρ₀ (stepDriftExpr S.dyn obs) = some d ∧ d ≠ 0 ∧
      (∀ ic : DiscreteInvariantCertQ0, checkDiscreteInvariantCert S.dyn obs ic = false)) ∧
    (∀ b_any : StageDCertBundleQ0,
      auditStageDDynamicsGate S b_any ≠ .verifiedForwardSafeAndInvariant ∧
      auditStageDDynamicsGate S b_any ≠ .verifiedEmptySafeDomain) := by
  have core : ∃ (obs : ExprQ0) (ρ₀ : List Rat) (d : Rat),
      S.optObs = some obs ∧
      ValidDomainQ0 ρ₀ S.dyn.ctx ∧
      denoteExpr ρ₀ (stepDriftExpr S.dyn obs) = some d ∧ d ≠ 0 ∧
      (∀ ic : DiscreteInvariantCertQ0, checkDiscreteInvariantCert S.dyn obs ic = false) := by
    unfold auditStageDDynamicsGate at hdrift
    cases hval : validateStageDSpec S with
    | some _ => rw [hval] at hdrift; contradiction
    | none =>
        rw [hval] at hdrift; dsimp only at hdrift
        cases bundle with
        | emptySafeDomain ec =>
            cases he : checkEmptyOverlapCert S.dyn.ctx ec <;> simp [he] at hdrift
        | forwardSafeAndInvariant ρ₀ sc oi ol oc =>
            cases hf : checkForwardSafeBundle S ρ₀ sc oi ol oc <;> simp [hf] at hdrift
        | discreteDriftWitness ρ₀ =>
            cases ho : S.optObs with
            | none => simp [ho] at hdrift
            | some obs =>
                rw [ho] at hdrift; dsimp only at hdrift
                cases hd : checkStepDriftWitness S.dyn obs ρ₀ with
                | false => simp [hd] at hdrift
                | true =>
                    rcases thm_drift_witness_blocks_invariant S.dyn obs ρ₀ hd with
                      ⟨hdom, ⟨d, hde, hdnz⟩, hblk⟩
                    exact ⟨obs, ρ₀, d, rfl, hdom, hde, hdnz, hblk⟩
        | barrierEscapeWitness ρ₀ tEsc =>
            cases hb : checkBarrierEscapeBundle S ρ₀ tEsc <;> simp [hb] at hdrift
        | sheafTearWitness sh cc A0 x0 =>
            cases ht : checkSheafDynamicsTear sh cc A0 x0 <;> simp [ht] at hdrift
        | markovNoGoWitness _ _ Xp Yn uD lf =>
            cases hm : (checkLinearMarkovNoGo Xp Yn uD && checkHiddenFiberRealization Xp Yn lf) <;>
              simp [hm] at hdrift
  refine ⟨core, fun b_any => ⟨?_, ?_⟩⟩
  · intro hsafe
    rcases core with ⟨obs, _, _, hobs, _, _, _, hblk⟩
    rcases (thm_stageD_forward_safe_sound S b_any hsafe).2.2.2 obs hobs with ⟨ic, hic⟩
    rw [hblk ic] at hic
    contradiction
  · intro hemp
    rcases core with ⟨_, ρ₀, _, _, hdom, _, _, _⟩
    exact (thm_stageD_empty_domain_sound_and_exclusive S b_any hemp).1 ρ₀ hdom

/-- Master Soundness & Exclusion Theorem for `.verifiedBarrierSafetyViolation`:
    Proves `¬ ForwardInvariant S.dyn` via a reachable finite-step pole or guard escape from
    `ρ₀ ∈ Real_ℚ(S.dyn.ctx)`, universally excluding `.verifiedForwardSafeAndInvariant`
    and `.verifiedEmptySafeDomain`! -/
theorem thm_stageD_barrier_violation_sound_and_exclusive
    (S : StageDSpecQ0) (bundle : StageDCertBundleQ0)
    (hviol : auditStageDDynamicsGate S bundle = .verifiedBarrierSafetyViolation) :
    (∃ ρ₀ : List Rat, ValidDomainQ0 ρ₀ S.dyn.ctx) ∧
    ¬ ForwardInvariant S.dyn ∧
    (∀ b_any : StageDCertBundleQ0,
      auditStageDDynamicsGate S b_any ≠ .verifiedForwardSafeAndInvariant ∧
      auditStageDDynamicsGate S b_any ≠ .verifiedEmptySafeDomain) := by
  have core : (∃ ρ₀ : List Rat, ValidDomainQ0 ρ₀ S.dyn.ctx) ∧ ¬ ForwardInvariant S.dyn := by
    unfold auditStageDDynamicsGate at hviol
    cases hval : validateStageDSpec S with
    | some _ => rw [hval] at hviol; contradiction
    | none =>
        rw [hval] at hviol; dsimp only at hviol
        cases bundle with
        | emptySafeDomain ec =>
            cases he : checkEmptyOverlapCert S.dyn.ctx ec <;> simp [he] at hviol
        | forwardSafeAndInvariant ρ₀ sc oi ol oc =>
            cases hf : checkForwardSafeBundle S ρ₀ sc oi ol oc <;> simp [hf] at hviol
        | discreteDriftWitness ρ₀ =>
            cases ho : S.optObs with
            | none => simp [ho] at hviol
            | some obs =>
                rw [ho] at hviol; dsimp only at hviol
                cases hd : checkStepDriftWitness S.dyn obs ρ₀ <;> simp [hd] at hviol
        | sheafTearWitness sh cc A0 x0 =>
            cases ht : checkSheafDynamicsTear sh cc A0 x0 <;> simp [ht] at hviol
        | markovNoGoWitness _ _ Xp Yn uD lf =>
            cases hm : (checkLinearMarkovNoGo Xp Yn uD && checkHiddenFiberRealization Xp Yn lf) <;>
              simp [hm] at hviol
        | barrierEscapeWitness ρ₀ tEsc =>
            cases hb : checkBarrierEscapeBundle S ρ₀ tEsc with
            | false => simp [hb] at hviol
            | true =>
                unfold checkBarrierEscapeBundle at hb
                simp only [Bool.and_eq_true] at hb
                rcases hb with ⟨⟨_, hdom_b⟩, hesc⟩
                have h₀ : ValidDomainQ0 ρ₀ S.dyn.ctx := (lem_checkValidDomain_iff ρ₀ S.dyn.ctx).mp hdom_b
                refine ⟨⟨ρ₀, h₀⟩, ?_⟩
                intro hfwd
                rcases thm_forward_invariant_all_steps S.dyn hfwd ρ₀ h₀ tEsc with ⟨ρt, hit, hvt⟩
                rw [hit] at hesc
                dsimp only at hesc
                have hv_true : checkValidDomainQ0 ρt S.dyn.ctx = true :=
                  (lem_checkValidDomain_iff ρt S.dyn.ctx).mpr hvt
                rw [hv_true] at hesc
                contradiction
  refine ⟨core.1, core.2, fun b_any => ⟨?_, ?_⟩⟩
  · intro hsafe
    exact core.2 (thm_stageD_forward_safe_sound S b_any hsafe).2.1.2
  · intro hemp
    rcases core.1 with ⟨ρ₀, h₀⟩
    exact (thm_stageD_empty_domain_sound_and_exclusive S b_any hemp).1 ρ₀ h₀

end GrandZero.StageD
