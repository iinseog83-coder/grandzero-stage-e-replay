/-
  GRANDZERO Ω — Stage E (Identifiability, Bounded-Error Set-Membership,
                         Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-4: Q0ConditionalEmpiricalQualificationGate.lean
  Scope:
    1. Detached External Provenance Cut (`Tribunal F-E05`: `Origin Claim ≠ Verified External Provenance`)
       separating untrusted `EmpiricalDatasetAnchorQ0` from evaluator-TCB `ExternalEmpiricalTrustCtxQ0`,
       with exact metadata + value-level (`obsVars`, `yObs`, `eps`) attestation matching.
    2. Three Core Authority Firewall Theorems:
         - `thm_unattested_origin_cannot_mint_empirical_auth` (`F-E05`)
         - `thm_synthetic_origin_always_zero_empirical`
         - `thm_stageE_institutional_firewall_zero` (`a_I = 0` invariant across ALL Stage E paths).
    3. Deterministic 9-Way `auditStageEEmpiricalGate` & Master Soundness / Mutual-Exclusion Theorems.
-/

import StageE.Q0SurgicalSEMAndConfoundingGate

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Part 1: Detached External Provenance Cut & Authority Firewall (`Tribunal F-E05`) -/

inductive DataOriginTagQ0 where
  | externalCalibratedMeasurement
  | syntheticSimulation
  | unverifiedOrigin
  deriving DecidableEq, Repr, Inhabited

/-- Untrusted proposer's empirical dataset anchor (`Origin Claim`). -/
structure EmpiricalDatasetAnchorQ0 (m : Nat) where
  claimedOrigin     : DataOriginTagQ0
  datasetId         : String
  payloadSha256Hex  : String
  calibrationCertId : String
  attesterId        : String
  obsVars           : VarCtxQ0
  yObs              : VecQ0 m
  eps               : VecQ0 m

/-- Independently attested dataset record inside the evaluator TCB (`Verified External Provenance`). -/
structure AttestedDatasetRecordQ0 where
  datasetId         : String
  payloadSha256Hex  : String
  calibrationCertId : String
  attesterId        : String
  obsVars           : VarCtxQ0
  yObsList          : List Rat
  epsList           : List Rat
  deriving DecidableEq, Repr, Inhabited

/-- Evaluator TCB's external provenance & formal-baseline trust context (`Tribunal F-E05`). -/
structure ExternalEmpiricalTrustCtxQ0 where
  sysModelAuth    : AuthorityVecQ0
  attestedRecords : List AttestedDatasetRecordQ0
  deriving DecidableEq, Repr, Inhabited

def isLowerHexChar (c : Char) : Bool :=
  ('0' ≤ c && c ≤ '9') || ('a' ≤ c && c ≤ 'f')

def isLowerSha256Hex (s : String) : Bool :=
  (s.length == 64) && s.toList.all isLowerHexChar

def recordMatchesAnchor {m : Nat} (anc : EmpiricalDatasetAnchorQ0 m)
    (rec : AttestedDatasetRecordQ0) : Bool :=
  (anc.datasetId == rec.datasetId) &&
  (anc.payloadSha256Hex == rec.payloadSha256Hex) &&
  (anc.calibrationCertId == rec.calibrationCertId) &&
  (anc.attesterId == rec.attesterId) &&
  (anc.obsVars == rec.obsVars) &&
  (vecToList anc.yObs == rec.yObsList) &&
  (vecToList anc.eps == rec.epsList)

/-- Computable TCB provenance attestation check (`Tribunal F-E05`):
    Verifies both structured external provenance fields AND exact value-level binding
    of `obsVars`, `yObs`, and `eps` against `tcb.attestedRecords`. -/
def verifyExternalProvenance {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m) : Bool :=
  (anc.claimedOrigin == .externalCalibratedMeasurement) &&
  (anc.datasetId != "") &&
  (anc.calibrationCertId != "") &&
  (anc.attesterId != "") &&
  isLowerSha256Hex anc.payloadSha256Hex &&
  tcb.attestedRecords.any (recordMatchesAnchor anc)

def effectiveEmpiricalAuth {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m) : Nat :=
  if verifyExternalProvenance tcb anc then 1 else 0

/-- Maximum authority ceiling conditionally achievable by coupling `modelAuth` with `anc`
    under `tcb : ExternalEmpiricalTrustCtxQ0` (`institutional := 0` identically!). -/
def maxConditionallyQualifiedAuth {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (modelAuth : AuthorityVecQ0)
    (anc : EmpiricalDatasetAnchorQ0 m) : AuthorityVecQ0 :=
  { formal        := Nat.min 1 modelAuth.formal
    empirical     := effectiveEmpiricalAuth tcb anc
    institutional := 0 }

/-- Target Theorem `thm_unattested_origin_cannot_mint_empirical_auth` (`Tribunal F-E05`):
    Even if a proposer sets `anc.claimedOrigin = .externalCalibratedMeasurement`,
    whenever `verifyExternalProvenance tcb anc = false`, `effectiveEmpiricalAuth = 0`
    and NO `claimedAuth` with `empirical ≥ 1` can pass `checkAuthorityLe`. -/
theorem thm_unattested_origin_cannot_mint_empirical_auth {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (modelAuth claimedAuth : AuthorityVecQ0)
    (anc : EmpiricalDatasetAnchorQ0 m)
    (hunatt : verifyExternalProvenance tcb anc = false) :
    effectiveEmpiricalAuth tcb anc = 0 ∧
    (maxConditionallyQualifiedAuth tcb modelAuth anc).empirical = 0 ∧
    (1 ≤ claimedAuth.empirical →
      checkAuthorityLe claimedAuth (maxConditionallyQualifiedAuth tcb modelAuth anc) = false) := by
  have heff : effectiveEmpiricalAuth tcb anc = 0 := by
    unfold effectiveEmpiricalAuth
    simp [hunatt]
  refine ⟨heff, heff, ?_⟩
  intro hemp1
  cases hle : checkAuthorityLe claimedAuth (maxConditionallyQualifiedAuth tcb modelAuth anc) with
  | false => rfl
  | true =>
      have hprop := (lem_checkAuthorityLe_iff _ _).mp hle
      have h2 := hprop.2.1
      dsimp [maxConditionallyQualifiedAuth] at h2
      rw [heff] at h2
      omega

/-- Target Theorem `thm_synthetic_origin_always_zero_empirical`:
    Any dataset whose `claimedOrigin ≠ .externalCalibratedMeasurement` (such as
    `syntheticSimulation`) ALWAYS receives `effectiveEmpiricalAuth = 0`. -/
theorem thm_synthetic_origin_always_zero_empirical {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m)
    (hsyn : anc.claimedOrigin ≠ .externalCalibratedMeasurement) :
    verifyExternalProvenance tcb anc = false ∧
    effectiveEmpiricalAuth tcb anc = 0 := by
  have hv : verifyExternalProvenance tcb anc = false := by
    unfold verifyExternalProvenance
    have hb : (anc.claimedOrigin == .externalCalibratedMeasurement) = false :=
      beq_false_of_ne hsyn
    simp [hb]
  exact ⟨hv, by unfold effectiveEmpiricalAuth; simp [hv]⟩

/-- Target Theorem `thm_stageE_institutional_firewall_zero`:
    Across ALL `tcb`, `modelAuth`, and `anc`, `maxConditionallyQualifiedAuth.institutional = 0`,
    so NO combination of formal proofs and empirical datasets can ever grant `institutional ≥ 1`. -/
theorem thm_stageE_institutional_firewall_zero {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (modelAuth claimedAuth : AuthorityVecQ0)
    (anc : EmpiricalDatasetAnchorQ0 m) :
    (maxConditionallyQualifiedAuth tcb modelAuth anc).institutional = 0 ∧
    (checkAuthorityLe claimedAuth (maxConditionallyQualifiedAuth tcb modelAuth anc) = true →
      claimedAuth.institutional = 0) := by
  refine ⟨rfl, ?_⟩
  intro hle
  have hprop := (lem_checkAuthorityLe_iff _ _).mp hle
  have hi := hprop.2.2
  dsimp [maxConditionallyQualifiedAuth] at hi
  omega

/-! ### Part 2: Stage E Specification, Causal Modes (`F-E04`), & Optional Holdout -/

/-- Out-of-sample holdout dataset indexed directly by the shared `thetaCtx` (`rfl` context match). -/
structure HoldoutDatasetSpecQ0 (thetaCtx : ContextQ0) where
  obsVars : VarCtxQ0
  Phi     : MatQ0 obsVars.length thetaCtx.vars.length
  d0      : VecQ0 obsVars.length
  unitPhi : Fin obsVars.length → Fin thetaCtx.vars.length → UnitSpecQ0
  unitD0  : Fin obsVars.length → UnitSpecQ0
  yHold   : VecQ0 obsVars.length
  epsHold : VecQ0 obsVars.length

namespace HoldoutDatasetSpecQ0

abbrev toDesign {thetaCtx : ContextQ0} (H : HoldoutDatasetSpecQ0 thetaCtx) :
    AffineObservationDesignQ0 :=
  { thetaCtx := thetaCtx
    obsVars  := H.obsVars
    Phi      := H.Phi
    d0       := H.d0
    unitPhi  := H.unitPhi
    unitD0   := H.unitD0 }

end HoldoutDatasetSpecQ0

/-- Strictly separated causal evidence modes (`Tribunal F-E04`):
    active `do`-clamping, passive interventional claim, and restricted canonical 3-node IV
    are kept on distinct constructors. -/
inductive CausalClaimModeQ0 where
  | predictiveObservational
  | interventionalActiveDo     (d : Nat) (sem : LinearSEMQ0 d) (sc : SurgicalDoCertQ0 d)
  | interventionalPassiveClaim (d : Nat)
  | canonicalRestrictedIV3     (sem3 : LinearSEMQ0 3) (sc1 : SurgicalDoCertQ0 3)

def checkCausalModeStatic : CausalClaimModeQ0 → Bool
  | .predictiveObservational       => true
  | .interventionalActiveDo _ M sc => checkSurgicalDoCert M sc
  | .interventionalPassiveClaim _  => true
  | .canonicalRestrictedIV3 M3 sc1 => checkCanonicalIV3Assumptions M3 sc1

def isDirectQualifiableMode : CausalClaimModeQ0 → Bool
  | .predictiveObservational      => true
  | .interventionalActiveDo _ _ _ => true
  | .interventionalPassiveClaim _ => false
  | .canonicalRestrictedIV3 _ _   => false

def isCanonicalIV3Mode : CausalClaimModeQ0 → Bool
  | .canonicalRestrictedIV3 _ _ => true
  | _                           => false

structure StageESpecQ0 where
  design      : AffineObservationDesignQ0
  anchor      : EmpiricalDatasetAnchorQ0 design.m
  cQuery      : VecQ0 design.p
  causalMode  : CausalClaimModeQ0
  optHoldout  : Option (HoldoutDatasetSpecQ0 design.thetaCtx)
  modelAuth   : AuthorityVecQ0
  claimedAuth : AuthorityVecQ0

inductive StageEInvalidReasonQ0 where
  | illTypedObservation
  | invalidUncertaintySpec
  | invalidSEMOrIVAssumptions
  | authorityEscalation
  deriving DecidableEq, Repr, Inhabited

inductive StageEGateOutcomeQ0 where
  | verifiedEmptyParameterPrior
  | verifiedConditionallyEmpiricallyQualified
  | verifiedQueryConditionallyQualified
  | verifiedCanonicalIVConditionallyQualified
  | verifiedUnderdeterminedCompatibility
  | verifiedEmpiricalFarkasFalsification
  | verifiedHoldoutExtrapolationFalsified
  | verifiedConfoundingCausalObstruction
  | rejectedInvalidEmpiricalSpec : StageEInvalidReasonQ0 → StageEGateOutcomeQ0
  | rejectedInvalidCertificate
  deriving DecidableEq, Repr, Inhabited

def checkHoldoutUnits {thetaCtx : ContextQ0} : Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => checkAffineObservationUnits H.toDesign

def checkHoldoutEpsPos {thetaCtx : ContextQ0} : Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => vecPosBool H.epsHold

def checkHoldoutPointFeasible {thetaCtx : ContextQ0} (θ : VecQ0 thetaCtx.vars.length) :
    Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => checkFeasibleParameter H.toDesign H.yHold H.epsHold θ

/-- Deterministic 4-step static validator (`validateStageESpec`):
    `1. Units/Offset Typing` → `2. Positive ε > 0` → `3. SEM/IV Hypotheses` →
    `4. Detached TCB Provenance & Authority Firewall`. -/
def validateStageESpec (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0) :
    Option StageEInvalidReasonQ0 :=
  if !(checkAffineObservationUnits S.design &&
       (S.design.obsVars == S.anchor.obsVars) &&
       checkHoldoutUnits S.optHoldout) then
    some .illTypedObservation
  else if !(vecPosBool S.anchor.eps && checkHoldoutEpsPos S.optHoldout) then
    some .invalidUncertaintySpec
  else if !checkCausalModeStatic S.causalMode then
    some .invalidSEMOrIVAssumptions
  else if !(checkAuthorityLe S.modelAuth tcb.sysModelAuth &&
            checkAuthorityLe S.claimedAuth
              (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor)) then
    some .authorityEscalation
  else
    none

theorem lem_validateStageESpec_none_authority
    {tcb : ExternalEmpiricalTrustCtxQ0} {S : StageESpecQ0}
    (hv : validateStageESpec tcb S = none) :
    AuthorityLe S.modelAuth tcb.sysModelAuth ∧
    AuthorityLe S.claimedAuth (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) ∧
    S.claimedAuth.institutional = 0 := by
  unfold validateStageESpec at hv
  split at hv
  · contradiction
  · split at hv
    · contradiction
    · split at hv
      · contradiction
      · split at hv
        · contradiction
        · rename_i h1 h2 h3 h4
          have hb : checkAuthorityLe S.modelAuth tcb.sysModelAuth = true ∧
              checkAuthorityLe S.claimedAuth
                (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) = true := by
            cases bm : checkAuthorityLe S.modelAuth tcb.sysModelAuth <;>
            cases bc : checkAuthorityLe S.claimedAuth
                (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) <;>
            simp [bm, bc] at h4 ⊢
          exact ⟨(lem_checkAuthorityLe_iff _ _).mp hb.1,
                 (lem_checkAuthorityLe_iff _ _).mp hb.2,
                 (thm_stageE_institutional_firewall_zero tcb S.modelAuth S.claimedAuth S.anchor).2 hb.2⟩

/-! ### Part 3: Certificate Bundles & Deterministic `auditStageEEmpiricalGate` -/

def checkOptTightCert (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cQuery : VecQ0 D.p) : Option (TightQueryIntervalCertQ0 D) → Bool
  | none    => true
  | some tc => checkTightQueryIntervalCert D yObs eps cQuery tc

inductive StageECertBundleQ0 (S : StageESpecQ0) where
  | emptyPrior
      (ec : EmptyOverlapCertQ0)
  | fullPointQualified
      (rc       : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert   : QueryEnclosingCertQ0 S.design)
      (optTight : Option (TightQueryIntervalCertQ0 S.design))
  | queryOnlyQualified
      (rc       : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert   : QueryEnclosingCertQ0 S.design)
      (optTight : Option (TightQueryIntervalCertQ0 S.design))
  | canonicalIV3Qualified
      (rc     : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert : QueryEnclosingCertQ0 S.design)
  | underdeterminedTwin
      (tw : TwinUnidentifiableWitnessQ0 S.design.p)
  | empiricalFarkas
      (fc : EmpiricalFalsificationCertQ0 S.design)
  | holdoutDisjoint
      (hcGen : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
                 S.optHoldout = some H → HoldoutDisjointCertQ0 S.design H.toDesign)
  | confoundingTwin
      {d : Nat} (tc : ConfoundingTwinCertQ0 d)

def checkFullPointBundle (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  isDirectQualifiableMode S.causalMode &&
  checkRankNullityCert S.design.Phi rc &&
  decide (rc.k = 0) &&
  checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
  checkOptTightCert S.design S.anchor.yObs S.anchor.eps S.cQuery optTight &&
  checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout

def checkQueryOnlyBundle (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  isDirectQualifiableMode S.causalMode &&
  decide (0 < rc.k) &&
  checkQueryOrthogonalKernel S.design rc S.cQuery &&
  checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
  checkOptTightCert S.design S.anchor.yObs S.anchor.eps S.cQuery optTight &&
  checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout

def checkCanonicalIV3Bundle (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design) : Bool :=
  isCanonicalIV3Mode S.causalMode &&
  checkRankNullityCert S.design.Phi rc &&
  decide (rc.k = 0) &&
  checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
  checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout

def checkUnderdeterminedBundle (S : StageESpecQ0)
    (tw : TwinUnidentifiableWitnessQ0 S.design.p) : Bool :=
  checkTwinDomainIndistinguishable S.design S.cQuery tw &&
  checkFeasibleParameter S.design S.anchor.yObs S.anchor.eps tw.theta1 &&
  checkFeasibleParameter S.design S.anchor.yObs S.anchor.eps tw.theta2

def checkHoldoutDisjointBundle (S : StageESpecQ0)
    (hcGen : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
               S.optHoldout = some H → HoldoutDisjointCertQ0 S.design H.toDesign) : Bool :=
  match hOpt : S.optHoldout with
  | none => false
  | some H =>
      checkHoldoutDisjointCert S.design H.toDesign rfl
        S.anchor.yObs S.anchor.eps H.yHold H.epsHold (hcGen H hOpt)

theorem lem_checkHoldoutDisjointBundle_sound (S : StageESpecQ0)
    (hcGen : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
               S.optHoldout = some H → HoldoutDisjointCertQ0 S.design H.toDesign)
    (hc : checkHoldoutDisjointBundle S hcGen = true) :
    ∃ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
      S.optHoldout = some H ∧
      (∃ θ_cal : VecQ0 S.design.p,
        InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ_cal) ∧
      ∀ θ : VecQ0 S.design.p,
        ¬ (InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ ∧
           InFeasibleParameterSet H.toDesign H.yHold H.epsHold θ) := by
  cases S with
  | mk design anc cq cm optH ma ca =>
    cases optH with
    | none =>
        unfold checkHoldoutDisjointBundle at hc
        contradiction
    | some H =>
        unfold checkHoldoutDisjointBundle at hc
        dsimp only at hc
        rcases thm_holdout_disjoint_falsification
          design H.toDesign rfl anc.yObs anc.eps H.yHold H.epsHold (hcGen H rfl) hc with
          ⟨hcal, hdisj⟩
        exact ⟨H, rfl, ⟨_, hcal⟩, hdisj⟩

def checkConfoundingBundle (S : StageESpecQ0) {d : Nat} (tc : ConfoundingTwinCertQ0 d) : Bool :=
  match S.causalMode with
  | .interventionalPassiveClaim dSpec => decide (d = dSpec) && checkConfoundingTwinCert tc
  | _ => false

/-- Trusted Deterministic Stage E Conditional Empirical Qualification Gate. -/
def auditStageEEmpiricalGate
    (tcb : ExternalEmpiricalTrustCtxQ0)
    (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S) : StageEGateOutcomeQ0 :=
  match validateStageESpec tcb S with
  | some reason => .rejectedInvalidEmpiricalSpec reason
  | none =>
      match bundle with
      | .emptyPrior ec =>
          if checkEmptyOverlapCert S.design.thetaCtx ec then .verifiedEmptyParameterPrior
          else .rejectedInvalidCertificate
      | .fullPointQualified rc lpCert optTight =>
          if checkFullPointBundle S rc lpCert optTight then .verifiedConditionallyEmpiricallyQualified
          else .rejectedInvalidCertificate
      | .queryOnlyQualified rc lpCert optTight =>
          if checkQueryOnlyBundle S rc lpCert optTight then .verifiedQueryConditionallyQualified
          else .rejectedInvalidCertificate
      | .canonicalIV3Qualified rc lpCert =>
          if checkCanonicalIV3Bundle S rc lpCert then .verifiedCanonicalIVConditionallyQualified
          else .rejectedInvalidCertificate
      | .underdeterminedTwin tw =>
          if checkUnderdeterminedBundle S tw then .verifiedUnderdeterminedCompatibility
          else .rejectedInvalidCertificate
      | .empiricalFarkas fc =>
          if checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc then
            .verifiedEmpiricalFarkasFalsification
          else .rejectedInvalidCertificate
      | .holdoutDisjoint hcGen =>
          if checkHoldoutDisjointBundle S hcGen then .verifiedHoldoutExtrapolationFalsified
          else .rejectedInvalidCertificate
      | .confoundingTwin tc =>
          if checkConfoundingBundle S tc then .verifiedConfoundingCausalObstruction
          else .rejectedInvalidCertificate

/-! ### Part 4: Master Soundness & Pairwise Mutual-Exclusion Theorems -/

/-- Target Theorem `thm_stageE_invalid_spec_universal_reject`:
    Any statically invalid `StageESpecQ0` (unit mismatch, `ε ≤ 0`, invalid SEM/IV, or
    authority/provenance escalation) is rejected across ALL possible certificate bundles. -/
theorem thm_stageE_invalid_spec_universal_reject
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (reason : StageEInvalidReasonQ0)
    (hinv : validateStageESpec tcb S = some reason) :
    ∀ bundle : StageECertBundleQ0 S,
      auditStageEEmpiricalGate tcb S bundle = .rejectedInvalidEmpiricalSpec reason := by
  intro bundle
  unfold auditStageEEmpiricalGate
  rw [hinv]

/-- Helper extracting a feasible parameter `θ_hat ∈ Θ_feas` from any of the three
    conditionally qualified outcomes. -/
theorem lem_qualified_outcomes_have_feasible_witness
    {tcb : ExternalEmpiricalTrustCtxQ0} {S : StageESpecQ0} {b : StageECertBundleQ0 S}
    (hout : auditStageEEmpiricalGate tcb S b = .verifiedConditionallyEmpiricallyQualified ∨
            auditStageEEmpiricalGate tcb S b = .verifiedQueryConditionallyQualified ∨
            auditStageEEmpiricalGate tcb S b = .verifiedCanonicalIVConditionallyQualified) :
    ∃ θ : VecQ0 S.design.p,
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ ∧
      checkHoldoutPointFeasible θ S.optHoldout = true := by
  unfold auditStageEEmpiricalGate at hout
  cases hv : validateStageESpec tcb S with
  | some r => rw [hv] at hout; simp at hout
  | none =>
      rw [hv] at hout
      dsimp only at hout
      cases b with
      | emptyPrior ec =>
          by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at hout
      | fullPointQualified rc lp optT =>
          by_cases hc : checkFullPointBundle S rc lp optT = true
          · unfold checkFullPointBundle at hc
            simp only [Bool.and_eq_true] at hc
            have hfeas := (thm_query_enclosing_interval_sound
              S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2).1
            exact ⟨lp.thetaHat, hfeas, hc.2⟩
          · simp [hc] at hout
      | queryOnlyQualified rc lp optT =>
          by_cases hc : checkQueryOnlyBundle S rc lp optT = true
          · unfold checkQueryOnlyBundle at hc
            simp only [Bool.and_eq_true] at hc
            have hfeas := (thm_query_enclosing_interval_sound
              S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2).1
            exact ⟨lp.thetaHat, hfeas, hc.2⟩
          · simp [hc] at hout
      | canonicalIV3Qualified rc lp =>
          by_cases hc : checkCanonicalIV3Bundle S rc lp = true
          · unfold checkCanonicalIV3Bundle at hc
            simp only [Bool.and_eq_true] at hc
            have hfeas := (thm_query_enclosing_interval_sound
              S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.2).1
            exact ⟨lp.thetaHat, hfeas, hc.2⟩
          · simp [hc] at hout
      | underdeterminedTwin tw =>
          by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at hout
      | empiricalFarkas fc =>
          by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
            simp [hc] at hout
      | holdoutDisjoint hcGen =>
          by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at hout
      | confoundingTwin tc =>
          by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at hout

/-- Target Theorem `thm_stageE_conditionally_qualified_sound` (`Tribunal F-E01 ~ F-E05`):
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedConditionallyEmpiricallyQualified`:
      1. `S.claimedAuth` obeys `maxConditionallyQualifiedAuth` (`institutional = 0`, and
         `1 ≤ claimedAuth.empirical → verifyExternalProvenance tcb S.anchor = true`),
      2. The affine design `Φ θ + d₀` is globally point-identifiable (`∀ θ₁ θ₂, predict θ₁ = predict θ₂ → θ₁ = θ₂`),
      3. `Θ_feas` is non-empty with certified enclosing interval `[qLb, qUb]` on `⟨cQuery, θ⟩`. -/
theorem thm_stageE_conditionally_qualified_sound
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedConditionallyEmpiricallyQualified) :
    AuthorityLe S.modelAuth tcb.sysModelAuth ∧
    AuthorityLe S.claimedAuth (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) ∧
    S.claimedAuth.institutional = 0 ∧
    (1 ≤ S.claimedAuth.empirical → verifyExternalProvenance tcb S.anchor = true) ∧
    (∀ θ1 θ2 : VecQ0 S.design.p, S.design.predict θ1 = S.design.predict θ2 → θ1 = θ2) ∧
    (∃ lpCert : QueryEnclosingCertQ0 S.design,
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps lpCert.thetaHat ∧
      ∀ θ : VecQ0 S.design.p, InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ →
        lpCert.qLb S.anchor.yObs S.anchor.eps ≤ dotVec S.cQuery θ ∧
        dotVec S.cQuery θ ≤ lpCert.qUb S.anchor.yObs S.anchor.eps) := by
  unfold auditStageEEmpiricalGate at haud
  cases hv : validateStageESpec tcb S with
  | some r => rw [hv] at haud; contradiction
  | none =>
      rw [hv] at haud
      dsimp only at haud
      rcases lem_validateStageESpec_none_authority hv with ⟨hm_le, hc_le, hinst0⟩
      have hprov : 1 ≤ S.claimedAuth.empirical → verifyExternalProvenance tcb S.anchor = true := by
        intro hemp1
        cases hp : verifyExternalProvenance tcb S.anchor with
        | true => rfl
        | false =>
            have hfalse := (thm_unattested_origin_cannot_mint_empirical_auth
              tcb S.modelAuth S.claimedAuth S.anchor hp).2.2 hemp1
            have htrue := (lem_checkAuthorityLe_iff _ _).mpr hc_le
            rw [hfalse] at htrue
            contradiction
      cases bundle with
      | emptyPrior ec =>
          by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
      | fullPointQualified rc lp optT =>
          by_cases hc : checkFullPointBundle S rc lp optT = true
          · unfold checkFullPointBundle at hc
            simp only [Bool.and_eq_true, decide_eq_true_eq] at hc
            have hid := (thm_affine_global_point_identifiable S.design rc hc.1.1.1.1.2 hc.1.1.1.2).2
            have henc := thm_query_enclosing_interval_sound
              S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2
            exact ⟨hm_le, hc_le, hinst0, hprov, hid, ⟨lp, henc.1, henc.2.1⟩⟩
          · simp [hc] at haud
      | queryOnlyQualified rc lp optT =>
          by_cases hc : checkQueryOnlyBundle S rc lp optT = true <;> simp [hc] at haud
      | canonicalIV3Qualified rc lp =>
          by_cases hc : checkCanonicalIV3Bundle S rc lp = true <;> simp [hc] at haud
      | underdeterminedTwin tw =>
          by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
      | empiricalFarkas fc =>
          by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
            simp [hc] at haud
      | holdoutDisjoint hcGen =>
          by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
      | confoundingTwin tc =>
          by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud

/-- Target Theorem `thm_stageE_farkas_falsified_sound_and_exclusive`:
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedEmpiricalFarkasFalsification`:
      1. `Θ_feas = ∅`, AND
      2. NO certificate bundle `b_any` can produce any of the four feasible/qualified outcomes! -/
theorem thm_stageE_farkas_falsified_sound_and_exclusive
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedEmpiricalFarkasFalsification) :
    (∀ θ : VecQ0 S.design.p, ¬ InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ) ∧
    (∀ b_any : StageECertBundleQ0 S,
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedCanonicalIVConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedUnderdeterminedCompatibility) := by
  have hunsat : ∀ θ : VecQ0 S.design.p,
      ¬ InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ := by
    unfold auditStageEEmpiricalGate at haud
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at haud; contradiction
    | none =>
        rw [hv] at haud
        dsimp only at haud
        cases bundle with
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
        | fullPointQualified rc lp optT =>
            by_cases hc : checkFullPointBundle S rc lp optT = true <;> simp [hc] at haud
        | queryOnlyQualified rc lp optT =>
            by_cases hc : checkQueryOnlyBundle S rc lp optT = true <;> simp [hc] at haud
        | canonicalIV3Qualified rc lp =>
            by_cases hc : checkCanonicalIV3Bundle S rc lp = true <;> simp [hc] at haud
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true
            · exact thm_empirical_farkas_falsification S.design S.anchor.yObs S.anchor.eps fc hc
            · simp [hc] at haud
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud
  refine ⟨hunsat, fun b_any => ⟨?_, ?_, ?_, ?_⟩⟩
  · intro hq
    rcases lem_qualified_outcomes_have_feasible_witness (Or.inl hq) with ⟨θ, hfeas, _⟩
    exact hunsat θ hfeas
  · intro hq
    rcases lem_qualified_outcomes_have_feasible_witness (Or.inr (Or.inl hq)) with ⟨θ, hfeas, _⟩
    exact hunsat θ hfeas
  · intro hq
    rcases lem_qualified_outcomes_have_feasible_witness (Or.inr (Or.inr hq)) with ⟨θ, hfeas, _⟩
    exact hunsat θ hfeas
  · intro hu
    unfold auditStageEEmpiricalGate at hu
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at hu; contradiction
    | none =>
        rw [hv] at hu
        dsimp only at hu
        cases b_any with
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true
            · unfold checkUnderdeterminedBundle at hc
              simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff] at hc
              exact hunsat tw.theta1 hc.1.2
            · simp [hc] at hu
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at hu
        | fullPointQualified rc lp optT =>
            by_cases hc : checkFullPointBundle S rc lp optT = true <;> simp [hc] at hu
        | queryOnlyQualified rc lp optT =>
            by_cases hc : checkQueryOnlyBundle S rc lp optT = true <;> simp [hc] at hu
        | canonicalIV3Qualified rc lp =>
            by_cases hc : checkCanonicalIV3Bundle S rc lp = true <;> simp [hc] at hu
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at hu
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at hu
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at hu

/-- Target Theorem `thm_stageE_underdetermined_blocks_qualified`:
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedUnderdeterminedCompatibility`,
    NO certificate bundle `b_any` can claim `.verifiedConditionallyEmpiricallyQualified`,
    `.verifiedQueryConditionallyQualified`, or `.verifiedEmpiricalFarkasFalsification`! -/
theorem thm_stageE_underdetermined_blocks_qualified
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedUnderdeterminedCompatibility) :
    (∃ θ1 θ2 : VecQ0 S.design.p,
      θ1 ≠ θ2 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ1 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ2 ∧
      S.design.predict θ1 = S.design.predict θ2 ∧
      dotVec S.cQuery θ1 ≠ dotVec S.cQuery θ2) ∧
    (∀ b_any : StageECertBundleQ0 S,
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have htw_prop : ∃ θ1 θ2 : VecQ0 S.design.p,
      θ1 ≠ θ2 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ1 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ2 ∧
      S.design.predict θ1 = S.design.predict θ2 ∧
      dotVec S.cQuery θ1 ≠ dotVec S.cQuery θ2 := by
    unfold auditStageEEmpiricalGate at haud
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at haud; contradiction
    | none =>
        rw [hv] at haud
        dsimp only at haud
        cases bundle with
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true
            · unfold checkUnderdeterminedBundle at hc
              simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff] at hc
              rcases thm_twin_witness_blocks_query_identifiability S.design S.cQuery tw hc.1.1 with
                ⟨hne, _, _, hpred, hq_ne, _, _⟩
              exact ⟨tw.theta1, tw.theta2, hne, hc.1.2, hc.2, hpred, hq_ne⟩
            · simp [hc] at haud
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
        | fullPointQualified rc lp optT =>
            by_cases hc : checkFullPointBundle S rc lp optT = true <;> simp [hc] at haud
        | queryOnlyQualified rc lp optT =>
            by_cases hc : checkQueryOnlyBundle S rc lp optT = true <;> simp [hc] at haud
        | canonicalIV3Qualified rc lp =>
            by_cases hc : checkCanonicalIV3Bundle S rc lp = true <;> simp [hc] at haud
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at haud
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud
  rcases htw_prop with ⟨θ1, θ2, hne, hf1, hf2, hpred, hq_ne⟩
  refine ⟨⟨θ1, θ2, hne, hf1, hf2, hpred, hq_ne⟩, fun b_any => ⟨?_, ?_, ?_⟩⟩
  · intro hfull
    have hinj := (thm_stageE_conditionally_qualified_sound tcb S b_any hfull).2.2.2.2.1
    exact hne (hinj θ1 θ2 hpred)
  · intro hq_only
    unfold auditStageEEmpiricalGate at hq_only
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at hq_only; contradiction
    | none =>
        rw [hv] at hq_only
        dsimp only at hq_only
        cases b_any with
        | queryOnlyQualified rc lp optT =>
            by_cases hc : checkQueryOnlyBundle S rc lp optT = true
            · unfold checkQueryOnlyBundle at hc
              simp only [Bool.and_eq_true] at hc
              have hsid := thm_structural_query_identifiable_of_orth_kernel
                S.design rc S.cQuery hc.1.1.1.2
              exact hq_ne (hsid θ1 θ2 hpred)
            · simp [hc] at hq_only
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at hq_only
        | fullPointQualified rc lp optT =>
            by_cases hc : checkFullPointBundle S rc lp optT = true <;> simp [hc] at hq_only
        | canonicalIV3Qualified rc lp =>
            by_cases hc : checkCanonicalIV3Bundle S rc lp = true <;> simp [hc] at hq_only
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at hq_only
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at hq_only
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at hq_only
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at hq_only
  · intro hfark
    exact (thm_stageE_farkas_falsified_sound_and_exclusive tcb S b_any hfark).2 bundle |>.2.2.2 haud

/-- Target Theorem `thm_stageE_holdout_falsified_sound_and_exclusive`:
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedHoldoutExtrapolationFalsified`:
      1. Calibration is feasible (`∃ θ_cal ∈ Θ_feas(cal)`), so `.verifiedEmpiricalFarkasFalsification`
         is impossible for EVERY `b_any`, AND
      2. Calibration and holdout feasible sets are disjoint, so ALL THREE qualified outcomes
         are impossible for EVERY `b_any`! -/
theorem thm_stageE_holdout_falsified_sound_and_exclusive
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedHoldoutExtrapolationFalsified) :
    (∃ θ_cal : VecQ0 S.design.p,
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ_cal) ∧
    (∀ b_any : StageECertBundleQ0 S,
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedCanonicalIVConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have hcore : (∃ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
      S.optHoldout = some H ∧
      (∃ θ_cal : VecQ0 S.design.p,
        InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ_cal) ∧
      ∀ θ : VecQ0 S.design.p,
        ¬ (InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ ∧
           InFeasibleParameterSet H.toDesign H.yHold H.epsHold θ)) := by
    unfold auditStageEEmpiricalGate at haud
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at haud; contradiction
    | none =>
        rw [hv] at haud
        dsimp only at haud
        cases bundle with
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true
            · exact lem_checkHoldoutDisjointBundle_sound S hcGen hc
            · simp [hc] at haud
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
        | fullPointQualified rc lp optT =>
            by_cases hc : checkFullPointBundle S rc lp optT = true <;> simp [hc] at haud
        | queryOnlyQualified rc lp optT =>
            by_cases hc : checkQueryOnlyBundle S rc lp optT = true <;> simp [hc] at haud
        | canonicalIV3Qualified rc lp =>
            by_cases hc : checkCanonicalIV3Bundle S rc lp = true <;> simp [hc] at haud
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at haud
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud
  rcases hcore with ⟨H, hOpt, ⟨θ_cal, hcal_f⟩, hdisj⟩
  have block_qual : ∀ b_any : StageECertBundleQ0 S,
      ¬ (auditStageEEmpiricalGate tcb S b_any = .verifiedConditionallyEmpiricallyQualified ∨
         auditStageEEmpiricalGate tcb S b_any = .verifiedQueryConditionallyQualified ∨
         auditStageEEmpiricalGate tcb S b_any = .verifiedCanonicalIVConditionallyQualified) := by
    intro b_any hor
    rcases lem_qualified_outcomes_have_feasible_witness hor with ⟨θ, hf_cal, hf_hold_b⟩
    rw [hOpt] at hf_hold_b
    dsimp [checkHoldoutPointFeasible] at hf_hold_b
    have hf_hold := (lem_checkFeasibleParameter_iff _ _ _ _).mp hf_hold_b
    exact hdisj θ ⟨hf_cal, hf_hold⟩
  refine ⟨⟨θ_cal, hcal_f⟩, fun b_any => ⟨?_, ?_, ?_, ?_⟩⟩
  · exact fun h => block_qual b_any (Or.inl h)
  · exact fun h => block_qual b_any (Or.inr (Or.inl h))
  · exact fun h => block_qual b_any (Or.inr (Or.inr h))
  · intro hfark
    have hunsat := (thm_stageE_farkas_falsified_sound_and_exclusive tcb S b_any hfark).1
    exact hunsat θ_cal hcal_f

end GrandZero.StageE
