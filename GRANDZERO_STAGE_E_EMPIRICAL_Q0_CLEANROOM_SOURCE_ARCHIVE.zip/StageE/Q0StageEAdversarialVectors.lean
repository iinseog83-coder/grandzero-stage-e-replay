/-
  GRANDZERO Ω — Stage E (Identifiability, Bounded-Error Set-Membership,
                         Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-5: Q0StageEAdversarialVectors.lean
  Scope:
    Mechanized formal proofs (`0 sorry`) for all 14 Stage E adversarial sub-vectors
    (`TE-01 ~ TE-07c`) binding `Tribunal F-E01 ~ F-E05`:
      - `TE-01`  : Full-Rank Affine Hooke Calibration (`d₀ ≠ 0`, `F-E01`) + Tight LP (`F-E02`)
                   + Holdout Pass + TCB Attested Provenance (`F-E05`)
      - `TE-02a` : Collinear Sum Sloppiness Trap (`verifiedUnderdeterminedCompatibility`)
      - `TE-02b` : Gauge-Invariant Sum Query (`Kᵀ c = 0`, `STRUCT_ID = true` + `WIDTH = 2 > 0`, `F-E03`)
      - `TE-03a` : Mutually Contradictory Affine Measurements (`verifiedEmpiricalFarkasFalsification`)
      - `TE-03b` : Physical Positivity Guard vs. Negative Envelope (`verifiedEmpiricalFarkasFalsification`)
      - `TE-04a` : Passive Correlation-as-Causation Confounding Trap (`verifiedConfoundingCausalObstruction`)
      - `TE-04b` : Active Surgical `do(X := u)` Clamp Disambiguation (`F-E04` Path 1)
      - `TE-04c` : Restricted Canonical 3-Node Linear IV (`F-E04` Path 2 + Invalid-IV Reject Theorem)
      - `TE-05`  : In-Sample Calibration Fit vs. Out-of-Sample Holdout Falsification + `Stage D` Escape
      - `TE-06`  : Counterfeit Unattained Tight LP Certificate Rejected (`F-E02`)
      - `TE-07a` : Torque-vs-Energy Sensor `KindTagQ0` Smuggling Rejected
      - `TE-07b1`: Synthetic Self-Simulation Bootstrap Smuggling Rejected
      - `TE-07b2`: Forged External Origin Label & Tampered-`ε` Provenance Smuggling Rejected (`F-E05`)
      - `TE-07c` : Institutional Authority Escalation (`a_I = 1`) Unconditionally Blocked
-/

import StageE.Q0ConditionalEmpiricalQualificationGate

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Shared Physical Units & TCB Provenance Registry (`Tribunal F-E05`) -/

def uStiff   : UnitSpecQ0 := { dim := { M := 1, T := -2 }, kind := .canonical }
def uForce   : UnitSpecQ0 := { dim := { L := 1, M := 1, T := -2 }, kind := .canonical }
def uMass    : UnitSpecQ0 := { dim := { M := 1 }, kind := .canonical }
def uInvMass : UnitSpecQ0 := { dim := { M := -1 }, kind := .canonical }

def shaTe01  : String := "a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90"
def shaTe02  : String := "b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1"
def shaTe04b : String := "c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2"
def shaTe04c : String := "d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3"

def stageE_tcb : ExternalEmpiricalTrustCtxQ0 :=
  { sysModelAuth := AuthorityVecQ0.formalOnly
    attestedRecords :=
      [ { datasetId         := "GZ-CAL-HOOKE-2026-01"
          payloadSha256Hex  := shaTe01
          calibrationCertId := "NIST-FORCE-CAL-01"
          attesterId        := "EXT-METROLOGY-LAB-A"
          obsVars           := [uForce, uForce]
          yObsList          := [18, 28]
          epsList           := [1, 1] },
        { datasetId         := "GZ-CAL-SUM-2026-02"
          payloadSha256Hex  := shaTe02
          calibrationCertId := "NIST-COND-CAL-02"
          attesterId        := "EXT-METROLOGY-LAB-A"
          obsVars           := [UnitSpecQ0.unitless]
          yObsList          := [12]
          epsList           := [1] },
        { datasetId         := "GZ-DO-CLAMP-2026-04B"
          payloadSha256Hex  := shaTe04b
          calibrationCertId := "LAB-SURGICAL-CLAMP-04"
          attesterId        := "EXT-INTERVENTION-LAB-B"
          obsVars           := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
          yObsList          := [1, 2]
          epsList           := [1 / 4, 1 / 4] },
        { datasetId         := "GZ-IV3-COVMOM-2026-04C"
          payloadSha256Hex  := shaTe04c
          calibrationCertId := "LAB-IV3-MOMENT-04C"
          attesterId        := "EXT-ECONOMETRICS-AUDIT-C"
          obsVars           := [UnitSpecQ0.unitless]
          yObsList          := [6]
          epsList           := [1 / 2] } ] }

/-! ### Vector `TE-01`: Full-Rank Affine Calibration (`d₀ ≠ 0`, `F-E01`), Tight LP (`F-E02`), & TCB (`F-E05`) -/

def te01_ctx : ContextQ0 :=
  { vars   := [uStiff, uForce]
    hyps   := []
    guards := [.pos (.bvar 0)] }

def te01_design : AffineObservationDesignQ0 :=
  { thetaCtx := te01_ctx
    obsVars  := [uForce, uForce]
    Phi      := matOfLists 2 2 [[1, 1], [2, 1]]
    d0       := vecOfList 2 [3, 3]
    unitPhi  := fun _ j => if j.val == 0 then UnitSpecQ0.meter else UnitSpecQ0.unitless
    unitD0   := fun _ => uForce }

def te01_anchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin     := .externalCalibratedMeasurement
    datasetId         := "GZ-CAL-HOOKE-2026-01"
    payloadSha256Hex  := shaTe01
    calibrationCertId := "NIST-FORCE-CAL-01"
    attesterId        := "EXT-METROLOGY-LAB-A"
    obsVars           := [uForce, uForce]
    yObs              := vecOfList 2 [18, 28]
    eps               := vecOfList 2 [1, 1] }

def te01_holdout : HoldoutDatasetSpecQ0 te01_ctx :=
  { obsVars := [uForce]
    Phi     := matOfLists 1 2 [[3, 1]]
    d0      := vecOfList 1 [3]
    unitPhi := fun _ j => if j.val == 0 then UnitSpecQ0.meter else UnitSpecQ0.unitless
    unitD0  := fun _ => uForce
    yHold   := vecOfList 1 [38]
    epsHold := vecOfList 1 [1] }

def te01_rc : RankNullityCertQ0 2 2 :=
  { r := 2
    k := 0
    U := idMat 2
    B := matOfLists 2 2 [[1, 1], [2, 1]]
    L := matOfLists 2 2 [[-1, 1], [2, -1]]
    K := fun _ j => j.elim0
    R := fun i _ => i.elim0 }

def te01_lpEnclosing : QueryEnclosingCertQ0 te01_design :=
  { thetaHat := vecOfList 2 [10, 5]
    domRows  := emptyDomainAffineBundle 2
    wLb      := vecOfList 4 [1, 0, 0, 1]
    wUb      := vecOfList 4 [0, 1, 1, 0] }

def te01_lpTight : TightQueryIntervalCertQ0 te01_design :=
  { enclosing := te01_lpEnclosing
    thetaMin  := vecOfList 2 [8, 8]
    thetaMax  := vecOfList 2 [12, 2] }

def te01_spec : StageESpecQ0 :=
  { design      := te01_design
    anchor      := te01_anchor
    cQuery      := vecOfList 2 [1, 0]
    causalMode  := .predictiveObservational
    optHoldout  := some te01_holdout
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te01_bundle : StageECertBundleQ0 te01_spec :=
  .fullPointQualified te01_rc te01_lpEnclosing (some te01_lpTight)

theorem te01_affine_full_rank_qualified :
    te01_design.d0 ⟨0, by decide⟩ = 3 ∧
    verifyExternalProvenance stageE_tcb te01_anchor = true ∧
    te01_lpEnclosing.qLb te01_anchor.yObs te01_anchor.eps = 8 ∧
    te01_lpEnclosing.qUb te01_anchor.yObs te01_anchor.eps = 12 ∧
    checkTightQueryIntervalCert te01_design te01_anchor.yObs te01_anchor.eps
      te01_spec.cQuery te01_lpTight = true ∧
    auditStageEEmpiricalGate stageE_tcb te01_spec te01_bundle =
      .verifiedConditionallyEmpiricallyQualified := by
  refine ⟨by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl⟩

/-! ### Vectors `TE-02a` & `TE-02b`: Collinear Sloppiness vs. Gauge-Invariant Query (`F-E02 & F-E03`) -/

def te02_ctx : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    hyps   := []
    guards := [.pos (.bvar 0), .pos (.bvar 1)] }

def te02_design : AffineObservationDesignQ0 :=
  { thetaCtx := te02_ctx
    obsVars  := [UnitSpecQ0.unitless]
    Phi      := matOfLists 1 2 [[1, 1]]
    d0       := vecOfList 1 [2]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te02_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin     := .externalCalibratedMeasurement
    datasetId         := "GZ-CAL-SUM-2026-02"
    payloadSha256Hex  := shaTe02
    calibrationCertId := "NIST-COND-CAL-02"
    attesterId        := "EXT-METROLOGY-LAB-A"
    obsVars           := [UnitSpecQ0.unitless]
    yObs              := vecOfList 1 [12]
    eps               := vecOfList 1 [1] }

def te02_rc : RankNullityCertQ0 1 2 :=
  { r := 1
    k := 1
    U := matOfLists 2 1 [[1], [0]]
    B := matOfLists 1 1 [[1]]
    L := matOfLists 1 1 [[1]]
    K := matOfLists 2 1 [[-1], [1]]
    R := matOfLists 1 2 [[0, 1]] }

def te02a_spec : StageESpecQ0 :=
  { design      := te02_design
    anchor      := te02_anchor
    cQuery      := vecOfList 2 [1, 0]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te02a_twin : TwinUnidentifiableWitnessQ0 2 :=
  { theta1 := vecOfList 2 [4, 6]
    theta2 := vecOfList 2 [7, 3] }

def te02a_bundle : StageECertBundleQ0 te02a_spec :=
  .underdeterminedTwin te02a_twin

theorem te02a_collinear_parameter_underdetermined :
    auditStageEEmpiricalGate stageE_tcb te02a_spec te02a_bundle =
      .verifiedUnderdeterminedCompatibility ∧
    (∀ b_any : StageECertBundleQ0 te02a_spec,
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have haud : auditStageEEmpiricalGate stageE_tcb te02a_spec te02a_bundle =
      .verifiedUnderdeterminedCompatibility := by
    with_unfolding_all rfl
  exact ⟨haud, (thm_stageE_underdetermined_blocks_qualified stageE_tcb te02a_spec te02a_bundle haud).2⟩

def te02b_cQuery : VecQ0 2 := vecOfList 2 [1, 1]

def te02b_lpEnclosing : QueryEnclosingCertQ0 te02_design :=
  { thetaHat := vecOfList 2 [5, 5]
    domRows  := emptyDomainAffineBundle 2
    wLb      := vecOfList 2 [0, 1]
    wUb      := vecOfList 2 [1, 0] }

def te02b_lpTight : TightQueryIntervalCertQ0 te02_design :=
  { enclosing := te02b_lpEnclosing
    thetaMin  := vecOfList 2 [4, 5]
    thetaMax  := vecOfList 2 [5, 6] }

def te02b_spec : StageESpecQ0 :=
  { design      := te02_design
    anchor      := te02_anchor
    cQuery      := te02b_cQuery
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te02b_bundle : StageECertBundleQ0 te02b_spec :=
  .queryOnlyQualified te02_rc te02b_lpEnclosing (some te02b_lpTight)

theorem te02b_invariant_query_structural_vs_noisy_width :
    StructuralQueryIdentifiable te02_design te02b_cQuery ∧
    te02b_lpEnclosing.qLb te02_anchor.yObs te02_anchor.eps = 9 ∧
    te02b_lpEnclosing.qUb te02_anchor.yObs te02_anchor.eps = 11 ∧
    te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps = 2 ∧
    0 < te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps ∧
    auditStageEEmpiricalGate stageE_tcb te02b_spec te02b_bundle =
      .verifiedQueryConditionallyQualified := by
  have horth : checkQueryOrthogonalKernel te02_design te02_rc te02b_cQuery = true := by
    with_unfolding_all rfl
  have hsid := thm_structural_query_identifiable_of_orth_kernel te02_design te02_rc te02b_cQuery horth
  have hlb : te02b_lpEnclosing.qLb te02_anchor.yObs te02_anchor.eps = 9 := by with_unfolding_all rfl
  have hub : te02b_lpEnclosing.qUb te02_anchor.yObs te02_anchor.eps = 11 := by with_unfolding_all rfl
  have hw  : te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps = 2 := by with_unfolding_all rfl
  have hpos : 0 < te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps := by
    rw [hw]; decide
  exact ⟨hsid, hlb, hub, hw, hpos, by with_unfolding_all rfl⟩

/-! ### Vectors `TE-03a` & `TE-03b`: Direct & Guard-Augmented Farkas Falsification -/

def te03a_ctx : ContextQ0 :=
  { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }

def te03a_design : AffineObservationDesignQ0 :=
  { thetaCtx := te03a_ctx
    obsVars  := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    Phi      := matOfLists 2 1 [[1], [1]]
    d0       := vecOfList 2 [1, 1]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te03a_anchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin     := .unverifiedOrigin
    datasetId         := "TE03A-CONFLICT"
    payloadSha256Hex  := ""
    calibrationCertId := ""
    attesterId        := ""
    obsVars           := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    yObs              := vecOfList 2 [2, 8]
    eps               := vecOfList 2 [1, 1] }

def te03a_spec : StageESpecQ0 :=
  { design      := te03a_design
    anchor      := te03a_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te03a_fc : EmpiricalFalsificationCertQ0 te03a_design :=
  { domRows := emptyDomainAffineBundle 1
    wDual   := vecOfList 4 [1, 0, 0, 1] }

def te03a_bundle : StageECertBundleQ0 te03a_spec :=
  .empiricalFarkas te03a_fc

theorem te03a_contradictory_measurements_falsified :
    auditStageEEmpiricalGate stageE_tcb te03a_spec te03a_bundle =
      .verifiedEmpiricalFarkasFalsification ∧
    (∀ θ : VecQ0 1, ¬ InFeasibleParameterSet te03a_design te03a_anchor.yObs te03a_anchor.eps θ) ∧
    (∀ b_any : StageECertBundleQ0 te03a_spec,
      auditStageEEmpiricalGate stageE_tcb te03a_spec b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te03a_spec b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te03a_spec b_any ≠ .verifiedCanonicalIVConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te03a_spec b_any ≠ .verifiedUnderdeterminedCompatibility) := by
  have haud : auditStageEEmpiricalGate stageE_tcb te03a_spec te03a_bundle =
      .verifiedEmpiricalFarkasFalsification := by
    with_unfolding_all rfl
  rcases thm_stageE_farkas_falsified_sound_and_exclusive stageE_tcb te03a_spec te03a_bundle haud with
    ⟨hunsat, hexcl⟩
  exact ⟨haud, hunsat, hexcl⟩

def te03b_ctx : ContextQ0 :=
  { vars   := [uMass]
    hyps   := []
    guards := [.pos (.bvar 0)] }

def te03b_design : AffineObservationDesignQ0 :=
  { thetaCtx := te03b_ctx
    obsVars  := [uMass]
    Phi      := matOfLists 1 1 [[1]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => uMass }

def te03b_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin     := .unverifiedOrigin
    datasetId         := "TE03B-NEG-MASS"
    payloadSha256Hex  := ""
    calibrationCertId := ""
    attesterId        := ""
    obsVars           := [uMass]
    yObs              := vecOfList 1 [-5]
    eps               := vecOfList 1 [1] }

def te03b_posRowCert : NonnegCertQ0 :=
  { c0        := 0
    posTerms  := [{ weight := 1
                    weightUnit := uInvMass
                    expr := .bvar 0
                    proof := .fromStageA (.gActiveMem 0) }]
    nnegTerms := []
    eqTerms   := []
    eqProof   := .gprAstCert [.gRatLit, .gRatLit] [] }

def te03b_domBundle : DomainAffineBundleQ0 1 :=
  { qDom     := 1
    Gdom     := matOfLists 1 1 [[1]]
    g0       := vecOfList 1 [0]
    rowCerts := fun _ => te03b_posRowCert }

def te03b_spec : StageESpecQ0 :=
  { design      := te03b_design
    anchor      := te03b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te03b_fc : EmpiricalFalsificationCertQ0 te03b_design :=
  { domRows := te03b_domBundle
    wDual   := vecOfList 3 [1, 0, 1] }

def te03b_bundle : StageECertBundleQ0 te03b_spec :=
  .empiricalFarkas te03b_fc

theorem te03b_physical_guard_vs_envelope_falsified :
    VecLe (matVec (boxMat te03b_design) (vecOfList 1 [-5]))
          (boxRhs te03b_design te03b_anchor.yObs te03b_anchor.eps) ∧
    auditStageEEmpiricalGate stageE_tcb te03b_spec te03b_bundle =
      .verifiedEmpiricalFarkasFalsification ∧
    (∀ θ : VecQ0 1, ¬ InFeasibleParameterSet te03b_design te03b_anchor.yObs te03b_anchor.eps θ) := by
  have hbox_alone : VecLe (matVec (boxMat te03b_design) (vecOfList 1 [-5]))
      (boxRhs te03b_design te03b_anchor.yObs te03b_anchor.eps) :=
    (lem_vecLeBool_iff _ _).mp (by with_unfolding_all rfl)
  have haud : auditStageEEmpiricalGate stageE_tcb te03b_spec te03b_bundle =
      .verifiedEmpiricalFarkasFalsification := by
    with_unfolding_all rfl
  exact ⟨hbox_alone, haud,
         (thm_stageE_farkas_falsified_sound_and_exclusive stageE_tcb te03b_spec te03b_bundle haud).1⟩

/-! ### Vectors `TE-04a`, `TE-04b`, `TE-04c`: Confounding vs. Active `do` vs. Canonical IV3 (`F-E04`) -/

def te04_M1 : LinearSEMQ0 2 :=
  { rNoise := 2
    B      := matOfLists 2 2 [[0, 0], [1, 0]]
    tau    := fun i => i.val
    S      := matOfLists 2 2 [[1, 0], [1, 1]]
    Lomega := matOfLists 2 2 [[1, 0], [0, 1]] }

def te04_M2 : LinearSEMQ0 2 :=
  { rNoise := 2
    B      := matOfLists 2 2 [[0, 0], [0, 0]]
    tau    := fun i => i.val
    S      := matOfLists 2 2 [[1, 0], [0, 1]]
    Lomega := matOfLists 2 2 [[1, 0], [1, 1]] }

def te04_sc1 : SurgicalDoCertQ0 2 :=
  { iDo := ⟨0, by decide⟩
    Sdo := matOfLists 2 2 [[1, 0], [1, 1]] }

def te04_sc2 : SurgicalDoCertQ0 2 :=
  { iDo := ⟨0, by decide⟩
    Sdo := matOfLists 2 2 [[1, 0], [0, 1]] }

def te04a_twinCert : ConfoundingTwinCertQ0 2 :=
  { M1      := te04_M1
    M2      := te04_M2
    sc1     := te04_sc1
    sc2     := te04_sc2
    iCause  := ⟨0, by decide⟩
    jTarget := ⟨1, by decide⟩ }

def te04b_ctx : ContextQ0 :=
  { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }

def te04b_design : AffineObservationDesignQ0 :=
  { thetaCtx := te04b_ctx
    obsVars  := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    Phi      := matOfLists 2 1 [[1], [2]]
    d0       := vecOfList 2 [0, 0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te04b_anchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin     := .externalCalibratedMeasurement
    datasetId         := "GZ-DO-CLAMP-2026-04B"
    payloadSha256Hex  := shaTe04b
    calibrationCertId := "LAB-SURGICAL-CLAMP-04"
    attesterId        := "EXT-INTERVENTION-LAB-B"
    obsVars           := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    yObs              := vecOfList 2 [1, 2]
    eps               := vecOfList 2 [1 / 4, 1 / 4] }

def te04a_spec : StageESpecQ0 :=
  { design      := te04b_design
    anchor      := te04b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .interventionalPassiveClaim 2
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te04a_bundle : StageECertBundleQ0 te04a_spec :=
  .confoundingTwin te04a_twinCert

theorem te04a_passive_confounding_obstruction :
    te04_M1.SigmaObs = te04_M2.SigmaObs ∧
    interventionalUnitEffect te04_sc1 ⟨1, by decide⟩ = 1 ∧
    interventionalUnitEffect te04_sc2 ⟨1, by decide⟩ = 0 ∧
    auditStageEEmpiricalGate stageE_tcb te04a_spec te04a_bundle =
      .verifiedConfoundingCausalObstruction := by
  have htw : checkConfoundingTwinCert te04a_twinCert = true := by with_unfolding_all rfl
  have hsig := (thm_confounding_twin_obs_eq_do_neq te04a_twinCert htw).2.2.1
  exact ⟨hsig, by with_unfolding_all rfl, by with_unfolding_all rfl, by with_unfolding_all rfl⟩

def te04b_rc : RankNullityCertQ0 2 1 :=
  { r := 1
    k := 0
    U := matOfLists 1 1 [[1]]
    B := matOfLists 2 1 [[1], [2]]
    L := matOfLists 1 2 [[1, 0]]
    K := fun _ j => j.elim0
    R := fun i _ => i.elim0 }

def te04b_lp : QueryEnclosingCertQ0 te04b_design :=
  { thetaHat := vecOfList 1 [1]
    domRows  := emptyDomainAffineBundle 1
    wLb      := vecOfList 4 [0, 0, 0, 1 / 2]
    wUb      := vecOfList 4 [0, 1 / 2, 0, 0] }

def te04b_spec : StageESpecQ0 :=
  { design      := te04b_design
    anchor      := te04b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .interventionalActiveDo 2 te04_M1 te04_sc1
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te04b_bundle : StageECertBundleQ0 te04b_spec :=
  .fullPointQualified te04b_rc te04b_lp none

theorem te04b_active_surgical_do_qualified :
    auditStageEEmpiricalGate stageE_tcb te04b_spec te04b_bundle =
      .verifiedConditionallyEmpiricallyQualified := by
  with_unfolding_all rfl

/-- Canonical 3-node Linear IV (`(Z, X, Y) = (0, 1, 2)`) with `α = 2`, true `β = 3`,
    exclusion `B[2,0] = 0`, `Ω[0,2] = 0`, yet strong latent confounding `Ω[1,2] = 1 ≠ 0`! -/
def te04c_M3 : LinearSEMQ0 3 :=
  { rNoise := 3
    B      := matOfLists 3 3 [[0, 0, 0], [2, 0, 0], [0, 3, 0]]
    tau    := fun i => i.val
    S      := matOfLists 3 3 [[1, 0, 0], [2, 1, 0], [6, 3, 1]]
    Lomega := matOfLists 3 3 [[1, 0, 0], [0, 1, 1], [0, 0, 1]] }

def te04c_sc1 : SurgicalDoCertQ0 3 :=
  { iDo := ivIdx1
    Sdo := matOfLists 3 3 [[1, 0, 0], [0, 1, 0], [0, 3, 1]] }

def te04c_design : AffineObservationDesignQ0 :=
  { thetaCtx := te04b_ctx
    obsVars  := [UnitSpecQ0.unitless]
    Phi      := matOfLists 1 1 [[2]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te04c_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin     := .externalCalibratedMeasurement
    datasetId         := "GZ-IV3-COVMOM-2026-04C"
    payloadSha256Hex  := shaTe04c
    calibrationCertId := "LAB-IV3-MOMENT-04C"
    attesterId        := "EXT-ECONOMETRICS-AUDIT-C"
    obsVars           := [UnitSpecQ0.unitless]
    yObs              := vecOfList 1 [6]
    eps               := vecOfList 1 [1 / 2] }

def te04c_rc : RankNullityCertQ0 1 1 :=
  { r := 1
    k := 0
    U := matOfLists 1 1 [[1 / 2]]
    B := matOfLists 1 1 [[1]]
    L := matOfLists 1 1 [[1]]
    K := fun _ j => j.elim0
    R := fun i _ => i.elim0 }

def te04c_lp : QueryEnclosingCertQ0 te04c_design :=
  { thetaHat := vecOfList 1 [3]
    domRows  := emptyDomainAffineBundle 1
    wLb      := vecOfList 2 [0, 1 / 2]
    wUb      := vecOfList 2 [1 / 2, 0] }

def te04c_spec : StageESpecQ0 :=
  { design      := te04c_design
    anchor      := te04c_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .canonicalRestrictedIV3 te04c_M3 te04c_sc1
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te04c_bundle : StageECertBundleQ0 te04c_spec :=
  .canonicalIV3Qualified te04c_rc te04c_lp

/-- Violated exclusion `B[2,0] = 1 ≠ 0` must fail `checkCanonicalIV3Assumptions` (`F-E04`). -/
def te04c_badExclusionM3 : LinearSEMQ0 3 :=
  { rNoise := 3
    B      := matOfLists 3 3 [[0, 0, 0], [2, 0, 0], [1, 3, 0]]
    tau    := fun i => i.val
    S      := matOfLists 3 3 [[1, 0, 0], [2, 1, 0], [7, 3, 1]]
    Lomega := matOfLists 3 3 [[1, 0, 0], [0, 1, 1], [0, 0, 1]] }

theorem te04c_canonical_iv3_wald_and_invalid_iv_blocked :
    te04c_M3.Omega ivIdx1 ivIdx2 = 1 ∧
    te04c_M3.SigmaObs ivIdx1 ivIdx2 / te04c_M3.SigmaObs ivIdx1 ivIdx1 = 19 / 6 ∧
    te04c_M3.SigmaObs ivIdx0 ivIdx2 / te04c_M3.SigmaObs ivIdx0 ivIdx1 = 3 ∧
    interventionalUnitEffect te04c_sc1 ivIdx2 = 3 ∧
    checkCanonicalIV3Assumptions te04c_badExclusionM3 te04c_sc1 = false ∧
    auditStageEEmpiricalGate stageE_tcb te04c_spec te04c_bundle =
      .verifiedCanonicalIVConditionallyQualified := by
  refine ⟨by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl⟩

/-! ### Vector `TE-05`: Calibration Fit vs. Out-of-Sample Holdout Falsification + `Stage D` Escape -/

def te05_designCal : AffineObservationDesignQ0 :=
  { thetaCtx := te04b_ctx
    obsVars  := [UnitSpecQ0.unitless]
    Phi      := matOfLists 1 1 [[1]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te05_anchorCal : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin     := .unverifiedOrigin
    datasetId         := "TE05-CAL"
    payloadSha256Hex  := ""
    calibrationCertId := ""
    attesterId        := ""
    obsVars           := [UnitSpecQ0.unitless]
    yObs              := vecOfList 1 [2]
    eps               := vecOfList 1 [1] }

def te05_holdout : HoldoutDatasetSpecQ0 te04b_ctx :=
  { obsVars := [UnitSpecQ0.unitless]
    Phi     := matOfLists 1 1 [[4]]
    d0      := vecOfList 1 [0]
    unitPhi := fun _ _ => UnitSpecQ0.unitless
    unitD0  := fun _ => UnitSpecQ0.unitless
    yHold   := vecOfList 1 [20]
    epsHold := vecOfList 1 [1] }

def te05_spec : StageESpecQ0 :=
  { design      := te05_designCal
    anchor      := te05_anchorCal
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := some te05_holdout
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te05_disjointCert : HoldoutDisjointCertQ0 te05_designCal te05_holdout.toDesign :=
  { thetaCal  := vecOfList 1 [2]
    domRows   := emptyDomainAffineBundle 1
    wDisjoint := vecOfList 4 [4, 0, 0, 1] }

def te05_bundle : StageECertBundleQ0 te05_spec :=
  .holdoutDisjoint (fun H hEq => by
    change some te05_holdout = some H at hEq
    injection hEq with hH
    subst hH
    exact te05_disjointCert)

theorem te05_calibration_fit_yet_holdout_falsified :
    auditStageEEmpiricalGate stageE_tcb te05_spec te05_bundle =
      .verifiedHoldoutExtrapolationFalsified ∧
    checkDynHoldoutResidualEscape td02_dyn td01_H [2, 0, 1, 1] 1 2 (1 / 2) = true ∧
    (∃ θ_cal : VecQ0 1, InFeasibleParameterSet te05_designCal te05_anchorCal.yObs te05_anchorCal.eps θ_cal) ∧
    (∀ b_any : StageECertBundleQ0 te05_spec,
      auditStageEEmpiricalGate stageE_tcb te05_spec b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te05_spec b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te05_spec b_any ≠ .verifiedCanonicalIVConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te05_spec b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have haud : auditStageEEmpiricalGate stageE_tcb te05_spec te05_bundle =
      .verifiedHoldoutExtrapolationFalsified := by
    with_unfolding_all rfl
  have hdyn : checkDynHoldoutResidualEscape td02_dyn td01_H [2, 0, 1, 1] 1 2 (1 / 2) = true := by
    with_unfolding_all rfl
  rcases thm_stageE_holdout_falsified_sound_and_exclusive stageE_tcb te05_spec te05_bundle haud with
    ⟨hcal, hexcl⟩
  exact ⟨haud, hdyn, hcal, hexcl⟩

/-! ### Vector `TE-06`: Counterfeit Unattained Tight LP Certificate Rejected (`F-E02`) -/

def te06_forgedTight : TightQueryIntervalCertQ0 te01_design :=
  { enclosing := te01_lpEnclosing
    thetaMin  := vecOfList 2 [10, 5]   -- Forged! `q([10, 5]) = 10 ≠ 8 = qLb`
    thetaMax  := vecOfList 2 [12, 2] }

def te06_bundle : StageECertBundleQ0 te01_spec :=
  .fullPointQualified te01_rc te01_lpEnclosing (some te06_forgedTight)

theorem te06_forged_tight_lp_certificate_rejected :
    auditStageEEmpiricalGate stageE_tcb te01_spec te06_bundle =
      .rejectedInvalidCertificate := by
  with_unfolding_all rfl

/-! ### Vectors `TE-07a`, `TE-07b1`, `TE-07b2`, `TE-07c`: Unit, Synthetic, Provenance (`F-E05`) & `a_I` Gates -/

def te07a_ctx : ContextQ0 :=
  { vars := [UnitSpecQ0.energy], hyps := [], guards := [] }

def te07a_design : AffineObservationDesignQ0 :=
  { thetaCtx := te07a_ctx
    obsVars  := [UnitSpecQ0.torque]
    Phi      := matOfLists 1 1 [[1]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.torque }

def te07a_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin     := .unverifiedOrigin
    datasetId         := "TE07A-TORQUE-SMUGGLE"
    payloadSha256Hex  := ""
    calibrationCertId := ""
    attesterId        := ""
    obsVars           := [UnitSpecQ0.torque]
    yObs              := vecOfList 1 [10]
    eps               := vecOfList 1 [1] }

def te07a_spec : StageESpecQ0 :=
  { design      := te07a_design
    anchor      := te07a_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

theorem te07a_torque_energy_sensor_smuggling_rejected :
    validateStageESpec stageE_tcb te07a_spec = some .illTypedObservation ∧
    ∀ bundle : StageECertBundleQ0 te07a_spec,
      auditStageEEmpiricalGate stageE_tcb te07a_spec bundle =
        .rejectedInvalidEmpiricalSpec .illTypedObservation := by
  have hv : validateStageESpec stageE_tcb te07a_spec = some .illTypedObservation := by
    with_unfolding_all rfl
  exact ⟨hv, thm_stageE_invalid_spec_universal_reject stageE_tcb te07a_spec .illTypedObservation hv⟩

def te07b1_syntheticAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te01_anchor with claimedOrigin := .syntheticSimulation }

def te07b1_spec : StageESpecQ0 :=
  { te01_spec with anchor := te07b1_syntheticAnchor }

theorem te07b1_synthetic_simulation_bootstrap_rejected :
    effectiveEmpiricalAuth stageE_tcb te07b1_syntheticAnchor = 0 ∧
    validateStageESpec stageE_tcb te07b1_spec = some .authorityEscalation ∧
    ∀ bundle : StageECertBundleQ0 te07b1_spec,
      auditStageEEmpiricalGate stageE_tcb te07b1_spec bundle =
        .rejectedInvalidEmpiricalSpec .authorityEscalation := by
  have heff : effectiveEmpiricalAuth stageE_tcb te07b1_syntheticAnchor = 0 := by
    with_unfolding_all rfl
  have hv : validateStageESpec stageE_tcb te07b1_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  exact ⟨heff, hv, thm_stageE_invalid_spec_universal_reject stageE_tcb te07b1_spec .authorityEscalation hv⟩

/-- `F-E05` Direct Attack 1: Self-declared `.externalCalibratedMeasurement` with unattested lab. -/
def te07b2_forgedOriginAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te01_anchor with attesterId := "UNATTESTED-SELF-DECLARED-LAB" }

/-- `F-E05` Direct Attack 2: Stolen valid `datasetId` & `payloadSha256Hex`, inflated `eps = [5, 5]`. -/
def te07b2_tamperedEpsAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te01_anchor with eps := vecOfList 2 [5, 5] }

def te07b2_spec : StageESpecQ0 :=
  { te01_spec with anchor := te07b2_forgedOriginAnchor }

theorem te07b2_forged_external_origin_and_tampered_eps_rejected :
    te07b2_forgedOriginAnchor.claimedOrigin = .externalCalibratedMeasurement ∧
    verifyExternalProvenance stageE_tcb te07b2_forgedOriginAnchor = false ∧
    verifyExternalProvenance stageE_tcb te07b2_tamperedEpsAnchor = false ∧
    effectiveEmpiricalAuth stageE_tcb te07b2_forgedOriginAnchor = 0 ∧
    validateStageESpec stageE_tcb te07b2_spec = some .authorityEscalation ∧
    ∀ bundle : StageECertBundleQ0 te07b2_spec,
      auditStageEEmpiricalGate stageE_tcb te07b2_spec bundle =
        .rejectedInvalidEmpiricalSpec .authorityEscalation := by
  have hv : validateStageESpec stageE_tcb te07b2_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  refine ⟨rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          hv,
          thm_stageE_invalid_spec_universal_reject stageE_tcb te07b2_spec .authorityEscalation hv⟩

def te07c_spec : StageESpecQ0 :=
  { te01_spec with claimedAuth := { formal := 1, empirical := 1, institutional := 1 } }

theorem te07c_institutional_authority_escalation_rejected :
    verifyExternalProvenance stageE_tcb te07c_spec.anchor = true ∧
    validateStageESpec stageE_tcb te07c_spec = some .authorityEscalation ∧
    ∀ bundle : StageECertBundleQ0 te07c_spec,
      auditStageEEmpiricalGate stageE_tcb te07c_spec bundle =
        .rejectedInvalidEmpiricalSpec .authorityEscalation := by
  have hv : validateStageESpec stageE_tcb te07c_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  refine ⟨by with_unfolding_all rfl,
          hv,
          thm_stageE_invalid_spec_universal_reject stageE_tcb te07c_spec .authorityEscalation hv⟩

/-! ### Runtime Structured Audit Table (`stageEVectorRecords`) -/

def formatStageEOutcome : StageEGateOutcomeQ0 → String
  | .verifiedEmptyParameterPrior               => "verifiedEmptyParameterPrior"
  | .verifiedConditionallyEmpiricallyQualified => "verifiedConditionallyEmpiricallyQualified"
  | .verifiedQueryConditionallyQualified       => "verifiedQueryConditionallyQualified"
  | .verifiedCanonicalIVConditionallyQualified => "verifiedCanonicalIVConditionallyQualified"
  | .verifiedUnderdeterminedCompatibility      => "verifiedUnderdeterminedCompatibility"
  | .verifiedEmpiricalFarkasFalsification      => "verifiedEmpiricalFarkasFalsification"
  | .verifiedHoldoutExtrapolationFalsified     => "verifiedHoldoutExtrapolationFalsified"
  | .verifiedConfoundingCausalObstruction      => "verifiedConfoundingCausalObstruction"
  | .rejectedInvalidEmpiricalSpec .illTypedObservation =>
      "rejectedInvalidEmpiricalSpec(illTypedObservation)"
  | .rejectedInvalidEmpiricalSpec .invalidUncertaintySpec =>
      "rejectedInvalidEmpiricalSpec(invalidUncertaintySpec)"
  | .rejectedInvalidEmpiricalSpec .invalidSEMOrIVAssumptions =>
      "rejectedInvalidEmpiricalSpec(invalidSEMOrIVAssumptions)"
  | .rejectedInvalidEmpiricalSpec .authorityEscalation =>
      "rejectedInvalidEmpiricalSpec(authorityEscalation)"
  | .rejectedInvalidCertificate                => "rejectedInvalidCertificate"

structure StageEVectorRecord where
  vecId    : String
  expected : StageEGateOutcomeQ0
  actual   : StageEGateOutcomeQ0
  detail   : String

def stageEVectorRecords : List StageEVectorRecord :=
  [ { vecId    := "TE-01"
      expected := .verifiedConditionallyEmpiricallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te01_spec te01_bundle
      detail   := "FullRankAffineHooke_NonZeroOffsetD0_TightLP_HoldoutPass_TCBAttested_FE01_FE02_FE05" },
    { vecId    := "TE-02a"
      expected := .verifiedUnderdeterminedCompatibility
      actual   := auditStageEEmpiricalGate stageE_tcb te02a_spec te02a_bundle
      detail   := "CollinearSumGaugeNullspace_DomainValidTwinWitness_BlocksIndividualPromotion" },
    { vecId    := "TE-02b"
      expected := .verifiedQueryConditionallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te02b_spec te02b_bundle
      detail   := "GaugeInvariantSumQuery_StructID_And_PositiveNoisyIntervalWidth2_FE02_FE03" },
    { vecId    := "TE-03a"
      expected := .verifiedEmpiricalFarkasFalsification
      actual   := auditStageEEmpiricalGate stageE_tcb te03a_spec te03a_bundle
      detail   := "MutuallyContradictoryAffineMeasurements_ExactFarkasDualRefutation" },
    { vecId    := "TE-03b"
      expected := .verifiedEmpiricalFarkasFalsification
      actual   := auditStageEEmpiricalGate stageE_tcb te03b_spec te03b_bundle
      detail   := "PhysicalPositivityGuard_StageDNonnegCert_RefutesNegativeEnvelope" },
    { vecId    := "TE-04a"
      expected := .verifiedConfoundingCausalObstruction
      actual   := auditStageEEmpiricalGate stageE_tcb te04a_spec te04a_bundle
      detail   := "PassiveObservationalClaim_ConfoundingTwinSameSigmaObs_DistinctDoEffect" },
    { vecId    := "TE-04b"
      expected := .verifiedConditionallyEmpiricallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te04b_spec te04b_bundle
      detail   := "ActiveSurgicalDoClamp_SeversConfounders_QualifiesInterventionalEffect_FE04Path1" },
    { vecId    := "TE-04c"
      expected := .verifiedCanonicalIVConditionallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te04c_spec te04c_bundle
      detail   := "Canonical3NodeLinearIV_ExclusionAndErrorOrth_WaldRecoversDoBeta3_FE04Path2" },
    { vecId    := "TE-05"
      expected := .verifiedHoldoutExtrapolationFalsified
      actual   := auditStageEEmpiricalGate stageE_tcb te05_spec te05_bundle
      detail   := "InSampleCalibrationFeasible_StackedFarkasProvesUniversalHoldoutDisjointness" },
    { vecId    := "TE-06"
      expected := .rejectedInvalidCertificate
      actual   := auditStageEEmpiricalGate stageE_tcb te01_spec te06_bundle
      detail   := "CounterfeitTightLPCertificate_UnattainedLowerEndpoint_Rejected_FE02" },
    { vecId    := "TE-07a"
      expected := .rejectedInvalidEmpiricalSpec .illTypedObservation
      actual   := auditStageEEmpiricalGate stageE_tcb te07a_spec (.emptyPrior default)
      detail   := "TorqueSensorVsEnergyPrediction_KindTagSmuggling_StaticallyBlocked" },
    { vecId    := "TE-07b1"
      expected := .rejectedInvalidEmpiricalSpec .authorityEscalation
      actual   := auditStageEEmpiricalGate stageE_tcb te07b1_spec (.emptyPrior default)
      detail   := "SyntheticSimulationBootstrap_EmpiricalZeroCap_StaticallyBlocked" },
    { vecId    := "TE-07b2"
      expected := .rejectedInvalidEmpiricalSpec .authorityEscalation
      actual   := auditStageEEmpiricalGate stageE_tcb te07b2_spec (.emptyPrior default)
      detail   := "ForgedExternalOriginLabel_WithoutTCBAttestation_EmpiricalZeroCap_FE05" },
    { vecId    := "TE-07c"
      expected := .rejectedInvalidEmpiricalSpec .authorityEscalation
      actual   := auditStageEEmpiricalGate stageE_tcb te07c_spec (.emptyPrior default)
      detail   := "InstitutionalAuthorityEscalation_aI1_UnconditionallyBlocked" } ]

end GrandZero.StageE
