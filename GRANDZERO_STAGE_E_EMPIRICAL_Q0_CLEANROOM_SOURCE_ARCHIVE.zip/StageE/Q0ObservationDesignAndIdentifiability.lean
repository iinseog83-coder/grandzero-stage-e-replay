/-
  GRANDZERO Ω — Stage E (Identifiability, Bounded-Error Set-Membership,
                         Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-1: Q0ObservationDesignAndIdentifiability.lean
  Scope:
    1. Exact Affine Observation Design `y^pred(θ) = Φ θ + d₀` (`Tribunal F-E01`) bound directly
       to frozen `StageB.ContextQ0` and `StageC.checkRestrictionMatrixUnits`, with static
       offset unit verification `checkOffsetUnits`.
    2. Global Point Identifiability via frozen `StageC.RankNullityCertQ0` (`rc.k = 0`), proving
       exact affine left-inverse recovery `(U L) ((Φ θ + d₀) - d₀) = θ` and global injectivity
       (`thm_affine_global_point_identifiable`).
    3. Explicit separation of noiseless `StructuralQueryIdentifiable` (`Kᵀ c_query = 0`,
       `thm_structural_query_identifiable_of_orth_kernel`, `Tribunal F-E03`) from domain-valid
       non-identifiability twin witnesses (`TwinUnidentifiableWitnessQ0`,
       `thm_twin_witness_blocks_query_identifiability`).
-/

import StageD

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Part 1: Vector & Matrix Subtraction / Cancellation Lemmas over `Rat` -/

def negVec {n : Nat} (v : VecQ0 n) : VecQ0 n := fun i => -(v i)

def negMat {m n : Nat} (M : MatQ0 m n) : MatQ0 m n := fun i j => -(M i j)

theorem add_sub_cancel_vec {n : Nat} (u d : VecQ0 n) :
    subVec (addVec u d) d = u := by
  funext i
  unfold subVec addVec
  grind

theorem sub_eq_zero_iff_vec {n : Nat} (u v : VecQ0 n) :
    subVec u v = zeroVec n ↔ u = v := by
  constructor
  · intro h
    funext i
    have hi := congrFun h i
    dsimp [subVec, zeroVec] at hi
    grind
  · intro h
    subst h
    funext i
    dsimp [subVec, zeroVec]
    grind

theorem finSum_sub :
    ∀ (k : Nat) (f g : Fin k → Rat),
      finSum k (fun j => f j - g j) = finSum k f - finSum k g
  | 0, _, _ => by simp only [finSum]; grind
  | r + 1, f, g => by
      simp only [finSum, finSum_sub r]
      grind

theorem matVec_sub {m n : Nat} (M : MatQ0 m n) (x y : VecQ0 n) :
    matVec M (subVec x y) = subVec (matVec M x) (matVec M y) := by
  funext i
  unfold matVec subVec
  rw [← finSum_sub]
  apply finSum_ext
  intro j
  grind

theorem matVec_negMat {m n : Nat} (M : MatQ0 m n) (x : VecQ0 n) :
    matVec (negMat M) x = negVec (matVec M x) := by
  funext i
  unfold matVec negMat negVec
  have hneg : (-1 : Rat) * finSum n (fun j => M i j * x j) =
      finSum n (fun j => (-1 : Rat) * (M i j * x j)) :=
    finSum_mul_left (-1) n _
  have hrew1 : -(finSum n (fun j => M i j * x j)) =
      (-1 : Rat) * finSum n (fun j => M i j * x j) := by grind
  rw [hrew1, hneg]
  apply finSum_ext
  intro j
  grind

theorem dotVec_sub_right {n : Nat} (c x y : VecQ0 n) :
    dotVec c (subVec x y) = dotVec c x - dotVec c y := by
  unfold dotVec subVec
  rw [← finSum_sub]
  apply finSum_ext
  intro j
  grind

theorem dotVec_neg_left {n : Nat} (c x : VecQ0 n) :
    dotVec (negVec c) x = -(dotVec c x) := by
  unfold dotVec negVec
  have h1 : -(finSum n (fun i => c i * x i)) =
      (-1 : Rat) * finSum n (fun i => c i * x i) := by grind
  rw [h1, finSum_mul_left (-1) n]
  apply finSum_ext
  intro i
  grind

theorem lem_matMul_zero_inner {m k n : Nat} (hk : k = 0)
    (A : MatQ0 m k) (B : MatQ0 k n) :
    matMul A B = zeroMat m n := by
  subst hk
  rfl

theorem addMat_zero_right {m n : Nat} (A : MatQ0 m n) :
    addMat A (zeroMat m n) = A := by
  funext i j
  dsimp [addMat, zeroMat]
  exact Rat.add_zero (A i j)

/-! ### Part 2: Unit-Typed Affine Observation Design (`y^pred(θ) = Φ θ + d₀`, `Tribunal F-E01`) -/

/-- Exact affine-in-parameters observation design over parameter context `thetaCtx`
    and sensor channel unit context `obsVars` (`Tribunal F-E01`). -/
structure AffineObservationDesignQ0 where
  thetaCtx : ContextQ0
  obsVars  : VarCtxQ0
  Phi      : MatQ0 obsVars.length thetaCtx.vars.length
  d0       : VecQ0 obsVars.length
  unitPhi  : Fin obsVars.length → Fin thetaCtx.vars.length → UnitSpecQ0
  unitD0   : Fin obsVars.length → UnitSpecQ0

namespace AffineObservationDesignQ0

abbrev p (D : AffineObservationDesignQ0) : Nat := D.thetaCtx.vars.length
abbrev m (D : AffineObservationDesignQ0) : Nat := D.obsVars.length

/-- Exact affine predicted observation vector `y^pred(θ) = Φ θ + d₀`. -/
def predict (D : AffineObservationDesignQ0) (θ : VecQ0 D.p) : VecQ0 D.m :=
  addVec (matVec D.Phi θ) D.d0

end AffineObservationDesignQ0

/-- Check that every non-zero baseline offset coordinate `d0 i` carries the exact
    synthesized channel `UnitSpecQ0` (`DimVec7` + `KindTagQ0`) of `obsVars[i]` (`F-E01`). -/
def checkOffsetUnits (obsVars : VarCtxQ0) (d0 : VecQ0 obsVars.length)
    (unitD0 : Fin obsVars.length → UnitSpecQ0) : Bool :=
  allFin obsVars.length fun i =>
    if d0 i == 0 then true
    else obsVars[i.val]? == some (unitD0 i)

/-- Static unit/kind & non-empty channel gate for `AffineObservationDesignQ0`. -/
def checkAffineObservationUnits (D : AffineObservationDesignQ0) : Bool :=
  wellTypedContext D.thetaCtx &&
  decide (0 < D.obsVars.length) &&
  checkRestrictionMatrixUnits D.thetaCtx.vars D.obsVars D.Phi D.unitPhi &&
  checkOffsetUnits D.obsVars D.d0 D.unitD0

theorem thm_affine_observation_units_sound {D : AffineObservationDesignQ0}
    (h : checkAffineObservationUnits D = true) :
    wellTypedContext D.thetaCtx = true ∧
    0 < D.obsVars.length ∧
    checkRestrictionMatrixUnits D.thetaCtx.vars D.obsVars D.Phi D.unitPhi = true ∧
    checkOffsetUnits D.obsVars D.d0 D.unitD0 = true := by
  unfold checkAffineObservationUnits at h
  simp only [Bool.and_eq_true, decide_eq_true_eq] at h
  exact ⟨h.1.1.1, h.1.1.2, h.1.2, h.2⟩

/-! ### Part 3: Global Point Identifiability & Exact Affine Left-Inverse (`F-E01`) -/

/-- Exact affine left-inverse parameter estimator `θ̂(y) := (U L) (y - d₀)` (`F-E01`). -/
def affineLeftInverseEst (D : AffineObservationDesignQ0)
    (rc : RankNullityCertQ0 D.m D.p) (y : VecQ0 D.m) : VecQ0 D.p :=
  matVec (matMul rc.U rc.L) (subVec y D.d0)

theorem thm_rank_nullity_k0_left_inverse {m p : Nat}
    (Phi : MatQ0 m p) (rc : RankNullityCertQ0 m p)
    (hrc : checkRankNullityCert Phi rc = true) (hk0 : rc.k = 0) :
    matMul (matMul rc.U rc.L) Phi = idMat p := by
  unfold checkRankNullityCert at hrc
  simp only [Bool.and_eq_true, decide_eq_true_eq, matEqBool_iff] at hrc
  have hpart := hrc.2
  rw [lem_matMul_zero_inner hk0 rc.K rc.R, addMat_zero_right] at hpart
  rw [matMul_assoc]
  exact hpart

/-- Target Theorem `thm_affine_global_point_identifiable` (`Tribunal F-E01`):
    When `checkRankNullityCert D.Phi rc = true` and `rc.k = 0`, the affine observation
    map `θ ↦ Φ θ + d₀` has exact left-inverse `affineLeftInverseEst D rc` and is
    globally injective across `ℚ^p` (and hence on `Real_ℚ(D.thetaCtx)`). -/
theorem thm_affine_global_point_identifiable
    (D : AffineObservationDesignQ0)
    (rc : RankNullityCertQ0 D.m D.p)
    (hrc : checkRankNullityCert D.Phi rc = true)
    (hk0 : rc.k = 0) :
    (∀ θ : VecQ0 D.p, affineLeftInverseEst D rc (D.predict θ) = θ) ∧
    (∀ θ1 θ2 : VecQ0 D.p, D.predict θ1 = D.predict θ2 → θ1 = θ2) := by
  have hleft := thm_rank_nullity_k0_left_inverse D.Phi rc hrc hk0
  have hrec : ∀ θ : VecQ0 D.p, affineLeftInverseEst D rc (D.predict θ) = θ := by
    intro θ
    unfold affineLeftInverseEst AffineObservationDesignQ0.predict
    rw [add_sub_cancel_vec, ← matVec_matMul, hleft, idMat_vec]
  refine ⟨hrec, ?_⟩
  intro θ1 θ2 heq
  calc
    θ1 = affineLeftInverseEst D rc (D.predict θ1) := (hrec θ1).symm
    _  = affineLeftInverseEst D rc (D.predict θ2) := by rw [heq]
    _  = θ2 := hrec θ2

/-! ### Part 4: Structural Query Identifiability vs. Domain-Valid Twins (`Tribunal F-E03`) -/

/-- Noiseless Structural Query Identifiability (`Tribunal F-E03`):
    Whenever two parameter vectors produce the EXACT same affine noiseless prediction
    `Φ θ₁ + d₀ = Φ θ₂ + d₀`, they yield the exact same target query value `⟨c_query, θ⟩`.
    (Strictly distinct from finite-noise interval uncertainty under `ε > 0` in `E-2`.) -/
def StructuralQueryIdentifiable (D : AffineObservationDesignQ0) (cQuery : VecQ0 D.p) : Prop :=
  ∀ θ1 θ2 : VecQ0 D.p, D.predict θ1 = D.predict θ2 → dotVec cQuery θ1 = dotVec cQuery θ2

/-- Computable certificate checker verifying `Kᵀ c_query = 0` (`c_query ⊥ ker(Φ)`). -/
def checkQueryOrthogonalKernel (D : AffineObservationDesignQ0)
    (rc : RankNullityCertQ0 D.m D.p) (cQuery : VecQ0 D.p) : Bool :=
  checkRankNullityCert D.Phi rc &&
  vecEqBool (matVec (transposeMat rc.K) cQuery) (zeroVec rc.k)

/-- Target Theorem `thm_structural_query_identifiable_of_orth_kernel` (`Tribunal F-E03`):
    If `checkQueryOrthogonalKernel D rc cQuery = true`, then `cQuery` is invariant across
    all exact affine observation fibres `Φ θ + d₀ = y`. -/
theorem thm_structural_query_identifiable_of_orth_kernel
    (D : AffineObservationDesignQ0)
    (rc : RankNullityCertQ0 D.m D.p)
    (cQuery : VecQ0 D.p)
    (hchk : checkQueryOrthogonalKernel D rc cQuery = true) :
    StructuralQueryIdentifiable D cQuery := by
  unfold checkQueryOrthogonalKernel at hchk
  simp only [Bool.and_eq_true, vecEqBool_iff] at hchk
  rcases hchk with ⟨hrc, horth⟩
  have hker := (thm_rank_nullity_cert_kernel_exact D.Phi rc hrc).2.2.2
  intro θ1 θ2 heq
  have hdiff_pred : subVec (D.predict θ1) (D.predict θ2) = zeroVec D.m :=
    (sub_eq_zero_iff_vec _ _).mpr heq
  have hphi_diff : matVec D.Phi (subVec θ1 θ2) = zeroVec D.m := by
    rw [matVec_sub]
    funext i
    have hi := congrFun hdiff_pred i
    dsimp [AffineObservationDesignQ0.predict, subVec, addVec, zeroVec] at hi ⊢
    grind
  have hdecomp := hker (subVec θ1 θ2) hphi_diff
  have hq_diff : dotVec cQuery (subVec θ1 θ2) = 0 := by
    rw [hdecomp, dotVec_matVec_transpose, horth, dotVec_zero_left]
  rw [dotVec_sub_right] at hq_diff
  grind

/-- Domain-valid Twin Non-Identifiability Witness inside `Real_ℚ(D.thetaCtx)`. -/
structure TwinUnidentifiableWitnessQ0 (p : Nat) where
  theta1 : VecQ0 p
  theta2 : VecQ0 p

def checkTwinDomainIndistinguishable
    (D : AffineObservationDesignQ0) (cQuery : VecQ0 D.p)
    (tw : TwinUnidentifiableWitnessQ0 D.p) : Bool :=
  !vecEqBool tw.theta1 tw.theta2 &&
  checkValidDomainQ0 (vecToList tw.theta1) D.thetaCtx &&
  checkValidDomainQ0 (vecToList tw.theta2) D.thetaCtx &&
  vecEqBool (D.predict tw.theta1) (D.predict tw.theta2) &&
  decide (dotVec cQuery tw.theta1 ≠ dotVec cQuery tw.theta2)

/-- Target Theorem `thm_twin_witness_blocks_query_identifiability`:
    A verified domain-valid twin witness `(θ₁, θ₂)` proves constructively inside
    `Real_ℚ(D.thetaCtx)` that `θ₁ ≠ θ₂`, `Φ θ₁ + d₀ = Φ θ₂ + d₀`, `q(θ₁) ≠ q(θ₂)`,
    `¬ StructuralQueryIdentifiable D cQuery`, and NO `RankNullityCertQ0` can certify
    `checkQueryOrthogonalKernel D rc cQuery = true`. -/
theorem thm_twin_witness_blocks_query_identifiability
    (D : AffineObservationDesignQ0) (cQuery : VecQ0 D.p)
    (tw : TwinUnidentifiableWitnessQ0 D.p)
    (htw : checkTwinDomainIndistinguishable D cQuery tw = true) :
    tw.theta1 ≠ tw.theta2 ∧
    ValidDomainQ0 (vecToList tw.theta1) D.thetaCtx ∧
    ValidDomainQ0 (vecToList tw.theta2) D.thetaCtx ∧
    D.predict tw.theta1 = D.predict tw.theta2 ∧
    dotVec cQuery tw.theta1 ≠ dotVec cQuery tw.theta2 ∧
    ¬ StructuralQueryIdentifiable D cQuery ∧
    (∀ rc : RankNullityCertQ0 D.m D.p, checkQueryOrthogonalKernel D rc cQuery = false) := by
  unfold checkTwinDomainIndistinguishable at htw
  simp only [Bool.and_eq_true, Bool.not_eq_true', vecEqBool_iff,
             lem_checkValidDomain_iff, decide_eq_true_eq] at htw
  rcases htw with ⟨⟨⟨⟨hne_b, hdom1⟩, hdom2⟩, hpred_eq⟩, hq_ne⟩
  have hne : tw.theta1 ≠ tw.theta2 := by
    intro heq
    rw [(vecEqBool_iff _ _).mpr heq] at hne_b
    contradiction
  have hnot_id : ¬ StructuralQueryIdentifiable D cQuery := by
    intro hid
    exact hq_ne (hid tw.theta1 tw.theta2 hpred_eq)
  refine ⟨hne, hdom1, hdom2, hpred_eq, hq_ne, hnot_id, ?_⟩
  intro rc
  cases hchk : checkQueryOrthogonalKernel D rc cQuery with
  | false => rfl
  | true => exact False.elim (hnot_id (thm_structural_query_identifiable_of_orth_kernel D rc cQuery hchk))

end GrandZero.StageE
