import Lake
open Lake DSL

package «gz_stage_e_empirical_q0» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

lean_lib «StageA» where
  roots := #[`StageA]

lean_lib «StageB» where
  roots := #[`StageB]

lean_lib «StageC» where
  roots := #[`StageC]

lean_lib «StageD» where
  roots := #[`StageD]

lean_lib «StageE» where
  roots := #[`StageE]

@[default_target]
lean_exe «stage_e_audit» where
  root := `Main
